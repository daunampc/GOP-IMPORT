<?php

namespace GopImport\Admin;

/**
 * Registers the menu and renders the admin screen.
 *
 * All of this loads only inside wp-admin — the API in `index.php` never comes
 * through here, so the interface costs the import path nothing.
 *
 * The landing view is a DASHBOARD rather than a settings form. What an operator
 * needs on opening this page is one sentence saying whether imports can happen
 * at all, and then the numbers; the forms are what they came for second.
 */
final class Admin
{
    public const SLUG = 'gop-import';

    private const TABS = [
        'dashboard'   => 'Dashboard',
        'connection'  => 'Connection',
        'license'     => 'Licence',
        'maintenance' => 'Maintenance',
        'logs'        => 'Import log',
        'status'      => 'Diagnostics',
    ];

    public static function register(): void
    {
        add_action('admin_menu', [self::class, 'menu']);
        add_action('admin_enqueue_scripts', [self::class, 'assets']);
        Actions::register();
    }

    public static function menu(): void
    {
        add_menu_page(
            'GOP_IMPORT',
            'GOP_IMPORT',
            Actions::CAPABILITY,
            self::SLUG,
            [self::class, 'render'],
            'dashicons-database-import',
            58
        );
    }

    public static function assets(string $hook): void
    {
        // Only on the plugin's own page, rather than sprayed across wp-admin.
        if ($hook !== 'toplevel_page_' . self::SLUG) {
            return;
        }

        wp_enqueue_style(
            'gop-import-admin',
            plugins_url('admin/assets/admin.css', dirname(__DIR__) . '/gop-import.php'),
            [],
            GOP_IMPORT_VERSION
        );
    }

    public static function currentTab(): string
    {
        $tab = isset($_GET['tab']) ? sanitize_key(wp_unslash($_GET['tab'])) : 'dashboard';

        return isset(self::TABS[$tab]) ? $tab : 'dashboard';
    }

    public static function tabUrl(string $tab): string
    {
        return admin_url('admin.php?page=' . self::SLUG . '&tab=' . $tab);
    }

    public static function render(): void
    {
        if (!current_user_can(Actions::CAPABILITY)) {
            wp_die(esc_html__('You do not have permission to view this page.', 'gop-import'), 403);
        }

        $tab = self::currentTab();
        $tabs = self::TABS;
        $notice = Actions::takeNotice();

        require __DIR__ . '/views/page.php';
    }

    /* ------------------------------------------------------------- helpers */

    /** A submit button in its own form, with the nonce already in place. */
    public static function actionButton(
        string $action,
        string $label,
        string $class = 'button',
        array $fields = [],
        string $confirm = ''
    ): void {
        ?>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"
              <?php if ($confirm !== '') : ?>onsubmit="return confirm(<?php echo esc_attr(wp_json_encode($confirm)); ?>);"<?php endif; ?>>
            <input type="hidden" name="action" value="gpm_tsd_<?php echo esc_attr($action); ?>">
            <?php wp_nonce_field("gpm_tsd_$action"); ?>
            <?php foreach ($fields as $name => $value) : ?>
                <input type="hidden" name="<?php echo esc_attr($name); ?>" value="<?php echo esc_attr($value); ?>">
            <?php endforeach; ?>
            <button type="submit" class="<?php echo esc_attr($class); ?>">
                <?php echo esc_html($label); ?>
            </button>
        </form>
        <?php
    }

    /** A read-only text field with a copy button. */
    public static function copyField(string $label, string $value, string $hint = ''): void
    {
        $id = 'gop-copy-' . wp_generate_password(6, false, false);
        ?>
        <div class="gop-field">
            <label for="<?php echo esc_attr($id); ?>"><?php echo esc_html($label); ?></label>
            <div class="gop-copy-row">
                <input type="text" id="<?php echo esc_attr($id); ?>" readonly
                       value="<?php echo esc_attr($value); ?>" onfocus="this.select();">
                <button type="button" class="button"
                        onclick="navigator.clipboard.writeText(document.getElementById('<?php echo esc_js($id); ?>').value); this.textContent='Copied';">
                    Copy
                </button>
            </div>
            <?php if ($hint !== '') : ?>
                <p class="description"><?php echo esc_html($hint); ?></p>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * One dashboard card.
     *
     * `null` prints an em dash rather than a zero. "We could not read this" and
     * "this is none" are different facts, and a 0 for the first is a number
     * somebody will make a decision on.
     */
    public static function card(string $label, ?string $value, string $hint = '', string $state = ''): void
    {
        ?>
        <div class="gop-card<?php echo $state !== '' ? ' is-' . esc_attr($state) : ''; ?>">
            <span class="gop-card-label"><?php echo esc_html($label); ?></span>
            <strong class="gop-card-value"><?php echo $value === null ? '—' : esc_html($value); ?></strong>
            <?php if ($hint !== '') : ?>
                <span class="gop-card-hint"><?php echo esc_html($hint); ?></span>
            <?php endif; ?>
        </div>
        <?php
    }

    /** Thousands separators, or an em dash when the number is unknown. */
    public static function number(?int $value): ?string
    {
        return $value === null ? null : number_format_i18n($value);
    }
}
