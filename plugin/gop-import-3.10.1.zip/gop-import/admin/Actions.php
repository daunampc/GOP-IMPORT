<?php

namespace GopImport\Admin;

use GopImport\Bootstrap;
use GopImport\License\License;
use GopImport\License\Verifier;
use GopImport\Setup\Installer;
use GopImport\Setup\InstallerException;
use GopImport\Support\Config;

/**
 * Handles the buttons on the admin screen.
 *
 * Every handler passes three gates, in this order: capability, nonce, then the
 * work. Without the nonce, any website could trick a logged-in administrator into
 * following a hidden link and reinstalling every stored function.
 */
final class Actions
{
    public const CAPABILITY = 'manage_options';

    private const NOTICE_TRANSIENT = 'gpm_tsd_notice_';

    public static function register(): void
    {
        $actions = [
            'install'          => [self::class, 'install'],
            'regenerate_keys'  => [self::class, 'regenerateKeys'],
            'clear_transients' => [self::class, 'clearTransients'],
            'fix_prices'       => [self::class, 'fixPrices'],
            'delete_setup'     => [self::class, 'deleteSetup'],
            'activate_license' => [self::class, 'activateLicense'],
            'recheck_license'  => [self::class, 'recheckLicense'],
        ];

        foreach ($actions as $name => $callback) {
            add_action("admin_post_gpm_tsd_$name", $callback);
        }
    }

    /** Capability and nonce. On failure it stops dead rather than redirecting. */
    private static function guard(string $action): void
    {
        if (!current_user_can(self::CAPABILITY)) {
            wp_die(esc_html__('You do not have permission to perform this action.', 'gop-import'), 403);
        }

        check_admin_referer("gpm_tsd_$action");
    }

    private static function notice(string $type, string $message, array $log = []): void
    {
        set_transient(
            self::NOTICE_TRANSIENT . get_current_user_id(),
            ['type' => $type, 'message' => $message, 'log' => $log],
            60
        );
    }

    /** @return array{type:string, message:string, log:array<int,string>}|null */
    public static function takeNotice(): ?array
    {
        $key = self::NOTICE_TRANSIENT . get_current_user_id();
        $notice = get_transient($key);

        if (!is_array($notice)) {
            return null;
        }

        // Read once and delete — otherwise a refresh shows the old notice again.
        delete_transient($key);

        return $notice;
    }

    private static function back(string $tab = 'dashboard'): void
    {
        wp_safe_redirect(admin_url('admin.php?page=gop-import&tab=' . $tab));
        exit;
    }

    /**
     * A full install: detect the charset, install the stored routines, create the
     * table, write the config.
     *
     * Running inside wp-admin, it takes the database credentials straight from
     * WordPress's own constants rather than guessing where wp-config.php is, as the
     * CLI path has to.
     */
    public static function install(): void
    {
        self::guard('install');

        $keepKeys = isset($_POST['keep_keys']) && $_POST['keep_keys'] === '1';

        try {
            $installer = new Installer(Bootstrap::FN_PREFIX);
            $credentials = Installer::fromWordPress();
            $connection = $installer->connect($credentials);

            [$charset, $collate] = $installer->detectCharsetCollate(
                $connection,
                $credentials['DB_NAME'],
                $credentials['table_prefix']
            );

            // Must run BEFORE installRoutines: a stored function's parameters take
            // the database's default collation at the moment the function is created.
            $installer->normalizeCollation(
                $connection,
                $credentials['DB_NAME'],
                $credentials['table_prefix'],
                $charset,
                $collate
            );

            $installer->installRoutines($connection, $credentials['table_prefix'], dirname(__DIR__) . '/sql');
            $installer->installTables($connection, $credentials['table_prefix'], $charset, $collate);

            // Reinstalling with the existing keys leaves the managing app's
            // connection intact.
            $keys = self::resolveKeys($keepKeys);

            $installer->writeConfig(
                $credentials,
                $charset,
                $collate,
                untrailingslashit(site_url()),
                $keys
            );

            $message = $keepKeys && self::hasExistingKeys()
                ? 'Installed. The existing api_key and api_secret were kept.'
                : 'Installed. A new key pair was generated — save the API secret below, it is shown once.';

            if (!$keepKeys || !self::hasExistingKeys()) {
                self::flashSecret($keys['api_secret']);
            }

            self::notice('success', $message, $installer->log());
        } catch (InstallerException $exception) {
            self::notice('error', $exception->getMessage(), $installer->log());
        } catch (\Throwable $exception) {
            self::notice('error', 'Unexpected error: ' . $exception->getMessage());
        }

        /*
         * Land on Connection, not Diagnostics.
         *
         * A fresh install flashes the API secret, and it is readable exactly once
         * within a five-minute window. Redirecting somewhere that does not display
         * it means the operator has to know to go looking — and the WordPress e2e
         * run is what showed this up: install succeeded and put the operator on a
         * page with no secret on it.
         */
        self::back('connection');
    }

    /**
     * @return array{api_key:string, api_secret:string}
     */
    private static function resolveKeys(bool $keepExisting): array
    {
        if ($keepExisting && self::hasExistingKeys()) {
            $config = Config::load();
            return [
                'api_key'    => (string) $config->get('api_key'),
                'api_secret' => (string) $config->get('api_secret'),
            ];
        }

        return Installer::generateKeys();
    }

    private static function hasExistingKeys(): bool
    {
        if (!Config::exists()) {
            return false;
        }

        try {
            Config::setInstance(null);
            $config = Config::load();
            return (string) $config->get('api_key', '') !== ''
                && (string) $config->get('api_secret', '') !== '';
        } catch (\Throwable) {
            return false;
        }
    }

    /**
     * The secret is shown ONCE, immediately after it is created.
     *
     * After that it lives in config.ini. Putting it back on the admin screen at
     * every page load would widen the leak surface and add nothing.
     */
    private static function flashSecret(string $secret): void
    {
        set_transient('gpm_tsd_secret_' . get_current_user_id(), $secret, 300);
    }

    public static function takeSecret(): ?string
    {
        $key = 'gpm_tsd_secret_' . get_current_user_id();
        $secret = get_transient($key);

        if (!is_string($secret)) {
            return null;
        }

        delete_transient($key);

        return $secret;
    }

    /** Generate a new key pair. Breaks every connection still using the old one. */
    public static function regenerateKeys(): void
    {
        self::guard('regenerate_keys');

        try {
            $config = Config::load();
            $keys = Installer::generateKeys();

            $installer = new Installer(Bootstrap::FN_PREFIX);
            $credentials = Installer::fromWordPress();

            $installer->writeConfig(
                $credentials,
                (string) $config->get('charset', 'utf8mb4'),
                (string) $config->get('collate', 'utf8mb4_unicode_ci'),
                untrailingslashit(site_url()),
                $keys
            );

            self::flashSecret($keys['api_secret']);
            Config::setInstance(null);

            self::notice(
                'success',
                'A new key pair was generated. Update the managing app — the old keys no longer work.'
            );
        } catch (\Throwable $exception) {
            self::notice('error', $exception->getMessage());
        }

        self::back('connection');
    }

    /**
     * Writing straight to the database means WooCommerce never clears its own
     * transients. This button calls the cleanup procedure by hand.
     */
    public static function clearTransients(): void
    {
        self::guard('clear_transients');

        self::runProcedure(
            [Bootstrap::FN_PREFIX . 'clear_woocommeerce_transients', Bootstrap::FN_PREFIX . 'clear_woocommeerce_transients_price'],
            'WooCommerce transients cleared.'
        );

        self::back('maintenance');
    }

    /** Repair the min/max price range of variable products when it has drifted. */
    public static function fixPrices(): void
    {
        self::guard('fix_prices');

        self::runProcedure(
            [Bootstrap::FN_PREFIX . 'fix_min_max_price_upgrade_v2_0'],
            'Recalculated the min/max price of every variable product.'
        );

        self::back('maintenance');
    }

    /** @param array<int,string> $procedures */
    private static function runProcedure(array $procedures, string $successMessage): void
    {
        try {
            $installer = new Installer(Bootstrap::FN_PREFIX);
            $connection = $installer->connect(Installer::fromWordPress());

            foreach ($procedures as $procedure) {
                /*
                 * clear_* takes a product id, and NULL — not 0 — is what means "all
                 * of them".
                 *
                 * The procedure branches on `IF(_idParent IS NOT null)`. Passing 0
                 * took the per-product branch, whose statement is
                 * `DELETE FROM wp_options WHERE option_name LIKE CONCAT('%_', 0)`:
                 * it cleared no WooCommerce transient at all, and it did delete any
                 * unrelated option whose name ended in `_0`. The ten correct
                 * statements live in the ELSE branch and had never run, so this
                 * button had never done what it says.
                 */
                $argument = str_contains($procedure, 'clear_woocommeerce') ? '(NULL)' : '()';
                $connection->query("CALL `$procedure`$argument");
            }

            self::notice('success', $successMessage);
        } catch (\Throwable $exception) {
            self::notice('error', $exception->getMessage());
        }
    }

    public static function deleteSetup(): void
    {
        self::guard('delete_setup');

        $path = dirname(__DIR__) . '/setup.php';

        if (!file_exists($path)) {
            self::notice('success', 'setup.php is already gone.');
        } elseif (@unlink($path)) {
            self::notice('success', 'setup.php deleted.');
        } else {
            self::notice(
                'error',
                'Could not delete setup.php — PHP cannot write to the plugin directory. Delete it by hand over FTP.'
            );
        }

        self::back('status');
    }
    /**
     * Activate this installation.
     *
     * One field: the key. The address of the managing app belongs to the build, not to
     * the customer — see `GOP_IMPORT_APP_URL` in `gop-import.php`.
     *
     * The three outcomes stay distinguishable in the notice — activated, rejected, or
     * could not be reached — because only the third one leaves an existing licence
     * alone.
     */
    public static function activateLicense(): void
    {
        self::guard('activate_license');

        $key = isset($_POST['license_key']) ? sanitize_text_field(wp_unslash($_POST['license_key'])) : '';

        $result = Verifier::verify($key);

        self::notice($result['ok'] ? 'success' : 'error', $result['message']);
        self::back('license');
    }

    /** Ask again now, rather than waiting for the daily check. */
    public static function recheckLicense(): void
    {
        self::guard('recheck_license');

        $state = License::state();

        if (License::normalise($state['key']) === '') {
            self::notice('error', 'No key stored yet.');
            self::back('license');
        }

        $result = Verifier::verify($state['key']);

        self::notice($result['ok'] ? 'success' : 'error', $result['message']);
        self::back('license');
    }

}
