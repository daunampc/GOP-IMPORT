<?php
/**
 * The activation dialog.
 *
 * Copy rule for everything a user reads on this screen: one line per idea, no
 * explanation of how the licence works, no reasoning. Somebody looking at this wants
 * to type a key and get on with their day; the reasoning belongs in the code and in
 * the docs, which is where it now is.
 *
 * Plain markup with the form inside it — no JavaScript, nothing dismissible. The
 * plugin cannot do anything until this is filled in, so a dialog that could be closed
 * would only leave the screen looking ready when it is not.
 */

use GopImport\License\License;

if (!defined('ABSPATH')) {
    exit;
}

$state = License::state();
$verdict = License::verdict($state);
$hasKey = License::normalise($state['key']) !== '';
$configured = License::appUrl() !== '';
?>

<div class="gop-modal-backdrop" role="presentation"></div>

<div class="gop-modal" role="dialog" aria-modal="true" aria-labelledby="gop-activate-title">
    <div class="gop-modal-head">
        <span class="gop-modal-mark" aria-hidden="true">GOP</span>
        <div>
            <h2 id="gop-activate-title">Activate this site</h2>
            <p>Enter your licence key to switch the import API on.</p>
        </div>
    </div>

    <?php if (!$configured) : ?>
        <p class="gop-modal-note">
            This build has no activation server, so the key is saved without being checked.
        </p>
    <?php elseif ($hasKey) : ?>
        <p class="gop-modal-error" role="alert">
            <?php echo esc_html($verdict['message']); ?>
        </p>
    <?php endif; ?>

    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="gop-modal-form">
        <input type="hidden" name="action" value="gpm_tsd_activate_license">
        <?php wp_nonce_field('gpm_tsd_activate_license'); ?>

        <p class="gop-field">
            <label for="gop-key">Licence key</label>
            <input type="text" id="gop-key" name="license_key" class="code"
                   value="<?php echo esc_attr($state['key']); ?>"
                   placeholder="GOP-XXXX-XXXX-XXXX"
                   autocomplete="off" spellcheck="false" required autofocus>
        </p>

        <button type="submit" class="button button-primary button-hero gop-modal-submit">
            Activate
        </button>
    </form>

    <p class="gop-modal-foot">Use the same key as your web account.</p>
</div>
