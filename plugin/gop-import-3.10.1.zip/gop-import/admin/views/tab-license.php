<?php
/**
 * The Licence tab, for a site that is already activated.
 *
 * An unactivated site never reaches here — `page.php` shows the dialog instead — so
 * this is the maintenance view: what the licence is, when it expires, when it was
 * last checked, and the two buttons.
 */

use GopImport\License\License;

if (!defined('ABSPATH')) {
    exit;
}

$state = License::state();
$verdict = License::verdict($state);
$fingerprint = License::fingerprint($state['key']);
?>

<div class="gop-panel">
    <div class="gop-licence-head">
        <?php $local = License::appUrl() === ''; ?>
        <span class="gop-pill <?php echo $verdict['allowed'] ? ($local ? 'is-warn' : 'is-ok') : 'is-bad'; ?>">
            <?php echo $verdict['allowed'] ? ($local ? 'Active · not verified' : 'Active') : 'Inactive'; ?>
        </span>
        <?php if ($local) : ?>
            <span class="gop-licence-reason">No activation server in this build, so the key was not checked.</span>
        <?php endif; ?>
        <?php if (!$verdict['allowed']) : ?>
            <span class="gop-licence-reason"><?php echo esc_html($verdict['message']); ?></span>
        <?php endif; ?>
    </div>

    <table class="gop-licence-facts">
        <tr>
            <th scope="row">Key</th>
            <td class="code"><?php echo esc_html($state['key']); ?></td>
        </tr>
        <tr>
            <th scope="row">Expires</th>
            <td><?php echo esc_html($state['expires_at'] === null ? 'Never' : License::day($state['expires_at'])); ?></td>
        </tr>
        <tr>
            <th scope="row">Last checked</th>
            <td><?php echo esc_html(License::day($state['verified_at'])); ?></td>
        </tr>
        <tr>
            <th scope="row">Server</th>
            <td class="code"><?php echo esc_html(License::appUrl() === '' ? 'not configured' : License::appUrl()); ?></td>
        </tr>
        <tr>
            <th scope="row">Fingerprint</th>
            <td class="code"><?php echo esc_html($fingerprint === '' ? '—' : substr($fingerprint, 0, 16)); ?></td>
        </tr>
    </table>

    <div class="gop-licence-actions">
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="gpm_tsd_recheck_license">
            <?php wp_nonce_field('gpm_tsd_recheck_license'); ?>
            <button type="submit" class="button button-primary">Check now</button>
        </form>

        <details class="gop-licence-replace">
            <summary>Use a different key</summary>

            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="gpm_tsd_activate_license">
                <?php wp_nonce_field('gpm_tsd_activate_license'); ?>

                <p class="gop-field">
                    <label for="gop-key-new">Licence key</label>
                    <input type="text" id="gop-key-new" name="license_key" class="code"
                           value="<?php echo esc_attr($state['key']); ?>"
                           autocomplete="off" spellcheck="false" required>
                </p>

                <button type="submit" class="button">Save and check</button>
            </form>
        </details>
    </div>

    <p class="gop-licence-note">
        <?php echo License::appUrl() === ''
            ? 'Nothing is checked while this build has no activation server. Without a key at all, the API is off.'
            : 'The key is confirmed once a day. Without a valid one the API is off.'; ?>
    </p>
</div>
