<?php
/** The Import log tab: the most recently imported products. */

use GopImport\Admin\Admin;
use GopImport\Admin\Status;

if (!defined('ABSPATH')) {
    exit;
}

$rows = Status::recentImports(50);
?>

<div class="gop-panel">
    <h2>The 50 most recent imports</h2>

    <p class="gop-panel-lede">
        This table records each product's idempotency key. Sending the same key again
        returns the existing product instead of creating a duplicate — which is what makes
        re-importing the same file safe, and what a removal has to delete along with the
        product so it can be imported again afterwards.
    </p>

    <?php if ($rows === []) : ?>
        <p class="gop-empty">
            Nothing has been imported yet. If an import has just finished and this table is
            still empty, check &ldquo;Import log table&rdquo; on the
            <a href="<?php echo esc_url(Admin::tabUrl('status')); ?>">Diagnostics</a> tab.
        </p>
    <?php else : ?>
        <table class="widefat striped gop-table">
            <thead>
            <tr>
                <th scope="col">Product</th>
                <th scope="col">Variations</th>
                <th scope="col">Idempotency key</th>
                <th scope="col">Created</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($rows as $row) : ?>
                <?php
                $productId = (int) $row['product_id'];
                $title = get_the_title($productId);
                $variations = array_filter(explode(',', (string) $row['variation_ids']));
                ?>
                <tr>
                    <td>
                        <?php if ($title !== '') : ?>
                            <a href="<?php echo esc_url(get_edit_post_link($productId) ?: '#'); ?>">
                                <?php echo esc_html($title); ?>
                            </a>
                        <?php else : ?>
                            <em>#<?php echo esc_html((string) $productId); ?> (deleted)</em>
                        <?php endif; ?>
                    </td>
                    <td><?php echo esc_html((string) count($variations)); ?></td>
                    <td><code class="gop-key"><?php echo esc_html(substr((string) $row['idempotency_key'], 0, 16)); ?>…</code></td>
                    <td><?php echo esc_html((string) $row['created_at']); ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
