<?php
/**
 * The Diagnostics tab: every check, passing or not, plus installation.
 *
 * The dashboard shows only what is wrong, deliberately. This tab is the opposite
 * — the complete list — because when someone is on the phone about a site that
 * "looks fine", the value is in reading out what actually passed.
 */

use GopImport\Admin\Admin;
use GopImport\Admin\Status;
use GopImport\Support\Config;

if (!defined('ABSPATH')) {
    exit;
}

$checks = Status::checks();
$overall = Status::overall($checks);
$configured = Config::exists();

$labels = [
    Status::OK   => 'Pass',
    Status::WARN => 'Warning',
    Status::FAIL => 'Blocking',
];
?>

<div class="gop-panel">
    <h2>System checks</h2>

    <table class="widefat striped gop-table gop-checks">
        <tbody>
        <?php foreach ($checks as $check) : ?>
            <tr>
                <td class="gop-state-cell">
                    <span class="gop-state is-<?php echo esc_attr($check['state']); ?>">
                        <?php echo esc_html($labels[$check['state']] ?? $check['state']); ?>
                    </span>
                </td>
                <th scope="row"><?php echo esc_html($check['label']); ?></th>
                <td><code><?php echo esc_html($check['value']); ?></code></td>
                <td class="gop-hint"><?php echo esc_html($check['hint'] ?? ''); ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<div class="gop-panel">
    <h2>Installation</h2>

    <p class="gop-panel-lede">
        Installs the stored functions and procedures into the database, creates the log
        table, and writes <code>config/config.ini</code>. Safe to run repeatedly — each run
        drops the old routines and installs them again from scratch.
    </p>

    <div class="gop-actions">
        <?php
        Admin::actionButton(
            'install',
            $configured ? 'Reinstall (keep the keys)' : 'Install',
            'button button-primary',
            ['keep_keys' => '1'],
            $configured ? 'Reinstall the stored functions and keep the current api_key/api_secret?' : ''
        );

        if ($configured) {
            Admin::actionButton(
                'install',
                'Reinstall and generate new keys',
                'button',
                ['keep_keys' => '0'],
                'New keys BREAK every connection still using the old pair. Continue?'
            );
        }
        ?>
    </div>
</div>

<?php if (file_exists(dirname(__DIR__, 2) . '/setup.php')) : ?>
    <div class="gop-panel">
        <h2>Tidy up</h2>
        <p class="gop-panel-lede">
            <code>setup.php</code> is only needed for a first install from the command line.
            This screen has replaced it, so leaving it is one unnecessary way in.
        </p>
        <div class="gop-actions">
            <?php
            Admin::actionButton(
                'delete_setup',
                'Delete setup.php',
                'button button-link-delete',
                [],
                'Delete setup.php from the server?'
            );
            ?>
        </div>
    </div>
<?php endif; ?>

<?php if ($overall['state'] === Status::FAIL) : ?>
    <div class="notice notice-error inline gop-inline-notice">
        <p>Something above is blocking — imports will fail until it is fixed.</p>
    </div>
<?php endif; ?>
