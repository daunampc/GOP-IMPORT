<?php
/**
 * The page shell: heading, notice, tabs.
 *
 * @var string $tab
 * @var array<string,string> $tabs
 * @var array{type:string,message:string,log:array<int,string>}|null $notice
 */

use GopImport\Admin\Admin;

if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="wrap gop-import">
    <div class="gop-head">
        <h1>
            GOP_IMPORT
            <span class="gop-version">v<?php echo esc_html(GOP_IMPORT_VERSION); ?></span>
        </h1>
        <p class="gop-lede">
            A high-speed WooCommerce import API that writes straight to MySQL. This screen
            installs it and watches it; publishing products is done from the managing app.
        </p>
    </div>

    <?php if ($notice !== null) : ?>
        <div class="notice notice-<?php echo $notice['type'] === 'error' ? 'error' : 'success'; ?>">
            <p><?php echo esc_html($notice['message']); ?></p>
            <?php if (!empty($notice['log'])) : ?>
                <details>
                    <summary>Details</summary>
                    <ul class="gop-log">
                        <?php foreach ($notice['log'] as $line) : ?>
                            <li><?php echo esc_html($line); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </details>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <?php
    /*
     * THE ACTIVATION MODAL.
     *
     * Until this installation is activated there is exactly one thing to do on this
     * screen, so it is the only thing offered: the key form, over a dimmed page.
     * Everything else — install, keys, maintenance, logs — is withheld, because none
     * of it does anything useful while the API refuses every call.
     *
     * It is NOT a lock-out. The form is right here and the administrator can always
     * reach it; what is removed is the ability to wander around a plugin that cannot
     * work yet and wonder why nothing happens.
     */
    if (!\GopImport\License\License::verdict()['allowed']) {
        require __DIR__ . '/modal-activate.php';

        return;
    }
    ?>

    <nav class="nav-tab-wrapper gop-tabs">
        <?php foreach ($tabs as $slug => $label) : ?>
            <a href="<?php echo esc_url(Admin::tabUrl($slug)); ?>"
               class="nav-tab <?php echo $tab === $slug ? 'nav-tab-active' : ''; ?>">
                <?php echo esc_html($label); ?>
            </a>
        <?php endforeach; ?>
    </nav>

    <div class="gop-tab-body">
        <?php require __DIR__ . "/tab-$tab.php"; ?>
    </div>
</div>
