<?php
/** The Maintenance tab: repairing the consequences of writing straight to the database. */

use GopImport\Admin\Admin;

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="gop-panel">
    <h2>Clear WooCommerce transients</h2>

    <p class="gop-panel-lede">
        The plugin writes straight to the database, so WooCommerce never clears its own
        cache. If prices or stock look wrong after an import, run this.
    </p>

    <div class="gop-actions">
        <?php Admin::actionButton('clear_transients', 'Clear transients', 'button button-primary'); ?>
    </div>
</div>

<div class="gop-panel">
    <h2>Recalculate variable prices</h2>

    <p class="gop-panel-lede">
        A variable product stores its lowest and highest price in
        <code>wc_product_meta_lookup</code>. That range is widened variation by variation
        during an import, so it can end up wrong if an import failed partway through.
        This recalculates every one of them.
    </p>

    <div class="gop-actions">
        <?php
        Admin::actionButton(
            'fix_prices',
            'Recalculate min/max price',
            'button',
            [],
            'Rescan every variable product. On a large catalogue this can take a few minutes. Continue?'
        );
        ?>
    </div>
</div>
