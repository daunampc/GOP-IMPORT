<?php
/**
 * The dashboard.
 *
 * Ordered by what an operator needs first when something is wrong:
 *
 *  1. ONE sentence saying whether imports can happen at all. Derived from the
 *     same checks as the diagnostics tab, so the headline and the detail can
 *     never disagree.
 *  2. The numbers — what this plugin has actually done.
 *  3. Anything failing, in full, with what to do about it. Nothing that passed:
 *     a wall of green ticks is where a red cross goes to hide.
 *  4. The connection details, because wiring the managing app up is the next
 *     thing anyone does after installing.
 *  5. Recent activity, as evidence the numbers above are real.
 */

use GopImport\Admin\Actions;
use GopImport\Admin\Admin;
use GopImport\Admin\Status;
use GopImport\Support\Config;

if (!defined('ABSPATH')) {
    exit;
}

$checks = Status::checks();
$overall = Status::overall($checks);
$summary = Status::summary();
$configured = Config::exists();
$mismatch = Status::directoryMismatch();

$problems = array_values(array_filter(
    $checks,
    static fn (array $check): bool => $check['state'] !== Status::OK
));

$recent = $configured ? Status::recentImports(8) : [];
?>

<div class="gop-banner is-<?php echo esc_attr($overall['state']); ?>">
    <span class="gop-banner-dot" aria-hidden="true"></span>
    <div>
        <strong><?php echo esc_html($overall['title']); ?></strong>
        <p><?php echo esc_html($overall['detail']); ?></p>
    </div>
    <?php if (!$configured) : ?>
        <div class="gop-banner-action">
            <?php Admin::actionButton('install', 'Install now', 'button button-primary'); ?>
        </div>
    <?php endif; ?>
</div>

<?php if ($mismatch !== null) : ?>
    <div class="notice notice-warning inline gop-inline-notice">
        <p>
            <strong>This plugin's directory is named <code><?php echo esc_html($mismatch); ?></code>.</strong>
            The managing app builds its API URLs as
            <code>wp-content/plugins/gop-import</code>, so it will get a 404 from this
            site. Either rename the directory to <code>gop-import</code>, or paste the
            base URL below into the app's &ldquo;Plugin base URL override&rdquo; field.
        </p>
    </div>
<?php endif; ?>

<!-- ------------------------------------------------------------- the numbers -->

<div class="gop-cards">
    <?php
    Admin::card(
        'Products imported',
        Admin::number($summary['products']),
        $configured ? 'since installation' : 'not installed yet'
    );
    Admin::card('Variations created', Admin::number($summary['variations']), 'across those products');
    Admin::card('Imported today', Admin::number($summary['today']), 'server date');
    Admin::card('Last 7 days', Admin::number($summary['week']));
    Admin::card(
        'Last import',
        $summary['last'] === null
            ? null
            : human_time_diff(strtotime($summary['last']), current_time('timestamp')) . ' ago',
        $summary['last'] ?? ''
    );
    Admin::card('Plugin', 'v' . GOP_IMPORT_VERSION, 'PHP ' . PHP_VERSION);
    ?>
</div>

<!-- ------------------------------------------------------ what needs attention -->

<?php if ($problems !== []) : ?>
    <div class="gop-panel">
        <h2>Needs attention</h2>
        <p class="gop-panel-lede">
            Only what is not right. Everything that passed is on the Diagnostics tab —
            a wall of green ticks is where a red cross goes to hide.
        </p>
        <table class="widefat striped gop-table">
            <tbody>
            <?php foreach ($problems as $check) : ?>
                <tr>
                    <td class="gop-state-cell">
                        <span class="gop-state is-<?php echo esc_attr($check['state']); ?>">
                            <?php echo $check['state'] === Status::FAIL ? 'Blocking' : 'Warning'; ?>
                        </span>
                    </td>
                    <th scope="row"><?php echo esc_html($check['label']); ?></th>
                    <td><code><?php echo esc_html($check['value']); ?></code></td>
                    <td class="gop-hint"><?php echo esc_html($check['hint'] ?? ''); ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

<!-- --------------------------------------------------------------- connection -->

<div class="gop-columns">
    <div class="gop-panel">
        <h2>Connection</h2>

        <?php if (!$configured) : ?>
            <p class="gop-empty">
                Nothing to connect to yet. Install the plugin and a key pair is generated.
            </p>
        <?php else : ?>
            <?php
            $config = Config::load();
            Admin::copyField(
                'Base URL',
                Status::baseUrl(),
                'Paste this into the managing app if its directory name differs from gop-import.'
            );
            Admin::copyField('API key', (string) $config->get('api_key', ''));
            ?>
            <p class="description">
                The API secret is shown exactly once, at the moment it is created. It has
                to be stored in <code>config.ini</code> in plain text — HMAC needs the real
                value to verify a signature, so there is nothing to hash. That is why
                <code>config.ini</code> is blocked by <code>.htaccess</code> and why the
                secret is not put back on screen at every page load. Lost it? Generate a new
                pair on the Connection tab.
            </p>
        <?php endif; ?>
    </div>

    <div class="gop-panel">
        <h2>Quick actions</h2>
        <div class="gop-actions">
            <?php
            Admin::actionButton(
                'install',
                $configured ? 'Reinstall (keeps the keys)' : 'Install',
                'button button-primary'
            );

            if ($configured) {
                Admin::actionButton(
                    'clear_transients',
                    'Clear WooCommerce transients',
                    'button',
                    [],
                    'Clear WooCommerce\'s cached transients on this site?'
                );
                Admin::actionButton(
                    'fix_prices',
                    'Recalculate variable prices',
                    'button',
                    [],
                    'Recalculate the min/max price of every variable product?'
                );
            }

            if (file_exists(dirname(__DIR__, 2) . '/setup.php')) {
                Admin::actionButton(
                    'delete_setup',
                    'Delete setup.php',
                    'button button-link-delete',
                    [],
                    'Delete setup.php from the server? Installation stays available from this screen.'
                );
            }
            ?>
        </div>
        <p class="description">
            Reinstalling keeps the existing API key and secret, so the managing app does
            not lose its connection. Rotating the keys is a separate, explicit action on
            the Connection tab.
        </p>
    </div>
</div>

<!-- ----------------------------------------------------------- recent activity -->

<div class="gop-panel">
    <h2>Recent imports</h2>

    <?php if ($recent === []) : ?>
        <p class="gop-empty">
            <?php echo $configured
                ? 'Nothing has been imported yet. The managing app writes a row here for every product it creates.'
                : 'Not installed, so there is no log to read.'; ?>
        </p>
    <?php else : ?>
        <table class="widefat striped gop-table">
            <thead>
            <tr>
                <th scope="col">Product</th>
                <th scope="col">Variations</th>
                <th scope="col">Idempotency key</th>
                <th scope="col">Created</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($recent as $row) : ?>
                <?php
                $productId = (int) ($row['product_id'] ?? 0);
                $variationIds = trim((string) ($row['variation_ids'] ?? ''));
                $variationCount = $variationIds === '' ? 0 : count(explode(',', $variationIds));
                ?>
                <tr>
                    <td>
                        <?php if ($productId > 0) : ?>
                            <a href="<?php echo esc_url(get_edit_post_link($productId) ?: '#'); ?>">
                                #<?php echo esc_html((string) $productId); ?>
                            </a>
                            <span class="gop-muted"><?php echo esc_html(get_the_title($productId) ?: ''); ?></span>
                        <?php else : ?>
                            <span class="gop-muted">—</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo esc_html((string) $variationCount); ?></td>
                    <td><code class="gop-key"><?php echo esc_html((string) ($row['idempotency_key'] ?? '')); ?></code></td>
                    <td><?php echo esc_html((string) ($row['created_at'] ?? '')); ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>

        <p class="description">
            <a href="<?php echo esc_url(Admin::tabUrl('logs')); ?>">See the full log</a> —
            these rows are what makes re-importing the same file safe: a matching key
            returns the existing product instead of creating a second one.
        </p>
    <?php endif; ?>
</div>

<?php
// The secret is flashed exactly once, immediately after it is generated.
$secret = Actions::takeSecret();
if ($secret !== null) :
    ?>
    <div class="gop-panel gop-secret">
        <h2>Save the API secret now</h2>
        <p>
            This is the only time it will be shown. Paste it into the managing app before
            leaving this page.
        </p>
        <?php Admin::copyField('API secret', $secret); ?>
    </div>
<?php endif; ?>
