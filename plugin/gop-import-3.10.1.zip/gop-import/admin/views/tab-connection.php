<?php
/** The Connection tab: what the managing app has to be told. */

use GopImport\Admin\Actions;
use GopImport\Admin\Admin;
use GopImport\Admin\Status;
use GopImport\Support\Config;

if (!defined('ABSPATH')) {
    exit;
}

$secret = Actions::takeSecret();

if (!Config::exists()) {
    echo '<div class="notice notice-warning inline gop-inline-notice"><p>Not installed yet. '
        . 'Go to the <strong>Dashboard</strong> tab and press Install first.</p></div>';
    return;
}

Config::setInstance(null);
$config = Config::load();
$apiKey = (string) $config->get('api_key', '');
$mismatch = Status::directoryMismatch();
?>

<div class="gop-panel">
    <h2>Connection details</h2>

    <p class="gop-panel-lede">
        Put these into the managing app under <em>Sites &rarr; Connect a site</em>.
    </p>

    <?php
    Admin::copyField('Site URL', untrailingslashit(site_url()));
    Admin::copyField(
        'Plugin base URL',
        Status::baseUrl(),
        $mismatch === null
            ? 'Only needed if the app cannot reach the default path.'
            : 'REQUIRED here: this plugin\'s directory is named "' . $mismatch . '", not "gop-import", '
              . 'so paste this into the app\'s "Plugin base URL override" field.'
    );
    Admin::copyField('API key', $apiKey);
    ?>

    <?php if ($secret !== null) : ?>
        <div class="notice notice-success inline gop-secret">
            <p><strong>API secret — shown this once only.</strong> Copy it now.</p>
            <?php Admin::copyField('API secret', $secret); ?>
        </div>
    <?php else : ?>
        <div class="gop-field">
            <label>API secret</label>
            <input type="text" readonly value="••••••••••••••••••••••••" disabled>
            <p class="description">
                The secret is shown exactly once, when it is created. If it has been lost,
                generate a new pair below — putting it back on screen at every page load
                would widen the leak surface and add nothing.
            </p>
        </div>
    <?php endif; ?>
</div>

<div class="gop-panel">
    <h2>Generate a new key pair</h2>

    <p class="gop-panel-lede">
        For when a key may have been exposed. Every connection still using the old pair
        starts getting 401 immediately afterwards.
    </p>

    <div class="gop-actions">
        <?php
        Admin::actionButton(
            'regenerate_keys',
            'Generate a new key pair',
            'button',
            [],
            'The old keys stop working at once. Continue?'
        );
        ?>
    </div>
</div>
