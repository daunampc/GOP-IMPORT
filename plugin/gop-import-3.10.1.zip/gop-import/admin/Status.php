<?php

namespace GopImport\Admin;

use GopImport\Bootstrap;
use GopImport\Setup\Installer;
use GopImport\Support\Config;
use GopImport\Support\SqlRewriter;

/**
 * Everything the dashboard reads.
 *
 * Every check is wrapped in try/catch, because the status screen has to render
 * EVEN WHEN the database is broken — that is precisely the moment somebody needs
 * it. A dashboard that white-screens when the thing it monitors fails is worse
 * than no dashboard.
 */
final class Status
{
    public const OK = 'ok';
    public const WARN = 'warn';
    public const FAIL = 'fail';

    /**
     * The single sentence at the top of the dashboard.
     *
     * Derived from the checks rather than guessed at separately, so the headline
     * and the detail below it can never disagree.
     *
     * @param array<int,array{label:string,state:string,value:string,hint?:string}> $checks
     * @return array{state:string, title:string, detail:string}
     */
    public static function overall(array $checks): array
    {
        $failed = array_values(array_filter($checks, static fn (array $c): bool => $c['state'] === self::FAIL));
        $warned = array_values(array_filter($checks, static fn (array $c): bool => $c['state'] === self::WARN));

        if ($failed !== []) {
            return [
                'state'  => self::FAIL,
                'title'  => count($failed) === 1
                    ? 'One thing is stopping imports'
                    : count($failed) . ' things are stopping imports',
                'detail' => $failed[0]['label'] . ' — ' . ($failed[0]['hint'] ?: $failed[0]['value']),
            ];
        }

        if ($warned !== []) {
            return [
                'state'  => self::WARN,
                'title'  => 'Working, with ' . count($warned) . ' thing' . (count($warned) === 1 ? '' : 's') . ' worth attending to',
                'detail' => $warned[0]['label'] . ' — ' . ($warned[0]['hint'] ?: $warned[0]['value']),
            ];
        }

        return [
            'state'  => self::OK,
            'title'  => 'Ready to receive imports',
            'detail' => 'Every check passed. The API is installed, reachable and authenticated.',
        ];
    }

    /**
     * @return array<int,array{label:string, state:string, value:string, hint?:string}>
     */
    public static function checks(): array
    {
        $checks = [];

        $phpOk = version_compare(PHP_VERSION, '8.1', '>=');
        $checks[] = [
            'label' => 'PHP version',
            'state' => $phpOk ? self::OK : self::FAIL,
            'value' => PHP_VERSION,
            'hint'  => $phpOk ? '' : 'The plugin requires PHP 8.1 or newer.',
        ];

        $mysqli = extension_loaded('mysqli');
        $checks[] = [
            'label' => 'mysqli extension',
            'state' => $mysqli ? self::OK : self::FAIL,
            'value' => $mysqli ? 'Enabled' : 'Not enabled',
            'hint'  => $mysqli ? '' : 'Enable `mysqli` under PHP Extensions in your hosting panel.',
        ];

        $configExists = Config::exists();
        $configDir = dirname(Config::path());
        $configWritable = is_writable($configDir);

        $checks[] = [
            'label' => 'config/ is writable',
            'state' => $configWritable ? self::OK : self::FAIL,
            'value' => $configWritable ? 'Yes' : 'No',
            'hint'  => $configWritable ? '' : "Make $configDir writable.",
        ];

        $checks[] = [
            'label' => 'config.ini',
            'state' => $configExists ? self::OK : self::WARN,
            'value' => $configExists ? 'Present' : 'Missing',
            'hint'  => $configExists ? '' : 'Press "Install / reinstall" below.',
        ];

        $logsDir = dirname(__DIR__) . '/logs';
        $logsWritable = is_dir($logsDir) && is_writable($logsDir);
        $checks[] = [
            'label' => 'logs/ is writable',
            'state' => $logsWritable ? self::OK : self::WARN,
            'value' => $logsWritable ? 'Yes' : 'No',
            'hint'  => $logsWritable ? '' : "Errors cannot be logged. Make $logsDir writable.",
        ];

        $setupPath = dirname(__DIR__) . '/setup.php';
        $setupExists = file_exists($setupPath);
        $checks[] = [
            'label' => 'setup.php',
            'state' => $setupExists ? self::WARN : self::OK,
            'value' => $setupExists ? 'Still on the server' : 'Deleted',
            // Anyone who can delete config.ini can force a fresh key pair for
            // themselves, which is why leaving this here matters.
            'hint'  => $setupExists
                ? 'Delete it once installation is done — leaving it is an unnecessary way in.'
                : '',
        ];

        return array_merge($checks, self::databaseChecks());
    }

    /**
     * @return array<int,array{label:string, state:string, value:string, hint?:string}>
     */
    private static function databaseChecks(): array
    {
        if (!extension_loaded('mysqli')) {
            return [];
        }

        try {
            $installer = new Installer(Bootstrap::FN_PREFIX);
            $credentials = Installer::fromWordPress();
            $connection = $installer->connect($credentials);

            $missing = $installer->missingRoutines($connection);
            $total = count(SqlRewriter::ROUTINES);

            $checks = [[
                'label' => 'Database connection',
                'state' => self::OK,
                'value' => $connection->get_server_info(),
            ], [
                'label' => 'Stored functions',
                'state' => $missing === [] ? self::OK : self::FAIL,
                'value' => ($total - count($missing)) . " / $total installed",
                'hint'  => $missing === []
                    ? ''
                    : 'Missing: ' . implode(', ', array_slice($missing, 0, 6))
                        . (count($missing) > 6 ? '…' : ''),
            ]];

            $table = $credentials['table_prefix'] . 'tsd_import_log';
            $hasTable = $connection->query(
                "SELECT 1 FROM information_schema.TABLES
                 WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = '" . $connection->real_escape_string($table) . "' LIMIT 1"
            );

            $exists = $hasTable && $hasTable->num_rows > 0;

            $checks[] = [
                'label' => 'Import log table',
                'state' => $exists ? self::OK : self::WARN,
                'value' => $exists ? $table : 'Not created',
                'hint'  => $exists
                    ? ''
                    : 'Without this table, duplicate protection (idempotency) does not work.',
            ];

            return $checks;
        } catch (\Throwable $exception) {
            return [[
                'label' => 'Database connection',
                'state' => self::FAIL,
                'value' => 'Failed',
                'hint'  => $exception->getMessage(),
            ]];
        }
    }

    /**
     * The numbers on the dashboard's cards.
     *
     * Read from the import log, which is the only record this plugin keeps of its
     * own work. Every figure falls back to null rather than 0 when it cannot be
     * read: "we do not know" and "none" are different answers, and showing 0 for
     * the first is a lie the operator will act on.
     *
     * @return array{products:?int, today:?int, week:?int, last:?string, variations:?int}
     */
    public static function summary(): array
    {
        $empty = ['products' => null, 'today' => null, 'week' => null, 'last' => null, 'variations' => null];

        global $wpdb;

        if (!isset($wpdb)) {
            return $empty;
        }

        // Built from WordPress's own prefix, so it is safe to interpolate; no
        // user input reaches this string.
        $table = $wpdb->prefix . 'tsd_import_log';

        $exists = $wpdb->get_var(
            $wpdb->prepare('SHOW TABLES LIKE %s', $table)
        );

        if ($exists !== $table) {
            return $empty;
        }

        $row = $wpdb->get_row(
            "SELECT
                COUNT(*)                                                        AS products,
                SUM(DATE(created_at) = CURDATE())                               AS today,
                SUM(created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY))              AS week,
                MAX(created_at)                                                 AS last
             FROM `$table`",
            ARRAY_A
        );

        if (!is_array($row)) {
            return $empty;
        }

        // `variation_ids` is a comma-separated list, so the count of variations
        // is the number of commas plus one, per non-empty row.
        $variations = $wpdb->get_var(
            "SELECT COALESCE(SUM(
                CHAR_LENGTH(variation_ids) - CHAR_LENGTH(REPLACE(variation_ids, ',', '')) + 1
             ), 0)
             FROM `$table`
             WHERE variation_ids IS NOT NULL AND variation_ids <> ''"
        );

        return [
            'products'   => (int) $row['products'],
            'today'      => (int) $row['today'],
            'week'       => (int) $row['week'],
            'last'       => $row['last'] !== null ? (string) $row['last'] : null,
            'variations' => $variations === null ? null : (int) $variations,
        ];
    }

    /** The address the managing app has to be pointed at. */
    public static function baseUrl(): string
    {
        return rtrim(plugins_url('', dirname(__DIR__) . '/gop-import.php'), '/');
    }

    /**
     * True when the plugin's directory is not the name the managing app expects.
     *
     * The app builds every API URL as wp-content/plugins/gop-import, so a
     * directory called anything else answers 404 until either the folder is
     * renamed or the app's "Plugin base URL override" is filled in. Saying so
     * here turns a mystifying 404 into a sentence.
     */
    public static function directoryMismatch(): ?string
    {
        $actual = basename(dirname(__DIR__));

        if ($actual === 'gop-import' || str_starts_with($actual, 'gop-import_')) {
            return null;
        }

        return $actual;
    }

    /** @return array<int,array<string,mixed>> the most recent import-log rows */
    public static function recentImports(int $limit = 50): array
    {
        global $wpdb;

        $table = $wpdb->prefix . 'tsd_import_log';

        // $table is built from WordPress's prefix so it is safe to interpolate;
        // anything user-supplied still goes through prepare().
        $rows = $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM `$table` ORDER BY id DESC LIMIT %d", $limit),
            ARRAY_A
        );

        return is_array($rows) ? $rows : [];
    }
}
