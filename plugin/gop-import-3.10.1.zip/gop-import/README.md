# GOP_IMPORT

A high-speed WooCommerce product import API. Writes straight to MySQL, bypassing
the WordPress runtime — the same model as WooFullControl v2, but with
authentication, transactions and batching.

## Why it is fast

Saving one variable product with 20 variations through WooCommerce costs roughly
500–1500 queries: `WC_Product::save()` goes through the data store, each
`update_post_meta` is its own SELECT+INSERT pair, and then
`WC_Product_Variable::sync()` reloads every variation.

Here one parent product is **one** `SELECT tsd_create_product(...)` call. Every
INSERT — post, attachment, postmeta, term, lookup — happens inside MySQL. The core
trick is packing arrays into strings (`;` for images, `<->` for meta) and letting
the stored function split them with `SUBSTRING_INDEX`, so a function with a fixed
parameter list still accepts any number of images and any number of meta rows.

### Where the gain comes from

| | v2 | GOP_IMPORT |
|---|---|---|
| HTTP requests for 50 products | 50 | **1** |
| TCP handshake + MySQL auth | every request | **once, persistent connection** |
| Statement preparation | no prepared statements | **prepare once, execute N times** |
| Resolving categories and tags | every category of every product | **cached per request** |
| Downloading images | sequential, no timeout | **8 in parallel, with timeouts** |
| Clearing transients | per product | **once for the whole run** |

A concrete example: 50 products sharing 3 categories. v2 calls
`create_category` 150 times; here it is 3, and everything after that comes from an
in-memory cache.

On images: 20 images at 400ms each is 8 seconds in sequence, and about 1 second
across 8 lanes.

> The round-trip numbers above are counted from the code. Real timings depend on
> the host, the latency to wherever the images live, and the MySQL configuration —
> measure on your own site using the `elapsed_ms` field in the response.

### What is still skipped (as in v2 — this is the price of the speed)

- **WordPress hooks and filters.** No `save_post`, no
  `woocommerce_new_product`. Which means Yoast/RankMath do not compute an SEO
  score, caching plugins do not purge themselves, a Google Shopping feed does not
  update itself, and no post revisions are created.
- **Thumbnail generation.** WordPress normally produces 5–8 sizes per image with
  GD or Imagick, at 0.3–2 seconds of CPU each. Here only the original file is
  stored. One difference from v2: for a LOCAL image this plugin writes **real**
  `_wp_attachment_metadata` — dimensions read with `getimagesize` — rather than a
  fake string, so WordPress knows the width and height and the Media library
  displays properly. srcset still points at the original.
- **`wp_unique_post_slug()`.** A parent product's slug is written as given, with
  no site-wide uniqueness check.
- **Exact term counts.** Uses `count = count + 1` rather than recounting with
  COUNT.

After a run, call `POST /maintenance/clear-transients` once.

## The dashboard

Once activated, open **GOP_IMPORT** in the left-hand menu. Five tabs:

| Tab | What it is for |
|---|---|
| **Dashboard** | One sentence saying whether imports can happen at all, then the numbers — products imported, variations created, today, the last 7 days, when the last import was. Below that, only what needs attention, the connection details, and recent activity. |
| **Connection** | The site URL, plugin base URL and API key to copy into the managing app, each with a copy button. Generating a new key pair lives here too. |
| **Maintenance** | Clear WooCommerce transients; recalculate min/max price for variable products. |
| **Import log** | The 50 most recent imports, linking straight to each product's edit screen. |
| **Diagnostics** | Every check, passing or not, plus installation. The dashboard shows only problems; this is the complete list, for when somebody is on the phone about a site that "looks fine". |

All of it loads only inside wp-admin — the API in `index.php` does not go through
WordPress, so the interface costs the import path nothing.

Every button carries a nonce and checks the `manage_options` capability. Without
the nonce, any website could trick a logged-in administrator into following a
hidden link and reinstalling every stored function.

The API secret is **shown exactly once**, immediately after it is created. It has
to live in `config.ini` in plain text — HMAC needs the real value to verify a
signature, so there is nothing to hash — which is why `config.ini` is blocked by
`.htaccess` and why the secret is not put back on screen at every page load. If it
is lost, generate a new pair.

## Installing

**Option 1 — through wp-admin.** Plugins → Add New → Upload Plugin → choose
`dist/gop-import-<version>.zip` → Install Now → Activate.

Activation only puts the directory under WordPress's management; the API itself
does not run through WordPress. After activating, a notice prompts you to install,
with a link on the plugin's own row in the Plugins list.

**Option 2 — upload by hand** (FTP, File Manager, SSH): unpack into
`wp-content/plugins/`.

Then, either way:

1. Make `config/` and `logs/` writable.
2. Open **GOP_IMPORT → Dashboard** and press **Install**.
3. You land on the **Connection** tab — **save `api_secret` now**, it is shown once.
4. Go to **Diagnostics** and press **Delete setup.php**.

To install across many sites from a script, use `setup.php` from the CLI:

```bash
php wp-content/plugins/gop-import/setup.php
```

Or call the admin screen's own handler through WP-CLI:

```bash
wp eval '$_REQUEST["_wpnonce"]=$_POST["_wpnonce"]=wp_create_nonce("gpm_tsd_install"); wp_set_current_user(1); \GopImport\Admin\Actions::install();'
```

Both paths share `src/Setup/Installer.php`, so one cannot be right while the other
is wrong.

The directory name after unpacking is whatever you called the package (`gop-import`
by default). **If it is not `gop-import`, the managing app will get a 404** until
you either rename the directory or fill in its "Plugin base URL override" field.
The dashboard says so explicitly when it detects a mismatch.

### Requirements

PHP 8.1 or newer with the `mysqli` extension. Without `mysqli`, both `setup.php`
and the API report it clearly instead of dying with a fatal error.

Over HTTP, `setup.php` only runs while `config/config.ini` does not exist. To
reinstall, delete that file over FTP/SSH — or use the dashboard.

### If MySQL reports error 1419

The host has binary logging on and requires SUPER to create a stored function. Ask
them to run:

```sql
SET GLOBAL log_bin_trust_function_creators = 1;
```

### If you are on Nginx

Nginx does not read `.htaccess`. Add this to the server block to block the
internal directories:

```nginx
location ~ ^/wp-content/plugins/gop-import/(config|logs|sql|src|tests)/ {
    deny all;
}
```

Note that `admin/assets/admin.css` must stay reachable — it is the dashboard's
stylesheet, fetched by the browser like any other asset. The rule above does not
touch `admin/`, which is deliberate.

## Authentication

Every request carries three headers:

| Header | Contents |
|---|---|
| `X-TSD-Key` | `api_key` |
| `X-TSD-Timestamp` | Unix epoch seconds |
| `X-TSD-Signature` | `hash_hmac('sha256', "METHOD\nROUTE\nTIMESTAMP\nBODY", api_secret)` |

The header names keep their original spelling on purpose: they are the contract
with every build already installed on a site, and renaming them would break all of
them at once for no visible gain. The same is true of the `tsd_` prefix on the
stored functions.

Signing the body means the payload cannot be altered in transit; a timestamp more
than 300 seconds out is rejected, so a request cannot be replayed. Signatures are
compared with `hash_equals`, in constant time.

`api_secret` **belongs on the server only**. Calling this API straight from a
browser would mean embedding the secret in client-side JavaScript, and this whole
authentication layer would then be decoration — call it from a Next.js Route
Handler instead.

## The API

Everything goes through `index.php`. The route travels either as
`?route=/products/batch` or as PATH_INFO when mod_rewrite is on.

### `GET /health`

Checks the connection and whether every stored function is installed. Answers 503
when any are missing.

### `POST /products/batch`

At most 50 products per request.

```json
{ "products": [ { "name": "T-shirt", "price": 199000, "images": ["https://..."] } ] }
```

Each product runs in its own transaction — one bad row does not take the batch
down, and no orphaned parent is left behind. The response reports every row:

```json
{
  "total": 2, "succeeded": 1, "failed": 1, "elapsed_ms": 412.7,
  "results": [
    { "index": 0, "ok": true, "product_id": 12345, "variation_ids": [12346] },
    { "index": 1, "ok": false, "error": { "code": "missing_name", "message": "..." } }
  ]
}
```

HTTP 200 when everything succeeded, **207** when individual rows failed, 400 for a
bad payload.

Send an `idempotency_key` with each product to make resending safe: on a key it has
seen, the plugin returns the existing `product_id` with `"deduplicated": true`
rather than creating a duplicate.

### `POST /products/lookup`

Finds the products a filter matches, and deletes nothing. Kept separate from the
delete command so an operator confirms the list they were actually shown.

Two modes. By default it returns one page of products **with a summary** — sku,
price, variation count, categories — capped at 500, because that summary is what
makes a page expensive. With `"ids_only": true` it returns ids alone, up to
100,000, which is what lets one removal cover a whole selection instead of its
first 500 products. `truncated` says so honestly when even that ceiling is hit.

### `POST /products/update`

Changes products that are **already on the site**. At most 50 rows per request,
same envelope and same 207-with-per-row-results answer as `/products/batch`.

**Only fields present in a row are written.** This is the property the whole route
rests on, not an implementation detail:

| On the wire | Meaning |
|---|---|
| the key is absent | leave the field exactly as it is |
| `"description": ""` | clear it, on purpose |
| `"description": null` | **refuse the row** (`null_field`) — never guessed at |

So `{"sku": "AO-1", "price": 219000}` changes the price and leaves the
description, the images, the categories and the stock untouched. Anything else
would turn a price sync into catalogue destruction. `null` is refused rather than
read as `""` because two client libraries serialise an empty field two different
ways, and guessing wrong erases a product description.

Rows are matched by `idempotency_key` when one is given, otherwise by `sku`. A SKU
matching **more than one** product is an error for that row (`ambiguous_sku`, with
the ids named) and touches neither — guessing which was meant is how a price lands
on the wrong product with nobody able to trace it.

Writable on a product: `name`, `sku`, `slug`, `description`, `short_description`,
`status`, `price`, `regular_price`, `sale_price`, `stock`, `instock`,
`categories`, `tags`, `shipping_class`, `custom_meta`. A **variation** matched by
its own SKU accepts `sku`, `description`, `status`, the three prices, `stock` and
`instock` — and **keeps its `variation_id`**, because deleting and recreating
variations breaks every order line pointing at them.

Deliberately not writable, each for its own reason: `images` (creating and
deleting attachments changes image ids), `type` and `attributes` and `variations`
(rebuilding the variation set changes variation ids). A field outside the list is
an **error**, not a silent no-op — ignoring it would leave the caller believing
the images had been replaced.

Three things happen that are easy to leave out and make the difference between
"the price changed" and "the shop shows the new price":

- `_price` is **derived**, never taken as an independent value: it is the sale
  price while a sale is on and the regular price otherwise, recomputed from
  whichever of the two the request did not carry. So `{"sale_price": ""}` ends a
  sale and puts `_price` back to the regular price already on the product.
- `wc_product_meta_lookup` is rewritten. That table is what category pages, price
  sorting and price filters read, so a change that stops at `postmeta` shows the
  new price on the product page and the old one everywhere a shopper looks.
- the product's WooCommerce transients are cleared, and a variation's price change
  recomputes its parent's min/max **by aggregate** — so a price that came DOWN
  lowers the advertised floor instead of leaving it where it was.

Each row reports what actually moved, and what it moved from:

```json
{
  "index": 0, "ok": true, "product_id": 8412, "sku": "AO-1",
  "is_variation": false, "parent_id": null,
  "changed": {
    "regular_price": { "from": "199000", "to": "219000" },
    "price":         { "from": "199000", "to": "219000" }
  }
}
```

A field appears only when the stored value genuinely differed, so re-sending the
same price answers `ok` with an empty `changed` — which is what makes "340
products, 340 prices changed, 0 descriptions touched" countable.

### `POST /products/exists`

```json
{ "skus": ["AO-1", "AO-2"] }
```

Which of these SKUs are already here. At most 1,000 per request. Answers `found`
— each with `product_id`, `name`, `status`, `type`, `price`, `regular_price`,
`sale_price` — and `missing`.

Cheap, and the point is that it can be asked **before** a run. Nothing used to ask
it, so a file whose SKUs already existed imported as a second set of products (a
different idempotency key means a different product) and the operator found out
afterwards.

### `POST /products/delete`

Takes a list of product ids — never a filter, because a filter can match
differently between looking and pressing. At most 50 per request. Reports rows
removed per table, so "nothing was orphaned" is evidence rather than a claim.

### `POST /images/upload`

The body is **framed**, not JSON:

```
{"images":[{"source_url":"https://cdn.com/a.jpg","content_type":"image/jpeg","length":184320}]}
<184320 raw bytes><the next image's raw bytes>…
```

One JSON manifest, one newline, then the images end to end. Writes them into
`wp-content/uploads/gop-import/<2 hex>/` and returns local URLs. At most 40 per
request and **31 MB** of image in total.

**Why not JSON with the bytes base64 encoded**, which is what 3.9.0 did: base64 costs
a third of the wire on every image-heavy request — 2.00 MB of JPEG becomes 2.67 MB,
measured — plus an encode on one side and a decode on the other, and it capped a
single image at 22 MB because 4/3 of anything larger will not fit in the body. Gzip
is not the answer either: a JPEG is already compressed, so gzipping its base64 only
removes the padding base64 just added, at ~92ms of CPU per 2 MB on each side.

**Why not multipart/form-data**, which is what a browser would send: PHP parses it
into `$_FILES` and leaves `php://input` **empty**. `Auth::verify` signs the body it
reads from there, so every request would fail authentication. The framing above keeps
the HMAC over every byte — images included — with no change to the signing scheme and
none to any key already installed on a site.

The lengths must add up to exactly what arrived, and that is checked before anything
is written. Offsets are cumulative, so one wrong length shifts every image after it
and each would be written from the middle of its neighbour: one refusal is better
than a directory of quietly corrupt files.

**This plugin makes no outbound network call.** That was the change in 3.9.0, which
replaced `POST /images/fetch` — a route that took a list of URLs and fetched them here
with `curl_multi`. Forty images across eight lanes at a 20 second timeout is up to 100
seconds of a PHP-FPM worker held open, and the managing app ran up to 32 such requests
at once, so an import could exhaust the pool and hand real shoppers a 502. The work
did not belong on the shop's own server.

Three properties follow from the bytes arriving in the request:

- **Idempotent.** The path is `gop-import/<2 hex>/<slug>-<8 hex of sha256(source_url)>.<ext>`
  — a pure function of the source URL — so the same image always lands in the same
  place. A retried batch overwrites nothing and leaves no `-1`, `-2` duplicates, which
  the pre-3.9.0 build did. A file whose size disagrees with the bytes sent IS
  rewritten, because that is a truncated file from a run killed midway.
- **The filename is always the server's decision.** There is no `file_name` input at
  all: a client-supplied name would make the path a function of the request, and
  `/images/present` — which only ever sees a URL — would compute a different path from
  the one the upload wrote to.
- **The bytes are checked, not the label.** A magic-byte table decides what the file
  is. The pre-3.9.0 build trusted the `Content-Type` the remote server declared, so a
  CDN answering 200 with an HTML error page landed in the media library as a `.jpg`.

Refusals: `unframed_body`, `invalid_manifest`, `length_mismatch`, `upload_too_large`,
`image_batch_too_large`. A single bad entry fails on its own and the rest of the
request is still written.

**Why the path is not `YYYY/MM`.** WordPress's own layout is dated, and this one is
not, because a dated path cannot be looked up: the same image re-imported the
following month belongs in a different directory, so nothing can answer "do you
already have this". Being able to answer it is what removes the traffic — see below.
`AttachmentMeta` reads dimensions from wherever the file is, and the media library
displays it normally.

### `POST /images/present`

```json
{ "images": ["https://cdn.com/a.jpg", "https://cdn.com/b.jpg"] }
```

Answers, in order, `{"source_url": …, "url": … | null}` — the local URL if this site
already holds that image, `null` if it does not. At most 200 URLs.

The cheapest route in the plugin and the most valuable one on a re-run. It costs a
handful of `is_file` calls per URL, because the path is a pure function of the source
URL and only the extension has to be guessed at (each of the six allowed ones is
tried). Every URL it answers with is an image the managing app then does **not**
download from its source and does **not** send here. For a catalogue being re-synced
that is most of the traffic of a run.

`null` is always the safe answer: it means "send it". Being wrong that way costs
bandwidth; being wrong the other way would publish a URL serving nothing.

### `GET /terms/{taxonomy}`

`taxonomy` is `product_cat`, `product_tag` or `product_shipping_class`. The
parameter travels in the route so that it is covered by the signature.

### `POST /maintenance/clear-transients`

Call once after a whole run.

### `POST /maintenance/recalculate-prices`

Recomputes the min/max price of every variable product from its variations, and
clears each one's price transient. The same repair as the Maintenance tab's
button, which until now had no HTTP route and so could not be reached from the
managing app.

It matters because the min/max in `wc_product_meta_lookup` is the price a shopper
sees on a category page — the first price they see. Computed by aggregate rather
than by widening comparison, so a variation whose price came down lowers the
range.

## The product payload

The v2 contract is kept unchanged, so existing data still works. The full types are
in [clients/gop-import-client.ts](clients/gop-import-client.ts).

Only `name` is required. With `variations` present, `type` becomes `variable`
automatically. `sale_price` overrides the displayed `price` while `regular_price`
keeps the original. Set `"mode_import": "full_data"` to fill in WooCommerce's
defaults (tax_status, backorders, manage_stock…).

Categories support a hierarchy written with `>`: `"Clothing > T-shirts > Men"`.

## Using it from Next.js

```ts
// app/api/import/route.ts — RUNS ON THE SERVER
import { GopImportClient } from '@/lib/gop-import-client';

const client = new GopImportClient({
  baseUrl: process.env.TSD_BASE_URL!,
  apiKey: process.env.TSD_API_KEY!,
  apiSecret: process.env.TSD_API_SECRET!,
});

export async function POST(request: Request) {
  const { products } = await request.json();
  const results = await client.importProducts(products);
  return Response.json({ results });
}
```

The client splits into batches of 50 itself and translates the indexes back to the
original array, so `results[i]` always corresponds to `products[i]`.

## Running the tests

### Logic tests — no database needed

```bash
php tests/run.php
```

35 tests, no Composer. Covers the slug algorithm, routine renaming inside SQL, the
serialised format of `_product_attributes`, payload normalisation, and the whole
HMAC authentication path.

No PHP on the machine? Use Docker:

```bash
docker run --rm -v "$PWD":/app -w /app php:8.2-cli php tests/run.php
```

### On a real WordPress + WooCommerce

```bash
./tests/wordpress-e2e.sh
```

Stands up a full WordPress plus WooCommerce, installs the plugin through
WordPress's own zip installer, presses the admin screen's "Install" button, calls
the real API, then reads the product back with `wc_get_product()`. This is the only
suite that catches the collation trap described below — neither of the others sees
it.

### Integration tests — a real MySQL

```bash
./tests/integration.sh
```

38 tests. The script stands up MySQL 8 in Docker, loads a minimal WordPress schema
(the 11 tables the stored functions touch), installs the routines, then imports
real products and checks each table: `wp_posts`, `wp_postmeta`, attachments,
hierarchical terms, `wc_product_meta_lookup`, a variable product's min/max price
range, idempotency, rollback when a variation fails, and complete deletion leaving
no row behind. The container is removed on exit.

This is the most important safety net: the logic lives inside stored functions, so
pure PHP tests cannot see a bug in it. Run this suite again whenever WooCommerce
takes a major version.

### A note on collation

This is the biggest trap in writing straight to the database, and it has **two**
layers:

1. **The session's collation.** The connection pins
   `SET NAMES <charset> COLLATE <collate>` to whatever `wp_posts` actually uses.
   Without that step, every comparison against a string literal fails on MySQL 8,
   because the server defaults to `utf8mb4_0900_ai_ci`.

2. **The DATABASE's collation.** MySQL gives a stored function's parameters the
   *database's* default collation at the moment the function is created — not the
   session's. If the database default differs from `wp_posts`, every comparison
   between a parameter and a column fails. In practice it is worse: WordPress
   creates its core tables with `utf8mb4_unicode_520_ci` (it prefers 520 where
   MySQL supports it) while WooCommerce creates its own with the server default —
   two tables in one database, disagreeing.

The install step therefore **must** align them: `ALTER DATABASE` changes the
default (rewrites no data, runs instantly), then `ALTER TABLE` touches only the
tables that actually differ, naming each one in the log. The MySQL account needs
`ALTER`; without it the installer says so clearly at install time rather than
letting it surface during an import.

## Differences from the v2 plugin

| | v2 | GOP_IMPORT |
|---|---|---|
| Authentication | **none, on any endpoint** | HMAC-SHA256, required |
| Arbitrary SQL over HTTP | yes (`add_on.php`) | removed |
| Zip upload and extraction | yes (RCE) | removed |
| SQL parameters | string interpolation | prepared statements |
| Image downloads | SSRF, `verify_peer=false`, client-chosen filenames | internal addresses blocked, TLS verified, server-chosen names |
| Transactions | none | one per product |
| Resending | optional `check_sku`, with a race | idempotency key with a UNIQUE index |
| HTTP status codes | always 200 | 200 / 207 / 400 / 401 / 404 / 500 |
| Directly callable endpoints | every PHP file | `index.php` only |
| Stored routine names | bare (`create_product`) | `tsd_` prefix, so it shares a database with v2 |
| Local image metadata | fake string, no dimensions | read with `getimagesize`, real metadata |
| Deleting products | a stored function that orphaned rows | full clean-out, counted per table |
| Changing a product | delete and reimport, losing the id, reviews and URL | `POST /products/update`, partial, keeping ids |
| Interface | none, `setup.php` by hand | a dashboard in wp-admin: install, keys, maintenance, log, diagnostics |
| Collation alignment | present but optional, easily forgotten | required during install, touching only what differs |
| Tests | none | 35 logic + 81 integration on real MySQL + a full WordPress e2e |

The `tsd_` prefix means this plugin **installs alongside v2 on the same database
without either overwriting the other**. Migration can be gradual.

## Status

**Verified:**

- Lint clean on PHP 8.2, every file.
- Installed, activated, set up through the admin screen's own button, a product
  imported over the API, and **WooCommerce 11.0.1 read it back correctly** on a
  real WordPress 7.0.4 + PHP 8.2: type `variable`, 2 variations, a 199k–259k price
  range, a hierarchical category, the `pa_size` attribute.
- 35 logic tests green.
- 81 integration tests green against a real MySQL 8 (38 before this change): simple
  and variable products created, images becoming attachments, hierarchical
  categories, correct min/max price range, idempotency creating no duplicate, a
  clean rollback when a variation fails, and the `ids_only` lookup returning every
  matching id in one call while the summary cap of 500 stays exactly as it was.
- The 43 new ones cover `/products/update`, `/products/exists`, matching by
  `product_id`, and the server-side name and status search, and the load-bearing one is asserted
  the only way it is worth asserting: a `{sku, price}` update is checked
  field by field for having left the name, slug, description, short description,
  status, stock, stock status, thumbnail, gallery, attachment count and category
  count **exactly** as they were. Verified to have teeth by mutation rather than by
  reading — disabling the price write turns 12 of them red, and writing absent
  fields as empty values (the simpler implementation this route refuses) turns the
  partial-update test red. Also covered: `""` clearing a field while an omitted key
  leaves it, `null` refused, an unsupported field refused with the reason,
  `_price` returning to the regular price when a sale is ended, the lookup table
  and transients carrying the change, a stock of 0 becoming `outofstock` while an
  explicit `instock` still wins, a category swap correcting the count on **both**
  sides, a variation keeping its `variation_id`, a lowered variation lowering the
  parent's advertised floor, `recalculate-prices` repairing a corrupted range, an
  ambiguous SKU touching neither product, a taken SKU and a taken slug refused
  rather than made ambiguous or silently suffixed, and `/products/exists` over a
  mix of present and absent SKUs.
- The dashboard walked in a browser on that real WordPress: banner, cards, the
  needs-attention list, connection fields and diagnostics all render, and the
  stylesheet loads.
- The TypeScript client typechecks clean under `--strict`.

**Fixed in 3.2.0, and worth recording because it had never worked:**

- `clear_woocommeerce_transients` was called as `(0)` from both `index.php` and the
  Maintenance tab. The procedure branches on `IF(_idParent IS NOT null)`, and `0`
  is not NULL — so the statement that actually ran was
  `DELETE FROM wp_options WHERE option_name LIKE '%_0'`. It cleared **no**
  WooCommerce transient (the ten correct statements are in the `ELSE` branch and
  had never run) and it did delete any unrelated option whose name happened to end
  in `_0`. Both call sites now pass `NULL`. The procedure's own signature is
  unchanged, because every installed site already has it.

  `ProductUpdater` does not use that procedure at all: it deletes the ten
  transient names for a product by **exact name**, since the procedure's
  per-product branch is a `LIKE '%_<id>'` that would match any option ending in
  those digits. An integration test asserts a control option named
  `an_unrelated_option_0` survives.

**Not verified:**

- The HTTP layer of `/images/upload` and `/images/present` — route wiring, the byte
  ceiling, the `length_mismatch` refusal, and the HMAC over a body that is mostly raw
  image — is not covered by `tests/integration.php`, which tests `ImageWriter`
  directly. It IS exercised over real HTTP by the managing app's `tests/e2e.sh`, which
  sends a 1 MB image of random bytes and asserts the probe then finds it at exactly
  the URL the upload returned. `ImageWriter` itself now has automated tests, which its
  predecessor never could: writing bytes needs no outside network access, and fetching
  them did.
- A mid-body length lie is caught by the route's total check, not by `ImageWriter`.
  Offsets are cumulative, so a shortfall in the middle is absorbed by the next image's
  bytes and the slice still looks like a valid image. The writer's own per-entry check
  only catches the body ending early, and `tests/integration.php` asserts exactly that
  and says so.
- `/products/update` and `/products/exists` are covered at the class level against
  a real MySQL, not yet over HTTP through `index.php`. The route wiring, the
  50-row ceiling and the HMAC signature over the new route names are exercised by
  the managing app's own `tests/e2e.sh`, which runs this plugin for real.
- `images` cannot be updated. Replacing a gallery means creating and deleting
  attachments, which changes image ids and deletes files — it needs its own design
  and its own confirmation, not a line in a partial update.
- Updating a product does **not** rebuild its attribute set, so a variable product
  whose variations gain a new size still needs the `attributes` written by an
  import. Stated rather than half-done.
- Not tried on a site with a large existing catalogue. Aligning collation means
  `ALTER TABLE` on the tables that differ, and on a `postmeta` of several million
  rows that takes time. Do the first install during a quiet period.
- Not tried on restricted shared hosting: `ALTER DATABASE` needs `ALTER`, and
  creating stored functions needs `log_bin_trust_function_creators`.
- A removal larger than the `ids_only` ceiling of 100,000 reports `truncated` and
  covers what it returned; that path has not been exercised against a catalogue
  that large.

Before using this on real data: install it on a staging site, import a few
products, open wp-admin and check prices, variations, attributes and images against
the source, and only then move to the live site.

## Finding products with no picture

`POST /products/lookup` takes `without_images: true` as a narrowing, on top of one of
the four selections — never instead of one, so it cannot quietly mean everything.

A product HAS an image when any of these is true, and the third is the one that
matters most:

- `_thumbnail_id` points at something;
- `_product_image_gallery` is not empty;
- `fifu_image_url` is set — an external URL, which is what the default import mode
  writes. A definition that skipped it would report every such product as picture-less.

A variation's image counts as the parent having one, because a variable product whose
variants carry pictures shows pictures.

Every row the lookup returns carries `has_image`, computed by the same method the
filter uses (`ProductDeleter::hasImageSql`), so a client cannot show a list that
disagrees with why it matched. `image_count` is a different question — it counts
attachment children — and is left alone.

Older builds IGNORE an unknown filter key rather than refusing it, so a client must
check the version before sending this one. The managing app refuses below 3.7.0.
