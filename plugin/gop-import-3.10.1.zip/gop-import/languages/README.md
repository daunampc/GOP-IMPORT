# Translations

`gop-import.php` declares `Text Domain: gop-import` and `Domain Path: /languages`,
and loads this directory on `init`. Drop `gop-import-<locale>.mo` files here —
`gop-import-vi.mo` for Vietnamese — and WordPress will use them.

The interface strings are English on purpose: the web application is English, the
two are read together, and a half-translated pair is harder to follow than one
language throughout. This directory exists so a site can translate it without
patching the plugin.
