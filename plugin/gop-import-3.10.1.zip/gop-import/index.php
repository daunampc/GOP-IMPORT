<?php

/**
 * GOP_IMPORT — the ONE entry point of the API.
 *
 * In v2 every PHP file was a directly callable endpoint, so a single overlooked
 * file was a hole. Here everything comes through one door: authenticate first,
 * then route against an allowlist.
 */

declare(strict_types=1);

require_once __DIR__ . '/src/Bootstrap.php';

use GopImport\Bootstrap;
use GopImport\Http\Auth;
use GopImport\Http\Response;
use GopImport\Http\UnauthorizedException;
use GopImport\Import\ValidationException;
use GopImport\License\License;
use GopImport\Support\Config;

Bootstrap::registerAutoloader();

// Never print a PHP error into the response — that is an information leak. Log it.
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
ini_set('error_log', __DIR__ . '/logs/php-error.log');

const MAX_BATCH_SIZE = 50;

/*
 * IMAGE UPLOADS — the bytes arrive in the request, RAW, so these bound the body.
 *
 * 31 MB of image against a 32 MB MAX_BODY_BYTES: the manifest in front of them is a
 * few kilobytes for forty entries, so the megabyte of headroom is generous.
 *
 * 3.9.0 could only carry 22 MB here, because it took the bytes as base64 and 4/3 of
 * anything larger does not fit in the body. Sending them raw removed that entirely —
 * a third of every image-heavy request was base64 padding, measured at 2.00 MB of
 * JPEG becoming 2.67 MB.
 */
const MAX_IMAGE_UPLOAD_BYTES = 32505856;
const MAX_IMAGE_UPLOAD_COUNT = 40;

/** URLs one `/images/present` question may ask about. */
const MAX_IMAGE_PRESENT_COUNT = 200;
const MAX_DELETE_BATCH = 50;
const MAX_UPDATE_BATCH = 50;
const MAX_BODY_BYTES = 33554432; // 32 MB

$startedAt = microtime(true);

try {
    // Stop early, before any mysqli_* call — otherwise the error is "Call to
    // undefined function", which tells whoever has to fix it nothing.
    if (!extension_loaded('mysqli')) {
        Response::error(
            503,
            'missing_mysqli',
            'This server has not enabled the `mysqli` extension. Enable it under PHP Extensions in your hosting panel.'
        );
        return;
    }

    if (!Config::exists()) {
        Response::error(503, 'not_installed', 'Not installed yet. Run setup.php first.');
        return;
    }

    $method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
    $route = resolve_route();
    $body = read_body();

    $app = Bootstrap::boot();
    (new Auth($app->config()))->verify($method, $route, $body);

    /*
     * THE ACTIVATION GATE — every route.
     *
     * After authentication on purpose: a request that is not signed must be told it
     * is not signed, rather than told about the licence. An attacker with no key
     * learns nothing about this site's licensing.
     *
     * Nothing is exempt, `/health` included. The reason a full block is still
     * diagnosable is the SHAPE of the refusal: a 403 whose body carries
     * `license_missing`, `license_invalid`, `license_expired` or `license_stale` says
     * precisely what is wrong, where a site that is unreachable, misconfigured or on
     * the wrong path says nothing at all. The managing app tells those two apart by
     * the code and reports them with different words.
     */
    if (!in_array("$method $route", License::EXEMPT_ROUTES, true)) {
        $verdict = License::verdict();

        if (!$verdict['allowed']) {
            Response::error(403, $verdict['code'], $verdict['message']);
            return;
        }
    }

    dispatch($app, $method, $route, $body, $startedAt);
} catch (UnauthorizedException $e) {
    Response::error(401, $e->errorCode(), $e->getMessage(), $e->extra());
} catch (ValidationException $e) {
    Response::error(400, $e->errorCode(), $e->getMessage());
} catch (\Throwable $e) {
    error_log('[gop-import] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    Response::error(500, 'internal_error', 'Server error. See logs/php-error.log.');
}

/**
 * The route comes from PATH_INFO (`/index.php/products/batch`) or `?route=`.
 * It is always normalised to `/a/b`, so a client's signature is stable no matter
 * which directory the plugin sits in.
 */
function resolve_route(): string
{
    $raw = (string) ($_SERVER['PATH_INFO'] ?? '');
    if ($raw === '') {
        $raw = (string) ($_GET['route'] ?? '');
    }

    $raw = '/' . trim($raw, '/');

    // Letters, digits, dashes, underscores and / only.
    if (!preg_match('~^/[a-z0-9/_-]*$~i', $raw)) {
        return '/';
    }

    return $raw;
}

function read_body(): string
{
    $body = (string) file_get_contents('php://input');

    if (strlen($body) > MAX_BODY_BYTES) {
        throw new ValidationException('body_too_large', 'The body exceeds 32 MB.');
    }

    return $body;
}

/** @return array<string,mixed> */
function decode_json(string $body): array
{
    if (trim($body) === '') {
        throw new ValidationException('empty_body', 'The body is empty.');
    }

    try {
        $decoded = json_decode($body, true, 512, JSON_THROW_ON_ERROR);
    } catch (\JsonException $e) {
        throw new ValidationException('invalid_json', 'Malformed JSON: ' . $e->getMessage());
    }

    if (!is_array($decoded)) {
        throw new ValidationException('invalid_json', 'The body must be a JSON object or array.');
    }

    return $decoded;
}

function dispatch(Bootstrap $app, string $method, string $route, string $body, float $startedAt): void
{
    // The parameter travels IN the route rather than in a query string, because
    // the HMAC signs the route only — a query parameter could be changed while
    // the signature stayed valid.
    if ($method === 'GET' && str_starts_with($route, '/terms/')) {
        handle_terms($app, substr($route, strlen('/terms/')));
        return;
    }

    switch ("$method $route") {
        case 'GET /health':
            handle_health($app);
            return;

        case 'POST /products/batch':
            handle_batch($app, $body, $startedAt);
            return;

        case 'POST /products/lookup':
            handle_lookup($app, $body);
            return;

        case 'POST /products/exists':
            handle_exists($app, $body);
            return;

        case 'POST /products/update':
            handle_update($app, $body, $startedAt);
            return;

        case 'POST /products/delete':
            handle_delete($app, $body, $startedAt);
            return;

        case 'POST /images/upload':
            handle_image_upload($app, $body);
            return;

        case 'POST /images/present':
            handle_images_present($app, $body);
            return;

        case 'POST /maintenance/clear-transients':
            handle_clear_transients($app);
            return;

        case 'POST /maintenance/recalculate-prices':
            handle_recalculate_prices($app);
            return;

        default:
            Response::error(404, 'unknown_route', "No such route: $method $route");
    }
}

function handle_health(Bootstrap $app): void
{
    $db = $app->db();
    $prefix = Bootstrap::FN_PREFIX;

    $required = [
        'create_product', 'create_variant', 'create_term', 'create_review',
        'create_attribute', 'create_attribute_for_product', 'create_postmeta', 'slugify',
    ];

    $installed = [];
    foreach ($db->rows(
        'SELECT ROUTINE_NAME AS name FROM information_schema.ROUTINES WHERE ROUTINE_SCHEMA = DATABASE()'
    ) as $row) {
        $installed[strtolower((string) $row['name'])] = true;
    }

    $missing = [];
    foreach ($required as $function) {
        if (!isset($installed[strtolower($prefix . $function)])) {
            $missing[] = $prefix . $function;
        }
    }

    Response::json($missing === [] ? 200 : 503, [
        'ok'                 => $missing === [],
        'version'            => trim((string) @file_get_contents(__DIR__ . '/version.txt')),
        'php'                => PHP_VERSION,
        'mysql'              => $db->raw()->get_server_info(),
        'table_prefix'       => $db->prefix(),
        'site_url'           => $app->config()->siteUrl(),
        'missing_functions'  => $missing,
        /*
         * Two numbers the managing app cannot guess, reported so that a host which
         * chokes on image uploads can be DIAGNOSED rather than argued about.
         *
         * They are deliberately not acted on automatically. Clamping the app's
         * upload budget to whatever a site reports would need this value stored per
         * store and kept fresh, and the failure it would prevent already announces
         * itself with `upload_too_large`, naming the limit.
         */
        'max_image_upload_bytes' => MAX_IMAGE_UPLOAD_BYTES,
        // So the app can tell a build that takes raw bytes from one that took base64
        // without inferring it from the version string alone.
        'image_framing'      => 'binary',
        'php_memory_limit'   => (string) ini_get('memory_limit'),
        /*
         * The licence, as a FINGERPRINT and never the key.
         *
         * This is the half of "the same key on both sides" that the managing app
         * reads: it hashes the key its own account activated and compares, so a site
         * running somebody else's key is visible from the other end rather than only
         * from this one. The key itself never travels back out of the site, so a
         * leaked health response cannot be redeemed anywhere.
         */
        'license'            => \GopImport\License\License::report(),
    ]);
}

function handle_batch(Bootstrap $app, string $body, float $startedAt): void
{
    $payload = decode_json($body);

    // Accepts both `{"products":[...]}` and a bare array `[...]`.
    $items = $payload['products'] ?? $payload;

    if (!is_array($items) || $items === []) {
        throw new ValidationException('empty_batch', 'At least one product is required.');
    }

    if (!array_is_list($items)) {
        // A single object is accepted too, as a batch of one.
        $items = [$items];
    }

    if (count($items) > MAX_BATCH_SIZE) {
        throw new ValidationException(
            'batch_too_large',
            'At most ' . MAX_BATCH_SIZE . ' products per request; received ' . count($items) . '.'
        );
    }

    $results = $app->importer()->importBatch($items);

    Response::batch($results, (microtime(true) - $startedAt) * 1000);
}

/**
 * Find the products a filter matches. Deletes NOTHING.
 *
 * Separate from the delete command so the operator confirms the list they were
 * actually shown, rather than a filter they believe means what they think.
 */
function handle_lookup(Bootstrap $app, string $body): void
{
    $filter = decode_json($body);

    // `all` is the only way to match the whole catalogue, so it has to be stated
    // explicitly — an empty filter never quietly means "everything".
    Response::ok($app->deleter()->lookup($filter));
}

/**
 * Delete products and every dependent row.
 *
 * Accepts a list of ids only — the very list the lookup returned and the operator
 * saw. It accepts no filter, because a filter can match differently between
 * looking and pressing.
 */
function handle_delete(Bootstrap $app, string $body, float $startedAt): void
{
    $payload = decode_json($body);
    $ids = $payload['product_ids'] ?? null;

    if (!is_array($ids) || $ids === []) {
        throw new ValidationException('empty_batch', 'At least one product_id is required.');
    }

    if (count($ids) > MAX_DELETE_BATCH) {
        throw new ValidationException(
            'batch_too_large',
            'At most ' . MAX_DELETE_BATCH . ' products per request; received ' . count($ids) . '.'
        );
    }

    $normalized = [];
    foreach ($ids as $id) {
        $normalized[] = (int) $id;
    }

    // Defaults to TRUE: someone deleting a product almost always wants its images
    // gone too. Keeping the files takes a deliberate delete_images: false.
    $deleteImages = !array_key_exists('delete_images', $payload) || (bool) $payload['delete_images'];

    $results = $app->deleter()->deleteBatch($normalized, $deleteImages);

    Response::batch($results, (microtime(true) - $startedAt) * 1000);
}

/**
 * Change products that are already on the site.
 *
 * The one route that OVERWRITES rather than creates, and the whole contract is
 * partial: only fields present in a row are written. `{sku, price}` changes the
 * price and leaves the description, the images, the categories and the stock
 * exactly as they were. See `ProductUpdater` for why absence rather than
 * emptiness is the discriminant, and why `null` is refused rather than guessed.
 *
 * Shaped exactly like `handle_batch`: same envelope, same 50-row ceiling, same
 * 207-with-per-row-results answer. Anything else would have meant a second
 * result shape for the client to special-case.
 */
function handle_update(Bootstrap $app, string $body, float $startedAt): void
{
    $payload = decode_json($body);

    $items = $payload['products'] ?? $payload;

    if (!is_array($items) || $items === []) {
        throw new ValidationException('empty_batch', 'At least one product is required.');
    }

    if (!array_is_list($items)) {
        $items = [$items];
    }

    if (count($items) > MAX_UPDATE_BATCH) {
        throw new ValidationException(
            'batch_too_large',
            'At most ' . MAX_UPDATE_BATCH . ' products per request; received ' . count($items) . '.'
        );
    }

    $results = $app->updater()->updateBatch($items);

    Response::batch($results, (microtime(true) - $startedAt) * 1000);
}

/**
 * Which of these SKUs are already here?
 *
 * Cheap, and the point is that it can be asked BEFORE a run. Nothing used to ask
 * it, so a file whose SKUs already existed on the site imported as a second set
 * of products — a different idempotency key means a different product — and the
 * operator found out afterwards.
 */
function handle_exists(Bootstrap $app, string $body): void
{
    $payload = decode_json($body);
    $skus = $payload['skus'] ?? $payload;

    if (!is_array($skus) || $skus === []) {
        throw new ValidationException('empty_skus', 'At least one SKU is required.');
    }

    Response::ok($app->updater()->exists($skus));
}

/**
 * Write images the managing app has already downloaded.
 *
 * THE BODY IS FRAMED, NOT JSON:
 *
 *     {"images":[{"source_url":"…","content_type":"image/jpeg","length":184320}]}\n
 *     <184320 raw bytes><the next image's raw bytes>…
 *
 * One JSON manifest, one newline, then the images end to end.
 *
 * Why not JSON with the bytes base64 encoded, which is what 3.9.0 did: base64 costs
 * a third of the wire on every image-heavy request — 2.00 MB of JPEG becomes
 * 2.67 MB — plus an encode on one side and a decode on the other, and it capped a
 * single image at 22 MB because 4/3 of more than that will not fit in the body.
 *
 * Why not multipart/form-data, which is what a browser would send: PHP parses it
 * into `$_FILES` and leaves `php://input` EMPTY. `Auth::verify` signs the body it
 * reads from there, so every request would fail authentication. The framing above
 * keeps the HMAC over every byte with no change to the signing scheme.
 */
function handle_image_upload(Bootstrap $app, string $body): void
{
    $newline = strpos($body, "\n");

    if ($newline === false) {
        throw new ValidationException(
            'unframed_body',
            'The body must be a JSON manifest, a newline, then the image bytes.'
        );
    }

    $manifest = decode_json(substr($body, 0, $newline));
    $entries = $manifest['images'] ?? null;

    if (!is_array($entries) || $entries === []) {
        throw new ValidationException('empty_images', 'At least one image is required.');
    }

    if (count($entries) > MAX_IMAGE_UPLOAD_COUNT) {
        throw new ValidationException(
            'image_batch_too_large',
            'At most ' . MAX_IMAGE_UPLOAD_COUNT . ' images per request.'
        );
    }

    /*
     * THE LENGTHS MUST ADD UP TO WHAT ARRIVED, EXACTLY.
     *
     * Offsets are derived by adding the lengths in order, so one wrong length shifts
     * every image after it — each would be written from the middle of its neighbour.
     * Checking the total first turns that into one refusal instead of a directory of
     * quietly corrupt files.
     */
    $declared = 0;

    foreach ($entries as $entry) {
        if (!is_array($entry)) {
            throw new ValidationException('invalid_manifest', 'Every manifest entry must be an object.');
        }

        $length = $entry['length'] ?? null;

        if (!is_int($length) && !ctype_digit((string) $length)) {
            throw new ValidationException('invalid_manifest', 'Every entry needs an integer `length`.');
        }

        $declared += (int) $length;
    }

    $available = strlen($body) - ($newline + 1);

    if ($declared !== $available) {
        throw new ValidationException(
            'length_mismatch',
            "The manifest declares $declared bytes of image and the body carries $available."
        );
    }

    if ($declared > MAX_IMAGE_UPLOAD_BYTES) {
        throw new ValidationException(
            'upload_too_large',
            'This request carries ' . round($declared / 1048576, 1) . ' MB of image, and the limit '
            . 'is ' . round(MAX_IMAGE_UPLOAD_BYTES / 1048576, 1) . ' MB per request. Send fewer '
            . 'images per request.'
        );
    }

    Response::ok(['images' => $app->imageWriter()->writeFramed($entries, $body, $newline + 1)]);
}

/**
 * Which of these images the site already holds.
 *
 * The cheapest route in the plugin and the most valuable one on a re-run. The path
 * an image lands at is a pure function of its source URL (see `ImageWriter`), so
 * this is a handful of `is_file` calls per URL — and every `url` it answers with is
 * an image the app then does not download from its source and does not send here.
 * For a catalogue being re-synced that is most of the traffic of a run.
 *
 * Answering `null` is always safe: it means "send it", and sending an image the site
 * already has costs bandwidth rather than correctness.
 */
function handle_images_present(Bootstrap $app, string $body): void
{
    $payload = decode_json($body);
    $urls = $payload['images'] ?? $payload;

    if (!is_array($urls) || $urls === []) {
        throw new ValidationException('empty_images', 'At least one image URL is required.');
    }

    if (count($urls) > MAX_IMAGE_PRESENT_COUNT) {
        throw new ValidationException(
            'image_batch_too_large',
            'At most ' . MAX_IMAGE_PRESENT_COUNT . ' URLs per request.'
        );
    }

    $flat = [];
    foreach ($urls as $url) {
        $flat[] = is_array($url) ? (string) ($url['source_url'] ?? '') : (string) $url;
    }

    Response::ok([
        'images' => $app->imageWriter()->present($flat, $payload['id_multisite'] ?? null),
    ]);
}

function handle_terms(Bootstrap $app, string $taxonomy): void
{
    if (!in_array($taxonomy, ['product_cat', 'product_tag', 'product_shipping_class'], true)) {
        throw new ValidationException('invalid_taxonomy', 'taxonomy must be product_cat, product_tag or product_shipping_class.');
    }

    $db = $app->db();
    $terms = $db->table('terms');
    $taxonomies = $db->table('term_taxonomy');

    $rows = $db->rows(
        "SELECT t.term_id, t.name, t.slug, tt.parent, tt.count
         FROM $terms t
         INNER JOIN $taxonomies tt ON tt.term_id = t.term_id
         WHERE tt.taxonomy = ?
         ORDER BY t.name
         LIMIT 5000",
        [$taxonomy]
    );

    Response::ok(['taxonomy' => $taxonomy, 'terms' => $rows]);
}

/**
 * Writing straight to the database means WooCommerce never clears its own
 * transients. This endpoint calls the cleanup procedure — a client should call it
 * ONCE after a whole run, not after each product.
 */
function handle_clear_transients(Bootstrap $app): void
{
    $db = $app->db();
    $prefix = Bootstrap::FN_PREFIX;

    /*
     * NULL, not 0.
     *
     * The procedure branches on `IF(_idParent IS NOT null)`, and `0` is not NULL —
     * so passing 0 took the per-product branch and ran
     * `DELETE FROM wp_options WHERE option_name LIKE '%_0'`, which cleared no
     * WooCommerce transient at all and did delete any unrelated option whose name
     * happened to end in `_0`. The ten correct statements are in the ELSE branch
     * and had never run. The procedure's signature is unchanged, because every
     * site already has it installed.
     */
    $db->raw()->query("CALL `{$prefix}clear_woocommeerce_transients`(NULL)");
    $db->raw()->query("CALL `{$prefix}clear_woocommeerce_transients_price`(NULL)");

    Response::ok(['cleared' => true]);
}

/**
 * Recompute the min/max price of every variable product.
 *
 * wp-admin's Maintenance tab has had this button all along and this API had no
 * route for it, so the app could not reach it — recorded in the app's README as a
 * known gap. It matters because the min/max in `wc_product_meta_lookup` is what
 * category pages show, and that is the first price a shopper sees.
 *
 * Computed by aggregate over each product's variations rather than by the
 * inherited procedure's temp-table dance, so a variation whose price came DOWN
 * lowers the range instead of leaving the old floor advertised.
 */
function handle_recalculate_prices(Bootstrap $app): void
{
    Response::ok(['recalculated' => true] + $app->updater()->recalculatePrices());
}
