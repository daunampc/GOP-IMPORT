<?php

/**
 * What is removed when the plugin is DELETED — not merely deactivated.
 *
 * WordPress runs this file (and nothing else from the plugin) on uninstall, so it
 * cannot rely on anything the plugin normally loads.
 *
 * The line worth thinking about is the one that is NOT here. `config/config.ini`
 * holds this site's own database credentials, its API key and its API secret, and
 * WordPress deletes the whole plugin directory straight after this file runs — so
 * the file goes with it either way. What this does is remove what lives OUTSIDE
 * the directory: the options and the scheduled event, which would otherwise sit in
 * `wp_options` for ever with nothing left to read them.
 */

declare(strict_types=1);

// Only ever reached through WordPress's uninstall path.
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

delete_option('gop_import_license_state');
delete_option('gop_import_app_url');
delete_option('gop_import_db_version');

// Site-wide options too, for a multisite install where the plugin was activated
// network-wide.
delete_site_option('gop_import_license_state');
delete_site_option('gop_import_app_url');

wp_clear_scheduled_hook('gop_import_verify_license');

// Transients are caches; losing them costs nothing and leaving them is litter.
delete_transient('gop_import_license_check');
delete_transient('gop_import_health');
