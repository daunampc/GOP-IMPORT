<?php

/**
 * Plugin Name:       GOP_IMPORT
 * Description:       High-speed WooCommerce product import over an authenticated API, writing straight to MySQL. Includes an admin dashboard for installation, connection keys, licence activation, maintenance and the import log.
 * Version:           3.10.1
 * Requires at least: 5.0
 * Tested up to:      7.0
 * Requires PHP:      8.1
 * Author:            GOP_IMPORT
 * License:           Proprietary
 * Text Domain:       gop-import
 * Domain Path:       /languages
 * WC requires at least: 6.0
 * WC tested up to:   11.0
 * Update URI:        false
 */

/*
 * `Update URI: false` is not decoration. Without it, WordPress asks wordpress.org
 * about any plugin whose directory name matches something in the directory — and
 * would happily offer to "update" this proprietary plugin over the top of itself
 * with somebody else's code of the same slug. `false` tells the update check to
 * leave it alone.
 *
 * `Text Domain` and `Domain Path` are declared because the strings in this plugin
 * already call `__()` with that domain: without the headers and the loader below
 * the calls are honest and the translations are simply never found.
 */

/**
 * WordPress's entry point.
 *
 * The API itself (index.php) does NOT load WordPress and never runs through this
 * file — which is exactly why it is fast. All that lives here is the admin
 * screen, and it is only loaded inside wp-admin.
 */

// Block direct access over a URL.
if (!defined('ABSPATH')) {
    exit;
}

define('GOP_IMPORT_VERSION', '3.10.1');

/**
 * THE ONE PLACE the web application's address is set.
 *
 * Change this line, build, and every installation picks it up — customers never see
 * it and are never asked for it. They have one thing to type: their key.
 *
 * Guarded by `defined()` so a single site can be pointed somewhere else from
 * `wp-config.php` — staging, a migration, a customer on their own instance — without
 * a separate build and without another field on the screen:
 *
 *     define('GOP_IMPORT_APP_URL', 'https://staging.example.com');
 *
 * EMPTY MEANS NO CHECKING. A key entered on a build with no address here is saved and
 * accepted on the site itself, without a server being asked — which is the state to
 * build in while testing the plugin, and the reason this is the only line to change to
 * turn real checking back on. Every screen says "not verified" while it lasts and
 * `/health` reports `verified: false`, because a build in this state accepts ANY key.
 * Do not ship one to a customer.
 */
if (!defined('GOP_IMPORT_APP_URL')) {
    define('GOP_IMPORT_APP_URL', '');
}
define('GOP_IMPORT_DIR', __DIR__);
define('GOP_IMPORT_FILE', __FILE__);

/**
 * Tell WooCommerce which of its features this plugin is compatible with.
 *
 * Without this, WooCommerce 8.2+ lists the plugin under "some of your active
 * plugins are incompatible with currently enabled WooCommerce features" — and that
 * notice does not mean anything was found to be broken. It means the plugin never
 * SAID anything, and WooCommerce refuses to assume.
 *
 * Declared compatible because it is true rather than to quiet the notice, and the
 * reason is the same for all three:
 *
 *  - `custom_order_tables` (HPOS) — this plugin never reads or writes an order. It
 *    imports products: posts, postmeta, terms and `wc_product_meta_lookup`. Where
 *    WooCommerce keeps orders is not something it can be affected by.
 *  - `cart_checkout_blocks` — it adds nothing to the front end at all. No cart, no
 *    checkout, no shortcode, no block.
 *  - `product_block_editor` — it writes product data through the database rather
 *    than through the editor screen, so which editor wp-admin renders changes
 *    nothing about what it writes.
 *
 * Registered at top level, NOT inside the `is_admin()` block below:
 * `before_woocommerce_init` fires on front-end requests too, and a declaration
 * WooCommerce never sees is a declaration that was not made.
 */
add_action('before_woocommerce_init', static function (): void {
    // Absent on a WooCommerce older than 7.8, and absent when WooCommerce is not
    // installed at all — in both cases there is nobody to tell.
    if (!class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) {
        return;
    }

    foreach (['custom_order_tables', 'cart_checkout_blocks', 'product_block_editor'] as $feature) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
            $feature,
            GOP_IMPORT_FILE,
            true
        );
    }
});

/**
 * Refuse to ACTIVATE on a server that cannot run this, rather than activating and
 * then breaking.
 *
 * The admin notices further down already explain an unsupported PHP or a missing
 * mysqli to somebody who has the plugin active. This is the earlier and kinder
 * moment: WordPress catches the exception, unwinds the activation and shows the
 * message, so the site is left exactly as it was.
 *
 * WooCommerce is deliberately NOT enforced here. It is genuinely required for the
 * data to mean anything, and it is also perfectly reasonable to install and
 * configure this plugin before WooCommerce on a new site — so its absence is a
 * notice, not a refusal.
 */
register_activation_hook(__FILE__, static function (): void {
    $problems = [];

    if (version_compare(PHP_VERSION, '8.1', '<')) {
        $problems[] = sprintf('PHP 8.1 or newer is required; this server runs PHP %s.', PHP_VERSION);
    }

    if (!extension_loaded('mysqli')) {
        $problems[] = 'The `mysqli` PHP extension is required and is not enabled on this server.';
    }

    if ($problems !== []) {
        // Plain text, no markup: WordPress prints this inside its own error page.
        wp_die(
            esc_html('GOP_IMPORT cannot be activated on this server. ' . implode(' ', $problems)),
            esc_html('Plugin could not be activated'),
            ['back_link' => true]
        );
    }
});

/**
 * Clean up the things that outlive a deactivation.
 *
 * The licence state and the connection config stay: deactivating is not deleting,
 * and making somebody re-enter a licence key because they toggled the plugin off
 * for ten minutes would be punishing them for a diagnostic step. The scheduled
 * re-check has to go, because a schedule for code that is not running is a WP-Cron
 * error every hour. `uninstall.php` is where the real removal lives.
 */
register_deactivation_hook(__FILE__, static function (): void {
    wp_clear_scheduled_hook('gop_import_verify_license');
});

/**
 * Translations.
 *
 * On `init` rather than at load: WordPress determines the locale after plugins are
 * loaded, and a textdomain loaded too early is loaded for the wrong language — the
 * bug that makes a site show English to a Vietnamese administrator.
 */
add_action('init', static function (): void {
    load_plugin_textdomain('gop-import', false, dirname(plugin_basename(__FILE__)) . '/languages');
});

/**
 * Confirm the activation key once a day.
 *
 * Daily rather than per request: the API has to answer in milliseconds and cannot
 * wait on somebody else's server, so the check is a background job and `index.php`
 * reads only what it wrote. `License::TRUST_DAYS` is what bounds the staleness that
 * arrangement allows.
 *
 * Scheduled on `init` and only when it is not already scheduled — WP-Cron keeps its
 * own list, and re-adding the event on every request would run it on every request.
 */
add_action('init', static function (): void {
    if (!wp_next_scheduled('gop_import_verify_license')) {
        wp_schedule_event(time() + HOUR_IN_SECONDS, 'daily', 'gop_import_verify_license');
    }
});

add_action('gop_import_verify_license', static function (): void {
    require_once __DIR__ . '/src/Bootstrap.php';
    \GopImport\Bootstrap::registerAutoloader();
    \GopImport\License\Verifier::recheck();
});

/**
 * Load the admin screen.
 *
 * The condition is deliberate: without it every visitor's request would load the
 * autoloader and register the menu hook — paying for something only an
 * administrator ever sees.
 *
 * WP-CLI counts as well, because `is_admin()` is false there. Without allowing it
 * the plugin could not be installed from a script — which is precisely what is
 * needed when managing many sites.
 */
if (is_admin() || (defined('WP_CLI') && WP_CLI)) {
    require_once __DIR__ . '/src/Bootstrap.php';

    \GopImport\Bootstrap::registerAutoloader();

    // On too old a PHP, load nothing and print one line. Loading anyway would be
    // a fatal error that whites out the whole of wp-admin.
    if (version_compare(PHP_VERSION, '8.1', '<')) {
        add_action('admin_notices', static function (): void {
            printf(
                '<div class="notice notice-error"><p><strong>%s</strong> %s</p></div>',
                esc_html__('GPM GopImport Import:', 'gop-import'),
                esc_html(sprintf(
                    'requires PHP 8.1 or newer; this server runs PHP %s. The plugin is inactive.',
                    PHP_VERSION
                ))
            );
        });
    } elseif (!extension_loaded('mysqli')) {
        add_action('admin_notices', static function (): void {
            printf(
                '<div class="notice notice-error"><p><strong>%s</strong> %s</p></div>',
                esc_html__('GPM GopImport Import:', 'gop-import'),
                esc_html__(
                    'This server has not enabled the `mysqli` extension. Enable it under PHP Extensions in your hosting panel.',
                    'gop-import'
                )
            );
        });
    } else {
        \GopImport\Admin\Admin::register();
    }
}

/** Prompt for installation when the plugin is active but config.ini is absent. */
add_action('admin_notices', static function (): void {
    if (!current_user_can('manage_options')) {
        return;
    }

    // No need to prompt while already on the plugin's own page.
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if ($screen !== null && $screen->id === 'toplevel_page_gop-import') {
        return;
    }

    if (file_exists(GOP_IMPORT_DIR . '/config/config.ini')) {
        return;
    }

    printf(
        '<div class="notice notice-warning"><p><strong>%s</strong> %s <a href="%s">%s</a></p></div>',
        esc_html__('GPM GopImport Import:', 'gop-import'),
        esc_html__('is not configured yet.', 'gop-import'),
        esc_url(admin_url('admin.php?page=gop-import')),
        esc_html__('Open the setup screen', 'gop-import')
    );
});

/** A shortcut to the admin screen, on the plugin's own row in the Plugins list. */
add_filter(
    'plugin_action_links_' . plugin_basename(__FILE__),
    static function (array $links): array {
        array_unshift($links, sprintf(
            '<a href="%s">%s</a>',
            esc_url(admin_url('admin.php?page=gop-import')),
            esc_html__('Settings', 'gop-import')
        ));

        return $links;
    }
);
