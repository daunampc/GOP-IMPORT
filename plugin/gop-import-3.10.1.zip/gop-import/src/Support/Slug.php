<?php

namespace GopImport\Support;

/**
 * The slug algorithm is UNCHANGED from v2. This is not a place to improve
 * things: an attribute term's slug has to match exactly what WooCommerce and
 * previously imported products already use. Drift by one character and a
 * variation can no longer be mapped to its attribute.
 *
 * The table below is Vietnamese data, not prose — it stays as it is.
 */
final class Slug
{
    private const VIETNAMESE = [
        'a' => ['á', 'à', 'ả', 'ã', 'ạ', 'ă', 'ắ', 'ằ', 'ẳ', 'ẵ', 'ặ', 'â', 'ấ', 'ầ', 'ẩ', 'ẫ', 'ậ'],
        'e' => ['é', 'è', 'ẻ', 'ẽ', 'ẹ', 'ê', 'ế', 'ề', 'ể', 'ễ', 'ệ'],
        'i' => ['í', 'ì', 'ỉ', 'ĩ', 'ị'],
        'o' => ['ó', 'ò', 'ỏ', 'õ', 'ọ', 'ô', 'ố', 'ồ', 'ổ', 'ỗ', 'ộ', 'ơ', 'ớ', 'ờ', 'ở', 'ỡ', 'ợ'],
        'u' => ['ú', 'ù', 'ủ', 'ũ', 'ụ', 'ư', 'ứ', 'ừ', 'ử', 'ữ', 'ự'],
        'y' => ['ý', 'ỳ', 'ỷ', 'ỹ', 'ỵ'],
        'd' => ['đ'],
        'A' => ['Á', 'À', 'Ả', 'Ã', 'Ạ', 'Ă', 'Ắ', 'Ằ', 'Ẳ', 'Ẵ', 'Ặ', 'Â', 'Ấ', 'Ầ', 'Ẩ', 'Ẫ', 'Ậ'],
        'E' => ['É', 'È', 'Ẻ', 'Ẽ', 'Ẹ', 'Ê', 'Ế', 'Ề', 'Ể', 'Ễ', 'Ệ'],
        'I' => ['Í', 'Ì', 'Ỉ', 'Ĩ', 'Ị'],
        'O' => ['Ó', 'Ò', 'Ỏ', 'Õ', 'Ọ', 'Ô', 'Ố', 'Ồ', 'Ổ', 'Ỗ', 'Ộ', 'Ơ', 'Ớ', 'Ờ', 'Ở', 'Ỡ', 'Ợ'],
        'U' => ['Ú', 'Ù', 'Ủ', 'Ũ', 'Ụ', 'Ư', 'Ứ', 'Ừ', 'Ử', 'Ữ', 'Ự'],
        'Y' => ['Ý', 'Ỳ', 'Ỷ', 'Ỹ', 'Ỵ'],
        'D' => ['Đ'],
    ];

    /** @var array<string,string> memoised for the life of one request */
    private static array $cache = [];

    public static function removeAccents(string $text): string
    {
        foreach (self::VIETNAMESE as $plain => $accented) {
            $text = str_replace($accented, $plain, $text);
        }
        return $text;
    }

    /**
     * @param bool $allowEmpty for an empty variation value, e.g. "any size"
     */
    public static function make(?string $text, bool $allowEmpty = false): string
    {
        $key = ($allowEmpty ? '1:' : '0:') . (string) $text;
        if (isset(self::$cache[$key])) {
            return self::$cache[$key];
        }

        if ($text !== null) {
            $text = self::removeAccents($text);
            $text = preg_replace('~[^\pL\d]+~u', '-', $text);

            if (function_exists('iconv')) {
                $transliterated = @iconv('utf-8', 'us-ascii//TRANSLIT', $text);
                if ($transliterated !== false && $transliterated !== null) {
                    $text = $transliterated;
                }
            }

            $text = preg_replace('~[^-\w]+~', '', $text);
            $text = trim($text, '-');
            $text = preg_replace('~-+~', '-', $text);
            $text = strtolower($text);
        }

        if (($text === null || $text === '') && !$allowEmpty) {
            // The random branch is never cached — every call must produce a
            // different slug.
            return 'na-' . substr(md5((string) mt_rand()), 0, 8);
        }

        return self::$cache[$key] = (string) $text;
    }
}
