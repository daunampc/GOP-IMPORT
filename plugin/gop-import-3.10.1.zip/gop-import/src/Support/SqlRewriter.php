<?php

namespace GopImport\Support;

/**
 * Rewrites table names and stored-routine names inside a .sql file before it is
 * installed.
 *
 * The `tsd_` prefix on routines is what lets this plugin share a database with
 * the v2 plugin without either overwriting the other — v2 uses bare names
 * (`create_product`), and installing over them breaks both.
 */
final class SqlRewriter
{
    /**
     * The routines to rename. ORDER MATTERS — longest first, because
     * `create_attribute` is a prefix of `create_attribute_for_product`.
     */
    public const ROUTINES = [
        'clear_woocommeerce_transients_price',
        'clear_woocommeerce_transients',
        'create_attribute_for_product',
        'fix_min_max_price_upgrade_v2_0',
        'get_productid_from_sku',
        'delete_product_by_sku',
        'delete_product_by_id',
        'create_attribute',
        'create_postmeta',
        'create_product',
        'create_variant',
        'create_review',
        'update_product',
        'update_variant',
        'create_term',
        'slugify',
    ];

    private string $functionPrefix;

    private string $tablePrefix;

    public function __construct(string $functionPrefix, string $tablePrefix)
    {
        $this->functionPrefix = $functionPrefix;
        $this->tablePrefix = $tablePrefix;
    }

    public function rewrite(string $sql): string
    {
        if ($this->tablePrefix !== 'wp_') {
            // Only rewrite where a backtick precedes it, so text literals and
            // variable names that happen to start with `wp_` are left alone.
            $sql = str_replace('`wp_', '`' . $this->tablePrefix, $sql);
        }

        $pattern = '/\b(' . implode('|', array_map('preg_quote', self::ROUTINES)) . ')\b/';

        // ONE pass only. A second pass would match `create_attribute` again
        // inside the `tsd_create_attribute_for_product` it just produced.
        return preg_replace_callback(
            $pattern,
            fn (array $matches): string => $this->functionPrefix . $matches[1],
            $sql
        );
    }

    /** @return array<int,string> the routine names with the prefix applied */
    public function prefixedRoutines(): array
    {
        return array_map(fn (string $name): string => $this->functionPrefix . $name, self::ROUTINES);
    }
}
