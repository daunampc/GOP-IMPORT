<?php

namespace GopImport\Support;

/**
 * Reads config/config.ini. Deliberately independent of everything else so that
 * setup.php can reuse it without dragging the HTTP layer along.
 */
final class Config
{
    /** @var array<string,mixed> */
    private array $values;

    private static ?Config $instance = null;

    private function __construct(array $values)
    {
        $this->values = $values;
    }

    public static function path(): string
    {
        return dirname(__DIR__, 2) . '/config/config.ini';
    }

    public static function exists(): bool
    {
        return file_exists(self::path());
    }

    public static function load(): Config
    {
        if (self::$instance !== null) {
            return self::$instance;
        }

        $path = self::path();
        if (!file_exists($path)) {
            throw new \RuntimeException('Not installed yet: config/config.ini was not found. Run setup.php first.');
        }

        $parsed = @parse_ini_file($path, true);
        if ($parsed === false) {
            throw new \RuntimeException('config/config.ini is malformed and could not be parsed.');
        }

        // Accepts both a flat file and one with a [database] section.
        $flat = isset($parsed['database']) && is_array($parsed['database'])
            ? array_merge($parsed, $parsed['database'])
            : $parsed;

        return self::$instance = new Config($flat);
    }

    /** Used by the tests to load a config built in memory. */
    public static function setInstance(?Config $config): void
    {
        self::$instance = $config;
    }

    public static function fromArray(array $values): Config
    {
        return new Config($values);
    }

    public function get(string $key, $default = null)
    {
        return $this->values[$key] ?? $default;
    }

    public function require(string $key)
    {
        if (!isset($this->values[$key]) || $this->values[$key] === '') {
            throw new \RuntimeException("Missing required configuration key: $key");
        }
        return $this->values[$key];
    }

    public function tablePrefix(): string
    {
        return (string) $this->get('table_prefix', 'wp_');
    }

    public function siteUrl(): string
    {
        return rtrim((string) $this->get('site_url', ''), '/');
    }

    /**
     * Write the ini file. Every value is quoted and escaped, so a password
     * containing special characters cannot corrupt the file the way it did in
     * v2.
     */
    public static function write(string $path, array $values): bool
    {
        $lines = ['; GOP_IMPORT — generated file, do not edit by hand', ''];
        foreach ($values as $key => $value) {
            $escaped = str_replace(['\\', '"'], ['\\\\', '\\"'], (string) $value);
            $lines[] = $key . ' = "' . $escaped . '"';
        }

        $handle = @fopen($path, 'w');
        if ($handle === false) {
            return false;
        }

        $locked = flock($handle, LOCK_EX);
        if ($locked) {
            fwrite($handle, implode("\n", $lines) . "\n");
            flock($handle, LOCK_UN);
        }
        fclose($handle);

        if ($locked) {
            @chmod($path, 0640);
        }

        return $locked;
    }
}
