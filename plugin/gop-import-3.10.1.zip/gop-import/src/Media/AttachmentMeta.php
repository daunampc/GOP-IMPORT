<?php

namespace GopImport\Media;

use GopImport\Support\Config;

/**
 * Builds `_wp_attachment_metadata` for an image ALREADY inside
 * wp-content/uploads.
 *
 * v2 wrote `a:1:{i:0;s:15:"giaiphapmmo.net";}` for an externally linked image —
 * fake metadata, from which WordPress can read no dimensions at all. Here, for a
 * local image, real metadata is written: dimensions read with getimagesize, and
 * every size WooCommerce looks for declared, all pointing at the original file.
 *
 * The trade: resized files are still NOT generated, so srcset points at the
 * original. That is why importing is fast — generating 8 sizes per image costs
 * 0.3–2 seconds of CPU each. In exchange WordPress and WooCommerce have real
 * width and height, so layout does not jump, and the Media library displays
 * normally.
 */
final class AttachmentMeta
{
    /** The sizes WooCommerce and WordPress actually look up. */
    private const SIZES = [
        'thumbnail',
        'medium',
        'medium_large',
        'large',
        '1536x1536',
        '2048x2048',
        'woocommerce_thumbnail',
        'woocommerce_single',
        'woocommerce_gallery_thumbnail',
        'shop_catalog',
        'shop_single',
        'shop_thumbnail',
    ];

    private string $siteUrl;

    private string $uploadsDir;

    /** @var array<string,string> memoised by URL — one image serves many variations */
    private array $cache = [];

    public function __construct(Config $config, string $uploadsDir)
    {
        $this->siteUrl = $config->siteUrl();
        $this->uploadsDir = rtrim($uploadsDir, '/');
    }

    /**
     * @param array<int,string> $urls
     * @return string the meta joined with `<->`, in the same order as the images
     */
    public function forList(array $urls): string
    {
        $out = [];
        foreach ($urls as $url) {
            $out[] = $this->forOne($url);
        }
        return implode(\GopImport\Import\MetaBuilder::SEPARATOR, $out);
    }

    /**
     * Returns the serialised string, or 'null' when the image is not local or
     * the file cannot be read. 'null' is the inherited stored function's
     * convention: seeing it, the function skips writing metadata.
     */
    public function forOne(string $url): string
    {
        if (isset($this->cache[$url])) {
            return $this->cache[$url];
        }

        $relative = $this->relativePath($url);
        if ($relative === null) {
            return $this->cache[$url] = 'null';
        }

        // `$this->uploadsDir` is WordPress's ROOT (Bootstrap passes
        // wordpressRoot in), while `$relative` is cut AFTER
        // "/wp-content/uploads/". Without joining that segment back on, the path
        // points at <root>/2026/08/image.jpg — which never exists — so every
        // image already uploaded to the site quietly returned 'null' and
        // WordPress had no dimensions with which to build a srcset.
        $path = $this->uploadsDir . '/wp-content/uploads/' . ltrim($relative, '/');
        if (!is_file($path)) {
            return $this->cache[$url] = 'null';
        }

        $info = @getimagesize($path);
        if ($info === false) {
            return $this->cache[$url] = 'null';
        }

        [$width, $height] = $info;
        $mime = $info['mime'] ?? 'image/jpeg';
        $file = basename($path);

        $sizes = [];
        foreach (self::SIZES as $size) {
            $sizes[$size] = [
                'file'      => $file,
                'width'     => $width,
                'height'    => $height,
                'mime-type' => $mime,
            ];
        }

        return $this->cache[$url] = serialize([
            'width'  => $width,
            'height' => $height,
            // WordPress stores `file` relative to the uploads directory.
            'file'   => ltrim($relative, '/'),
            'sizes'  => $sizes,
            'image_meta' => [
                'aperture' => '0', 'credit' => '', 'camera' => '', 'caption' => '',
                'created_timestamp' => '0', 'copyright' => '', 'focal_length' => '0',
                'iso' => '0', 'shutter_speed' => '0', 'title' => '', 'orientation' => '0',
                'keywords' => [],
            ],
        ]);
    }

    /**
     * Turns a full URL into a path relative to uploads ("2026/08/image.jpg"), or
     * null when the URL does not belong to this site.
     */
    private function relativePath(string $url): ?string
    {
        $marker = '/wp-content/uploads/';
        $position = strpos($url, $marker);
        if ($position === false) {
            return null;
        }

        // Only this site's own images; another site's uploads are still external.
        if ($this->siteUrl !== '' && !str_starts_with($url, $this->siteUrl)) {
            return null;
        }

        $relative = substr($url, $position + strlen($marker));
        $relative = explode('?', $relative)[0];

        // Block ../ from climbing out of the uploads directory.
        if (str_contains($relative, '..')) {
            return null;
        }

        return $relative;
    }
}
