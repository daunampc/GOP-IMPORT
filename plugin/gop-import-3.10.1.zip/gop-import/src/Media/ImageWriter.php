<?php

namespace GopImport\Media;

use GopImport\Support\Config;

/**
 * Writes images that the MANAGING APP has already downloaded into
 * wp-content/uploads.
 *
 * This replaced ImageFetcher in 3.9.0, and the difference was the whole point:
 * that class received a list of URLs and fetched them with curl_multi, so a PHP
 * process sat occupied for as long as the slowest CDN took. Forty images across
 * eight lanes with a 20 second timeout each is up to 100 seconds of a PHP-FPM
 * worker, and the app ran up to 32 such requests at once — 32 workers gone and
 * ~256 outbound connections leaving the shop's own server. That is what took sites
 * down mid-import, and no tuning inside the fetcher fixed it, because the work did
 * not belong here.
 *
 * 3.10.0 changes two things, both for SPEED with heavy images:
 *
 *  1. THE BYTES ARRIVE RAW, not base64. Base64 costs 33% on the wire — measured,
 *     not estimated: 2.00 MB of JPEG becomes 2.67 MB — plus an encode on one side
 *     and a decode on the other, and it forced a per-image ceiling of 22 MB because
 *     4/3 of anything larger will not fit in a 32 MB body. Gzip does not help: a
 *     JPEG is already compressed, so gzipping its base64 only claws back the
 *     padding it just added, for 92ms of CPU per 2 MB on each side. Raw bytes cost
 *     nothing and need no new signing scheme — see `writeFramed`.
 *  2. THE PATH IS CONTENT-ADDRESSED, not YYYY/MM. `uploads/gop-import/<2 hex>/`
 *     keyed by a hash of the source URL, so where an image lands is a pure function
 *     of where it came from — which is what makes `present()` below able to answer
 *     "you already have this" exactly, and therefore what lets the app skip
 *     downloading and uploading it at all. Under YYYY/MM the same image re-imported
 *     next month landed in a different directory, so nothing could be looked up.
 *
 * Two properties are kept from the class this replaced:
 *
 *  1. THE FILENAME IS ALWAYS THE SERVER'S DECISION. v2 used the name the client
 *     sent verbatim, which was path traversal.
 *  2. The CONTENT is not taken on trust. ImageFetcher believed the `Content-Type`
 *     the remote server declared and never looked at the bytes; here the magic
 *     bytes decide, and a declared type that disagrees with them loses.
 */
final class ImageWriter
{
    /** Extension per MIME type. Also the allowlist — nothing else is written. */
    private const EXTENSION_BY_MIME = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/gif'  => 'gif',
        'image/webp' => 'webp',
        'image/avif' => 'avif',
        'image/bmp'  => 'bmp',
    ];

    /** Longest slug kept, before `-<hash8>.<ext>` is appended. */
    private const MAX_SLUG_LENGTH = 100;

    /**
     * The one directory every image this plugin writes lives under.
     *
     * Named rather than dated. See the class comment: a dated path cannot be
     * looked up, and being able to look one up is what removes the traffic.
     */
    private const BUCKET = 'gop-import';

    private string $siteUrl;

    private string $wordpressRoot;

    public function __construct(Config $config, string $wordpressRoot)
    {
        $this->siteUrl = $config->siteUrl();
        $this->wordpressRoot = rtrim($wordpressRoot, '/');
    }

    /**
     * Write every image in a framed request body.
     *
     * THE FRAMING, and why it is this and not something more conventional:
     *
     *     {"images":[{"source_url":"…","content_type":"image/jpeg","length":184320}]}\n
     *     <184320 raw bytes><next image's raw bytes>…
     *
     * One JSON manifest, one newline, then the images end to end. Offsets come from
     * the lengths in order, so nothing is encoded and nothing is escaped.
     *
     * `Auth::verify` signs `method \n path \n timestamp \n body` and `read_body`
     * takes the body from `php://input`, which is binary safe — so the HMAC still
     * covers every byte, including the images, with NO change to the signing scheme
     * and none to any key already installed on a site. That is exactly what
     * multipart/form-data cannot do: PHP parses it into `$_FILES` and leaves
     * `php://input` EMPTY, so the signature would fail on every request.
     *
     * `$body` is passed whole rather than pre-sliced by the caller. Slicing forty
     * images out of it into an array first would hold a second copy of the entire
     * request in memory; slicing inside the loop holds one image at a time.
     *
     * @param array<int,array<string,mixed>> $entries the manifest's `images`
     * @return array<int,array<string,mixed>> in the same order as the manifest
     */
    public function writeFramed(array $entries, string $body, int $offset): array
    {
        $results = [];

        foreach ($entries as $index => $entry) {
            $length = (int) ($entry['length'] ?? 0);
            $raw = substr($body, $offset, $length);
            $offset += $length;

            $results[$index] = $this->writeOne($entry, $raw);

            // Released before the next image is sliced, so the peak is the body plus
            // ONE image rather than the body plus all of them.
            unset($raw);
        }

        ksort($results);

        return array_values($results);
    }

    /**
     * Which of these source URLs the site already holds.
     *
     * The whole point of the content-addressed path. Answering this costs a handful
     * of `is_file` calls per URL — the extension is the one thing not derivable from
     * the URL, so each of the six allowed ones is tried, and a stat is measured in
     * microseconds. In exchange the app skips DOWNLOADING and UPLOADING that image
     * entirely, which for a catalogue being re-synced is most of the work of a run.
     *
     * A `null` answer is never a lie in the expensive direction: it means "send it",
     * and sending an image the site already has costs bandwidth, not correctness.
     *
     * @param array<int,string> $sourceUrls
     * @return array<int,array<string,mixed>> `{source_url, url|null}` in input order
     */
    public function present(array $sourceUrls, $idMultisite = null): array
    {
        $multisite = $this->multisiteSegment($idMultisite);
        $results = [];

        foreach ($sourceUrls as $index => $sourceUrl) {
            $sourceUrl = trim((string) $sourceUrl);
            $found = null;

            if ($sourceUrl !== '') {
                foreach (self::EXTENSION_BY_MIME as $extension) {
                    [$relative, $absolute] = $this->pathFor($sourceUrl, $extension, $multisite);

                    if (is_file($absolute)) {
                        $found = $this->siteUrl . '/' . $relative;
                        break;
                    }
                }
            }

            $results[$index] = ['source_url' => $sourceUrl, 'url' => $found];
        }

        ksort($results);

        return array_values($results);
    }

    /**
     * @param array<string,mixed> $entry
     * @return array<string,mixed>
     */
    private function writeOne(array $entry, string $raw): array
    {
        $sourceUrl = trim((string) ($entry['source_url'] ?? ''));

        if ($sourceUrl === '') {
            return ['ok' => false, 'source_url' => '', 'error' => 'source_url is required'];
        }

        if ($raw === '') {
            return ['ok' => false, 'source_url' => $sourceUrl, 'error' => 'No bytes for this entry'];
        }

        $declaredLength = (int) ($entry['length'] ?? 0);

        if (strlen($raw) !== $declaredLength) {
            // The body ended early. Reported per entry rather than as a broken
            // request, because the entries before this one were written correctly.
            return [
                'ok'         => false,
                'source_url' => $sourceUrl,
                'error'      => "Expected $declaredLength bytes but the body held " . strlen($raw),
            ];
        }

        $mime = $this->sniff($raw);

        if ($mime === null) {
            $declared = (string) ($entry['content_type'] ?? '');

            return [
                'ok'         => false,
                'source_url' => $sourceUrl,
                'error'      => 'The bytes are not a recognised image'
                    . ($declared !== '' ? " (the request declared $declared)" : ''),
            ];
        }

        return $this->store($sourceUrl, $raw, $mime, $entry['id_multisite'] ?? null);
    }

    /**
     * The MIME type read from the first bytes of the file, or null.
     *
     * A prefix table rather than `getimagesizefromstring` or `finfo`, and the
     * reason is the hosting this plugin actually runs on: `IMAGETYPE_AVIF` only
     * exists from PHP 8.1, and `finfo` is not enabled everywhere. Either one would
     * REJECT VALID IMAGES on exactly the cheap hosts that matter, which is worse
     * than the narrower check. This table needs no extension and gives the same
     * answer everywhere.
     *
     * A prefix can of course be forged — prepend `FF D8 FF` to anything and it
     * reads as a JPEG. That is harmless here because the EXTENSION never comes from
     * the client: it comes from this function's verdict via EXTENSION_BY_MIME, so
     * no request can land a `.php` file in uploads.
     */
    public function sniff(string $raw): ?string
    {
        if (strlen($raw) < 12) {
            return null;
        }

        if (str_starts_with($raw, "\xFF\xD8\xFF")) {
            return 'image/jpeg';
        }

        if (str_starts_with($raw, "\x89PNG\x0D\x0A\x1A\x0A")) {
            return 'image/png';
        }

        if (str_starts_with($raw, 'GIF87a') || str_starts_with($raw, 'GIF89a')) {
            return 'image/gif';
        }

        // RIFF....WEBP — the four bytes between are the file size.
        if (str_starts_with($raw, 'RIFF') && substr($raw, 8, 4) === 'WEBP') {
            return 'image/webp';
        }

        // ISO-BMFF: a size, then "ftyp", then the brand.
        if (substr($raw, 4, 4) === 'ftyp') {
            $brand = substr($raw, 8, 4);
            if ($brand === 'avif' || $brand === 'avis') {
                return 'image/avif';
            }
        }

        if (str_starts_with($raw, 'BM')) {
            return 'image/bmp';
        }

        return null;
    }

    /**
     * @return array<string,mixed>
     */
    private function store(string $sourceUrl, string $raw, string $mime, $idMultisite): array
    {
        $multisite = $this->multisiteSegment($idMultisite);
        $extension = self::EXTENSION_BY_MIME[$mime];

        [$relative, $absolute] = $this->pathFor($sourceUrl, $extension, $multisite);

        $url = $this->siteUrl . '/' . $relative;
        $bytes = strlen($raw);

        /*
         * ALREADY THERE — checked before the directory is even created.
         *
         * This is where the old `-1`, `-2` behaviour went. ImageFetcher appended a
         * counter whenever a name was taken, so a retried batch left a second copy
         * of every image in uploads. The path now derives from the source URL, so
         * finding a file there means the work is done.
         *
         * The size comparison is not decoration: a run killed midway through
         * `file_put_contents` leaves a TRUNCATED file. Checking existence alone
         * would hand back a URL pointing at a broken image for ever, so a file whose
         * size disagrees is overwritten.
         */
        if (is_file($absolute) && filesize($absolute) === $bytes) {
            return [
                'ok'         => true,
                'source_url' => $sourceUrl,
                'url'        => $url,
                'bytes'      => $bytes,
                'skipped'    => true,
            ];
        }

        $directory = dirname($absolute);

        if (!is_dir($directory) && !@mkdir($directory, 0755, true) && !is_dir($directory)) {
            return [
                'ok'         => false,
                'source_url' => $sourceUrl,
                'error'      => 'Could not create the directory ' . dirname($relative),
            ];
        }

        if (@file_put_contents($absolute, $raw) === false) {
            return [
                'ok'         => false,
                'source_url' => $sourceUrl,
                'error'      => 'Could not write the file — check the permissions on '
                    . dirname($relative),
            ];
        }

        return [
            'ok'         => true,
            'source_url' => $sourceUrl,
            'url'        => $url,
            'bytes'      => $bytes,
            'skipped'    => false,
        ];
    }

    /**
     * Where an image from `$sourceUrl` with `$extension` belongs.
     *
     * `wp-content/uploads/[sites/N/]gop-import/<2 hex>/<slug>-<hash8>.<ext>`
     *
     * A pure function of the source URL, which is the property everything else here
     * rests on: `store()` uses it to be idempotent and `present()` uses it to answer
     * without being told anything but the URL. The two hex characters spread the
     * files over 256 directories, so a catalogue of 100,000 images does not put
     * 100,000 entries in one directory — which is slow to list on ext4 and painful
     * in any file manager.
     *
     * The slug keeps the name readable in the Media library and in the URL, which a
     * bare hash would not. There is deliberately NO `file_name` input: a
     * client-supplied name would make the name a function of the REQUEST rather than
     * of the source URL, and `present()` — which only ever sees a URL — would then
     * compute a different path from the one `store()` wrote to.
     *
     * @return array{0:string,1:string} the relative path and the absolute path
     */
    private function pathFor(string $sourceUrl, string $extension, string $multisite): array
    {
        $hash = substr(hash('sha256', $sourceUrl), 0, 8);

        $slug = \GopImport\Support\Slug::make(
            urldecode((string) pathinfo(parse_url($sourceUrl, PHP_URL_PATH) ?: '', PATHINFO_FILENAME)),
            true
        );
        $slug = substr($slug, 0, self::MAX_SLUG_LENGTH);

        if ($slug === '') {
            $slug = 'image';
        }

        $relative = 'wp-content/uploads/' . $multisite . self::BUCKET . '/'
            . substr($hash, 0, 2) . '/' . $slug . '-' . $hash . '.' . $extension;

        return [$relative, $this->wordpressRoot . '/' . $relative];
    }

    private function multisiteSegment($id): string
    {
        if ($id === null || $id === '') {
            return '';
        }
        // Digits only — the client cannot inject a path of its own here.
        if (!ctype_digit((string) $id)) {
            return '';
        }
        return 'sites/' . $id . '/';
    }
}
