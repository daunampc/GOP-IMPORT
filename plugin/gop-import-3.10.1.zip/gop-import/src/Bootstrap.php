<?php

namespace GopImport;

use GopImport\Db\Connection;
use GopImport\Db\TermRepository;
use GopImport\Import\MetaBuilder;
use GopImport\Import\Normalizer;
use GopImport\Import\ProductDeleter;
use GopImport\Import\ProductImporter;
use GopImport\Import\ProductUpdater;
use GopImport\Media\AttachmentMeta;
use GopImport\Media\ImageWriter;
use GopImport\Support\Config;

/**
 * The autoloader, and lazy construction of everything else.
 *
 * Composer is deliberately not used: the plugin has to work when the directory
 * is simply copied onto a host — no shell, no `composer install`. The trade is
 * that this autoloader is a few lines and never scans a vendor tree.
 */
final class Bootstrap
{
    /**
     * Prefix for every stored function this plugin installs.
     *
     * Kept as `tsd_` on purpose. It is part of the contract with every database
     * that already has the routines installed — renaming it would make `/health`
     * report all eight functions missing until each site reinstalled them. It
     * also keeps them clear of the v2 plugin's when both share one database.
     */
    public const FN_PREFIX = 'tsd_';

    private static ?Bootstrap $instance = null;

    private Config $config;

    private ?Connection $db = null;

    private ?ProductImporter $importer = null;

    private ?ProductDeleter $deleter = null;

    private ?ProductUpdater $updater = null;

    private ?ImageWriter $imageWriter = null;

    private ?AttachmentMeta $attachmentMeta = null;

    private function __construct(Config $config)
    {
        $this->config = $config;
    }

    public static function registerAutoloader(): void
    {
        spl_autoload_register(static function (string $class): void {
            $prefix = 'GopImport\\';
            if (!str_starts_with($class, $prefix)) {
                return;
            }

            $relative = str_replace('\\', '/', substr($class, strlen($prefix)));

            // The wp-admin screen lives in admin/ rather than src/, so that
            // everything to do with it — classes, views, stylesheet — sits in
            // one place.
            $path = str_starts_with($relative, 'Admin/')
                ? dirname(__DIR__) . '/admin/' . substr($relative, strlen('Admin/')) . '.php'
                : __DIR__ . '/' . $relative . '.php';

            if (is_file($path)) {
                require_once $path;
            }
        });
    }

    public static function boot(): Bootstrap
    {
        if (self::$instance !== null) {
            return self::$instance;
        }

        return self::$instance = new Bootstrap(Config::load());
    }

    public function config(): Config
    {
        return $this->config;
    }

    public function db(): Connection
    {
        return $this->db ??= new Connection($this->config);
    }

    /**
     * WordPress's root directory.
     *
     * The plugin sits at wp-content/plugins/<name>/, so the root is three levels
     * up. `wordpress_root` in the config overrides it for unusual layouts.
     */
    public function wordpressRoot(): string
    {
        $configured = (string) $this->config->get('wordpress_root', '');
        if ($configured !== '') {
            return rtrim($configured, '/');
        }

        return dirname(__DIR__, 4);
    }

    public function attachmentMeta(): AttachmentMeta
    {
        return $this->attachmentMeta ??= new AttachmentMeta($this->config, $this->wordpressRoot());
    }

    public function imageWriter(): ImageWriter
    {
        return $this->imageWriter ??= new ImageWriter($this->config, $this->wordpressRoot());
    }

    public function deleter(): ProductDeleter
    {
        // The WordPress root is needed so image FILES can be removed from disk,
        // not just their rows from the database.
        return $this->deleter ??= new ProductDeleter($this->db(), $this->wordpressRoot());
    }

    /**
     * Changes products that already exist.
     *
     * A separate object from the importer rather than a method on it, because the
     * two make opposite promises: `importer()` refuses to touch anything it has
     * seen before, and this one exists precisely to touch it. Sharing the class
     * would put "create" and "overwrite" one typo apart.
     */
    public function updater(): ProductUpdater
    {
        return $this->updater ??= new ProductUpdater(
            $this->db(),
            new TermRepository($this->db(), self::FN_PREFIX),
            self::FN_PREFIX
        );
    }

    public function importer(): ProductImporter
    {
        return $this->importer ??= new ProductImporter(
            $this->db(),
            new TermRepository($this->db(), self::FN_PREFIX),
            new MetaBuilder(),
            $this->attachmentMeta(),
            new Normalizer(),
            self::FN_PREFIX
        );
    }
}
