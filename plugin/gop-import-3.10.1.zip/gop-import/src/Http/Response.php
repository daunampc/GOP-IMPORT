<?php

namespace GopImport\Http;

/**
 * JSON out, with the RIGHT HTTP status.
 *
 * v2 always answered 200 with `status: "error"` in the body, which throws away
 * HTTP's own semantics: a proxy cannot retry, and monitoring cannot count
 * failures.
 */
final class Response
{
    public static function json(int $status, array $body): void
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('X-Content-Type-Options: nosniff');

        $json = json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);

        if ($json === false) {
            http_response_code(500);
            echo '{"error":{"code":"json_encode_failed","message":"The response could not be encoded"}}';
            return;
        }

        echo $json;
    }

    public static function ok(array $data): void
    {
        self::json(200, $data);
    }

    /**
     * 207 Multi-Status when a batch contains both failures and successes — the
     * client then knows to read the rows one by one rather than treating the
     * whole batch as done.
     *
     * @param array<int,array<string,mixed>> $results
     */
    public static function batch(array $results, float $elapsedMs): void
    {
        $failed = 0;
        foreach ($results as $result) {
            if (empty($result['ok'])) {
                $failed++;
            }
        }

        self::json($failed === 0 ? 200 : 207, [
            'total'      => count($results),
            'succeeded'  => count($results) - $failed,
            'failed'     => $failed,
            'elapsed_ms' => round($elapsedMs, 1),
            'results'    => $results,
        ]);
    }

    /**
     * @param array<string,mixed> $extra Added to the error object. Never overrides
     *                                   `code` or `message`.
     */
    public static function error(int $status, string $code, string $message, array $extra = []): void
    {
        self::json($status, ['error' => ['code' => $code, 'message' => $message] + $extra]);
    }
}
