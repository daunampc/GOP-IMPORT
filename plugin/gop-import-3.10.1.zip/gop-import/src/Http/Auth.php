<?php

namespace GopImport\Http;

use GopImport\Support\Config;

/**
 * HMAC-SHA256 authentication.
 *
 * v2 had NO authentication on any endpoint — knowing the directory name was full
 * access to the database. This is the single most important change in this
 * plugin.
 *
 * The client signs:  method \n path \n timestamp \n body
 * and sends three headers: X-TSD-Key / X-TSD-Timestamp / X-TSD-Signature.
 *
 * The header names keep their original spelling deliberately: they are the
 * contract with every build already installed on a site, and renaming them would
 * break all of them at once for no visible gain.
 *
 * Signing the body prevents the payload being altered in transit; binding a
 * timestamp prevents replay.
 */
final class Auth
{
    /** How far the clocks may disagree, in seconds. */
    private const MAX_CLOCK_SKEW = 300;

    private Config $config;

    public function __construct(Config $config)
    {
        $this->config = $config;
    }

    /**
     * @throws UnauthorizedException
     */
    public function verify(string $method, string $path, string $body): void
    {
        $secret = (string) $this->config->get('api_secret', '');
        if ($secret === '') {
            throw new UnauthorizedException('not_configured', 'api_secret is not configured. Run setup.php again.');
        }

        $key = $this->header('HTTP_X_TSD_KEY');
        $timestamp = $this->header('HTTP_X_TSD_TIMESTAMP');
        $signature = $this->header('HTTP_X_TSD_SIGNATURE');

        if ($key === '' || $timestamp === '' || $signature === '') {
            throw new UnauthorizedException('missing_credentials', 'Authentication headers are missing.');
        }

        $expectedKey = (string) $this->config->get('api_key', '');
        if ($expectedKey === '' || !hash_equals($expectedKey, $key)) {
            throw new UnauthorizedException('invalid_credentials', 'Authentication failed.');
        }

        if (!ctype_digit($timestamp)) {
            throw new UnauthorizedException('invalid_credentials', 'Authentication failed.');
        }

        $expected = hash_hmac('sha256', "$method\n$path\n$timestamp\n$body", $secret);

        // hash_equals compares in constant time — no timing attack.
        if (!hash_equals($expected, $signature)) {
            throw new UnauthorizedException('invalid_credentials', 'Authentication failed.');
        }

        /*
         * FRESHNESS IS CHECKED AFTER THE SIGNATURE, not before, and that order is the
         * whole point of this block.
         *
         * Two servers never agree on the time, and before 3.10.1 a site whose clock
         * differed from the managing app's by more than five minutes refused EVERY
         * request with the same words as a wrong secret — nothing on either side could
         * tell the operator which it was.
         *
         * Once the signature has verified, the caller is known to hold the secret, so it
         * is safe to tell THEM this site's clock. The app uses it to correct its own
         * timestamp and retry, which keeps the replay window at five minutes instead of
         * widening it to cover whatever the skew happens to be. A caller without the
         * secret never gets here: it is refused above, with the vague message, exactly
         * as before. The time of day is not a secret, but who may be told it still is a
         * decision.
         */
        $now = time();
        $skew = $now - (int) $timestamp;

        if (abs($skew) > self::MAX_CLOCK_SKEW) {
            error_log(sprintf(
                '[gop-import] stale request: the caller\'s clock is %d s %s this server\'s (limit %d s).',
                abs($skew),
                $skew > 0 ? 'behind' : 'ahead of',
                self::MAX_CLOCK_SKEW
            ));

            throw new UnauthorizedException('stale_request', 'Authentication failed.', ['server_time' => $now]);
        }
    }

    /**
     * Every cause deliberately produces the SAME vague message, so that someone
     * probing cannot tell "wrong key" from "wrong signature".
     */
    private function header(string $serverKey): string
    {
        return trim((string) ($_SERVER[$serverKey] ?? ''));
    }
}
