<?php

namespace GopImport\Http;

final class UnauthorizedException extends \RuntimeException
{
    // See the note in ValidationException: `$code` is a name Exception has
    // already taken.
    private string $errorCode;

    /** @var array<string,mixed> */
    private array $extra;

    /**
     * @param array<string,mixed> $extra Fields added to the error object in the
     *                                   response, beside `code` and `message`.
     */
    public function __construct(string $errorCode, string $message, array $extra = [])
    {
        parent::__construct($message);
        $this->errorCode = $errorCode;
        $this->extra = $extra;
    }

    /** @return array<string,mixed> */
    public function extra(): array
    {
        return $this->extra;
    }

    public function errorCode(): string
    {
        return $this->errorCode;
    }
}
