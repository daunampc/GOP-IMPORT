<?php

namespace GopImport\License;

/**
 * Asks the managing app whether a key is good, and writes down the answer.
 *
 * WordPress-only, on purpose: it uses the HTTP API, and it is called from the admin
 * screen and from a daily scheduled event. `index.php` never loads this file — it
 * only reads what this wrote, through `License`.
 *
 * The one rule that shapes it: A FAILURE TO REACH THE SERVER IS NOT A REFUSAL. Only
 * a definite answer — the server saying yes or saying no — is written down. Anything
 * else leaves the stored verdict exactly as it was, so an outage at the vendor cannot
 * turn into a shop that nobody can update. What limits that generosity is
 * `License::TRUST_DAYS`, after which a verdict nobody has been able to confirm stops
 * counting.
 */
final class Verifier
{
    /** Where the managing app's verify endpoint lives, under its base URL. */
    private const ROUTE = '/api/license/verify';

    /**
     * @return array{ok:bool,message:string,state:array}
     */
    public static function verify(string $key): array
    {
        $key = License::normalise($key);
        $appUrl = License::appUrl();
        $previous = License::state();

        if ($key === '') {
            return [
                'ok' => false,
                'message' => 'Enter your licence key.',
                'state' => $previous,
            ];
        }

        /*
         * NO SERVER CONFIGURED — accept the key here, and say that is what happened.
         *
         * This is the build's testing state, switched by one constant
         * (`GOP_IMPORT_APP_URL` in gop-import.php): empty accepts a key locally, an
         * address restores real checking with nothing else to change.
         *
         * It is written down as valid so the API works, and `verified_at` is stamped so
         * the state file reads the same shape either way — but every screen that shows
         * it says "not verified", and `/health` reports `verified: false`. A build in
         * this state accepts ANY key, so it is not one to hand to a customer.
         */
        if ($appUrl === '') {
            $state = [
                'key' => $key,
                'status' => License::STATUS_VALID,
                'reason' => 'local',
                'expires_at' => null,
                'verified_at' => gmdate('c'),
                'app_url' => '',
            ];

            if (!License::save($state)) {
                return [
                    'ok' => false,
                    'message' => 'Could not save the licence: config/ is not writable by PHP.',
                    'state' => $previous,
                ];
            }

            return [
                'ok' => true,
                'message' => 'Key saved. This build has no activation server, so it was not checked.',
                'state' => $state,
            ];
        }

        if (!preg_match('#^https?://#i', $appUrl)) {
            return [
                'ok' => false,
                'message' => 'The activation server address in this build is not a valid URL.',
                'state' => $previous,
            ];
        }

        $response = wp_remote_post($appUrl . self::ROUTE, [
            'timeout' => 15,
            'headers' => ['Content-Type' => 'application/json', 'Accept' => 'application/json'],
            'body' => wp_json_encode([
                'key' => $key,
                // So the operator can see which sites are using a key. It is the
                // site's own address and nothing more.
                'siteUrl' => home_url(),
                'pluginVersion' => defined('GOP_IMPORT_VERSION') ? GOP_IMPORT_VERSION : '',
            ]),
        ]);

        if (is_wp_error($response)) {
            // Nothing is written. The previous verdict stands for its window.
            return [
                'ok' => false,
                'message' => 'Could not reach the activation server. Nothing changed — try again.',
                'state' => $previous,
            ];
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        $payload = json_decode((string) wp_remote_retrieve_body($response), true);

        if ($code >= 500 || !is_array($payload) || !array_key_exists('valid', $payload)) {
            // A 500 or a body that is not the answer we asked for is the server
            // failing, not the key failing. Same treatment as unreachable.
            return [
                'ok' => false,
                'message' => "The activation server answered HTTP $code. Nothing changed — try again.",
                'state' => $previous,
            ];
        }

        $valid = $payload['valid'] === true;

        $state = [
            'key' => $key,
            'status' => $valid ? License::STATUS_VALID : License::STATUS_INVALID,
            'reason' => is_string($payload['status'] ?? null) ? $payload['status'] : ($valid ? '' : 'refused'),
            'expires_at' => is_string($payload['expiresAt'] ?? null) ? $payload['expiresAt'] : null,
            'verified_at' => gmdate('c'),
            'app_url' => $appUrl,
        ];

        if (!License::save($state)) {
            return [
                'ok' => false,
                'message' => 'Could not save the licence: config/ is not writable by PHP.',
                'state' => $previous,
            ];
        }

        return [
            'ok' => $valid,
            'message' => $valid
                ? 'Activated.' . ($state['expires_at'] === null
                    ? ''
                    : ' Valid until ' . License::day($state['expires_at']) . '.')
                : 'Licence key rejected' . ($state['reason'] === '' ? '' : ' (' . $state['reason'] . ')') . '.',
            'state' => $state,
        ];
    }

    /** The daily re-check. Silent: nobody is watching, and nothing here can be answered. */
    public static function recheck(): void
    {
        $state = License::state();

        // Nothing to re-check without a server, and re-stamping the file daily for no
        // reason would only churn it.
        if (License::normalise($state['key']) === '' || License::appUrl() === '') {
            return;
        }

        self::verify($state['key']);
    }
}
