<?php

namespace GopImport\License;

/**
 * The activation key for this installation, and whether it currently allows writing.
 *
 * WHY A FILE AND NOT AN OPTION. `index.php` — the API, the thing that has to be
 * gated — deliberately does not load WordPress. That is why an import of 14,000
 * products is measured in minutes. So it cannot read `wp_options`, and the licence
 * state has to live somewhere both halves can reach: `config/license.json`, beside
 * `config/config.ini`, behind the same `.htaccess` deny and the same directory
 * guard. The admin screen (which has WordPress) writes it; the API only reads it.
 *
 * WHAT IS STORED, and what is deliberately not. The key itself is kept, because the
 * daily re-check has to send it again. What never leaves this file is the key: the
 * only thing the API reports is a FINGERPRINT — a SHA-256 of the normalised key —
 * so the managing app can confirm the site is running its own account's key without
 * the key ever travelling back out of the site.
 *
 * The verdict is deliberately generous in one direction. A stored "valid" stands for
 * its full window even when the licence server cannot be reached, because the
 * failure mode of the other choice is unacceptable: an outage at the vendor would
 * become a shop that cannot be updated. Only a definite answer from the server
 * changes a verdict — see `Verifier`.
 */
final class License
{
    /**
     * How long a successful check is trusted without another one.
     *
     * Fourteen days rather than a day: the re-check runs daily, so this is the
     * number of consecutive failures it takes before a site is treated as
     * unlicensed — two weeks of the vendor being unreachable, which is an outage
     * nobody would describe as temporary.
     */
    public const TRUST_DAYS = 14;

    public const STATUS_VALID = 'valid';
    public const STATUS_INVALID = 'invalid';

    /**
     * Routes the gate lets through when there is no valid key: NONE.
     *
     * This was writes-only, and the product owner changed it to everything. The
     * objection to a full block was that the managing app could no longer tell "this
     * site has no licence" apart from "this site is unreachable" — and that objection
     * is answered by HOW this blocks rather than by letting reads through: every
     * refusal is a normal JSON error carrying a machine-readable `license_*` code, so
     * an unlicensed site says exactly what is wrong with it. A site that cannot be
     * reached says nothing at all. The two remain distinguishable, and the app reports
     * them differently.
     *
     * Kept as an explicit empty list rather than deleted, because "which routes are
     * exempt" is the question somebody will ask again.
     */
    public const EXEMPT_ROUTES = [];

    /**
     * Where the managing app lives, from the build's own constant.
     *
     * Not from `license.json` and not from an option: one address for every
     * installation, set in `gop-import.php`, overridable per site from
     * `wp-config.php`. The API half of the plugin never needs it — it only reads the
     * verdict — so an empty string here is normal inside `index.php`.
     */
    public static function appUrl(): string
    {
        return defined('GOP_IMPORT_APP_URL') ? rtrim((string) GOP_IMPORT_APP_URL, '/') : '';
    }

    public static function path(): string
    {
        return dirname(__DIR__, 2) . '/config/license.json';
    }

    /**
     * Uppercase, no spaces — the same normalisation the managing app applies, so a
     * key pasted out of a chat message with a stray space still matches, and so the
     * fingerprint computed here equals the one computed there.
     */
    public static function normalise(string $key): string
    {
        return strtoupper(preg_replace('/\s+/', '', trim($key)) ?? '');
    }

    /** SHA-256 of the normalised key. Never reversible into the key itself. */
    public static function fingerprint(string $key): string
    {
        $normalised = self::normalise($key);

        return $normalised === '' ? '' : hash('sha256', $normalised);
    }

    /**
     * @return array{key:string,status:string,reason:string,expires_at:?string,verified_at:?string,app_url:string}
     */
    public static function state(): array
    {
        $empty = [
            'key' => '',
            'status' => self::STATUS_INVALID,
            'reason' => 'license_missing',
            'expires_at' => null,
            'verified_at' => null,
            'app_url' => '',
        ];

        $path = self::path();

        if (!file_exists($path)) {
            return $empty;
        }

        $raw = @file_get_contents($path);
        $parsed = $raw === false ? null : json_decode($raw, true);

        if (!is_array($parsed)) {
            // A corrupted file is treated as no licence rather than as a valid one.
            // The failure has to fall on the safe side of the gate.
            return $empty;
        }

        return [
            'key' => is_string($parsed['key'] ?? null) ? $parsed['key'] : '',
            'status' => ($parsed['status'] ?? '') === self::STATUS_VALID
                ? self::STATUS_VALID
                : self::STATUS_INVALID,
            'reason' => is_string($parsed['reason'] ?? null) ? $parsed['reason'] : '',
            'expires_at' => is_string($parsed['expires_at'] ?? null) ? $parsed['expires_at'] : null,
            'verified_at' => is_string($parsed['verified_at'] ?? null) ? $parsed['verified_at'] : null,
            'app_url' => is_string($parsed['app_url'] ?? null) ? $parsed['app_url'] : '',
        ];
    }

    /** Write the state. Returns false rather than throwing: the caller reports it. */
    public static function save(array $state): bool
    {
        $encoded = json_encode($state, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);

        if ($encoded === false) {
            return false;
        }

        $path = self::path();
        $written = @file_put_contents($path, $encoded . "\n", LOCK_EX);

        if ($written === false) {
            return false;
        }

        // The key is in here. 0600 where the host allows it; a failure to chmod is
        // not worth failing the save over, because `.htaccess` and the directory
        // guard are the defence that actually holds on a shared host.
        @chmod($path, 0600);

        return true;
    }

    /**
     * Is this installation allowed to write right now, and if not, why?
     *
     * @return array{allowed:bool,code:string,message:string}
     */
    public static function verdict(?array $state = null, ?int $now = null): array
    {
        $state ??= self::state();
        $now ??= time();

        if (self::normalise($state['key']) === '') {
            return [
                'allowed' => false,
                'code' => 'license_missing',
                'message' => 'Not activated. Enter your licence key in wp-admin under GOP_IMPORT.',
            ];
        }

        if ($state['status'] !== self::STATUS_VALID) {
            return [
                'allowed' => false,
                'code' => 'license_invalid',
                'message' => 'Licence key rejected'
                    . ($state['reason'] === '' ? '' : ' (' . $state['reason'] . ')') . '.',
            ];
        }

        if ($state['expires_at'] !== null) {
            $expires = strtotime($state['expires_at']);

            if ($expires !== false && $expires <= $now) {
                return [
                    'allowed' => false,
                    'code' => 'license_expired',
                    'message' => 'Licence expired on ' . self::day($state['expires_at']) . '.',
                ];
            }
        }

        /*
         * NO ACTIVATION SERVER CONFIGURED — the local mode.
         *
         * With `GOP_IMPORT_APP_URL` empty, a key is accepted on this site and checked
         * with nobody. Staleness is meaningless then: there is no server that could
         * confirm it, so counting days since the last confirmation would switch the
         * plugin off for failing to do something it was never asked to do.
         *
         * Deliberate and reversible: this is the state a build ships in for testing,
         * and putting an address back in that one constant restores real checking with
         * no other change. What it means while it lasts is stated everywhere it shows —
         * in wp-admin, and in `/health` as `verified: false` — because "Active" on a
         * screen when nothing was verified would be the screen lying.
         *
         * READ FROM THE STATE FILE, NOT FROM THE CONSTANT, and that distinction is not
         * cosmetic. `index.php` — where this gate actually runs — does not load
         * WordPress and therefore never sees `GOP_IMPORT_APP_URL` at all. Reading the
         * constant here would make the API believe EVERY installation was in local mode
         * and skip the staleness check on all of them. The state file is written by the
         * admin screen, which does have the constant, and is the one thing both
         * processes can see.
         */
        if ($state['app_url'] === '') {
            return [
                'allowed' => true,
                'code' => 'license_local',
                'message' => 'Active (not verified — no activation server in this build)',
            ];
        }

        $verifiedAt = $state['verified_at'] === null ? false : strtotime($state['verified_at']);

        if ($verifiedAt === false) {
            return [
                'allowed' => false,
                'code' => 'license_unverified',
                'message' => 'Licence key not confirmed yet. Activate it in wp-admin under GOP_IMPORT.',
            ];
        }

        if ($verifiedAt + self::TRUST_DAYS * 86400 <= $now) {
            return [
                'allowed' => false,
                'code' => 'license_stale',
                'message' => 'Licence not confirmed since ' . self::day($state['verified_at'])
                    . '. Check it again in wp-admin under GOP_IMPORT.',
            ];
        }

        return ['allowed' => true, 'code' => 'license_valid', 'message' => 'Active'];
    }

    /**
     * A date somebody can read.
     *
     * The stored values are ISO 8601 because that is what the API exchanges; a dialog
     * showing `2026-08-18T02:41:07+00:00` to a shop owner is showing them a timestamp
     * format, not a date.
     */
    public static function day(?string $iso): string
    {
        if ($iso === null) {
            return 'an unknown date';
        }

        $time = strtotime($iso);

        return $time === false ? $iso : gmdate('j M Y', $time);
    }

    /** What `/health` reports: enough to diagnose, never the key. */
    public static function report(?array $state = null): array
    {
        $state ??= self::state();
        $verdict = self::verdict($state);

        return [
            'active' => $verdict['allowed'],
            'code' => $verdict['code'],
            'fingerprint' => self::fingerprint($state['key']),
            'expires_at' => $state['expires_at'],
            'verified_at' => $state['verified_at'],
            /*
             * Whether a SERVER said yes, as opposed to this site accepting a key on its
             * own because no server is configured. The managing app still compares the
             * fingerprint either way — "the same key on both sides" does not depend on
             * this — but it must be able to tell the two apart rather than infer it.
             */
            'verified' => $state['app_url'] !== '',
        ];
    }
}
