<?php

namespace GopImport\Import;

use GopImport\Db\Connection;

/**
 * Finds and deletes products, and removes EVERY dependent row with them.
 *
 * Why the inherited `delete_product_by_id` stored function is not used: it
 * hard-codes the `wp_` prefix, and it misses almost everything `create_product`
 * wrote — term_relationships, wc_product_meta_lookup, attachments, comments,
 * commentmeta. Deleting with it leaves a site full of orphans: images still in
 * the Media library, category counts still counting products that are gone, and
 * lookup rows still pointing at posts that no longer exist.
 *
 * Three principles, exactly as in ProductImporter:
 *
 *  1. Each product sits in ONE transaction. A failure partway through leaves that
 *     product intact rather than half-deleted.
 *  2. Prepared statements for every statement, including the IN lists.
 *  3. Count each table and return the numbers, so the interface can PROVE nothing
 *     was left behind rather than merely claiming it was deleted.
 */
final class ProductDeleter
{
    /** Ceiling on products returned WITH A SUMMARY by one lookup. */
    public const MAX_LOOKUP_LIMIT = 500;

    /**
     * Ceiling on the ids the `ids_only` mode returns.
     *
     * Far higher than MAX_LOOKUP_LIMIT, deliberately. What makes a lookup
     * expensive is not the id list — the ids are already in the index — but the
     * four summary queries that accompany each product: sku and price, variation
     * count, type, categories. Drop the summary and tens of thousands of ids come
     * back in one cheap statement.
     *
     * There is still a ceiling, because a shop with five million products should
     * not exhaust PHP's memory. On reaching it `truncated` says so, rather than
     * silently returning less than was asked for.
     */
    public const MAX_LOOKUP_IDS = 100000;

    /** How deep the sub-category walk goes. Stops a cycle in corrupt term data. */
    private const MAX_CATEGORY_DEPTH = 10;

    private Connection $db;

    private string $wordpressRoot;

    public function __construct(Connection $db, string $wordpressRoot)
    {
        $this->db = $db;
        $this->wordpressRoot = rtrim($wordpressRoot, '/');
    }

    /* ------------------------------------------------------------- lookup */

    /**
     * Find the products a filter matches, deleting NOTHING.
     *
     * Kept entirely separate from the delete command on purpose: the operator sees
     * exactly what matched and then confirms that list, rather than trusting a
     * filter to mean what they thought it meant.
     *
     * Two modes:
     *  - default: one page of products WITH a summary, for reading (at most
     *    MAX_LOOKUP_LIMIT);
     *  - `ids_only`: ids alone, no summary, up to MAX_LOOKUP_IDS — so that one
     *    removal covers the whole selection instead of its first 500 products.
     *
     * @param array<string,mixed> $filter
     * @return array{total:int, products:array<int,array<string,mixed>>, ids:array<int,int>, truncated:bool}
     */
    public function lookup(array $filter): array
    {
        [$where, $params] = $this->buildFilter($filter);

        $limit = (int) ($filter['limit'] ?? 100);
        $limit = max(1, min($limit, self::MAX_LOOKUP_LIMIT));
        $offset = max(0, (int) ($filter['offset'] ?? 0));

        $posts = $this->db->table('posts');

        $total = (int) $this->db->scalar(
            "SELECT COUNT(*) FROM $posts p WHERE $where",
            $params
        );

        if ($total === 0) {
            return ['total' => 0, 'products' => [], 'ids' => [], 'truncated' => false];
        }

        /*
         * The ids-only mode.
         *
         * It exists so that ONE removal covers the whole selection. The screen used
         * to be able to fetch only 500 products at a time, so "every product on the
         * site" against a 3000-product shop deleted 500 and reported success — the
         * rest stayed where they were.
         *
         * It does not break what makes the screen safe: a filter is STILL not the
         * thing that executes. This mode returns exactly the ids that matched at the
         * moment of looking; the operator confirms that list, and the delete command
         * still accepts ids and never a filter.
         */
        if (!empty($filter['ids_only'])) {
            $capped = self::MAX_LOOKUP_IDS;

            $rows = $this->db->rows(
                "SELECT p.ID FROM $posts p WHERE $where ORDER BY p.ID LIMIT $capped",
                $params
            );

            $ids = array_map(static fn (array $row): int => (int) $row['ID'], $rows);

            return [
                'total'     => $total,
                'ids'       => $ids,
                'products'  => [],
                'truncated' => count($ids) < $total,
            ];
        }

        $rows = $this->db->rows(
            "SELECT p.ID, p.post_title, p.post_name, p.post_status, p.post_date
             FROM $posts p
             WHERE $where
             ORDER BY p.ID
             LIMIT $limit OFFSET $offset",
            $params
        );

        $ids = array_map(static fn (array $row): int => (int) $row['ID'], $rows);

        $skusAndPrices = $this->skuAndPrice($ids);
        $childCounts = $this->childCounts($ids);
        $types = $this->productTypes($ids);
        $categories = $this->categoryNames($ids);
        $imageFlags = $this->imageFlags($ids);

        $products = [];
        foreach ($rows as $row) {
            $id = (int) $row['ID'];

            $products[] = [
                'product_id'      => $id,
                'name'            => (string) $row['post_title'],
                'sku'             => $skusAndPrices[$id]['sku'] ?? '',
                'slug'            => (string) $row['post_name'],
                'type'            => $types[$id] ?? 'simple',
                'status'          => (string) $row['post_status'],
                'price'           => $skusAndPrices[$id]['price'] ?? '',
                // Added for the product screen. `price` is what a shopper sees;
                // these are what an edit actually writes.
                'regular_price'   => $skusAndPrices[$id]['regular_price'] ?? '',
                'sale_price'      => $skusAndPrices[$id]['sale_price'] ?? '',
                'stock'           => $skusAndPrices[$id]['stock'] ?? '',
                'manage_stock'    => ($skusAndPrices[$id]['manage_stock'] ?? 'no') === 'yes',
                'variation_count' => $childCounts[$id]['variations'] ?? 0,
                'image_count'     => $childCounts[$id]['attachments'] ?? 0,
                /*
                 * Whether it has an image AT ALL, which `image_count` cannot answer:
                 * that counts attachment children, and a product whose images are
                 * external URLs (the default import mode) has none of those while
                 * showing pictures in the shop. Same definition the filter uses.
                 */
                'has_image'       => $imageFlags[$id] ?? false,
                'categories'      => $categories[$id] ?? [],
                'created_at'      => (string) $row['post_date'],
            ];
        }

        return [
            'total'     => $total,
            'products'  => $products,
            // Empty in summary mode: each product already carries its own id. The
            // key is still returned so both modes have the same response shape.
            'ids'       => [],
            'truncated' => $total > $offset + count($products),
        ];
    }

    /**
     * What counts as "this product has an image" — ONE definition, two callers.
     *
     * Used by the `without_images` filter and by the `has_image` flag on every row it
     * returns, deliberately from the same method: an operator reading a list of
     * products to delete must be reading the same question the filter asked. Two
     * definitions would drift, and the drift would show up as a product in the list
     * that visibly has a picture.
     *
     * THREE ways this plugin attaches an image, and missing the third is the mistake
     * that would matter most:
     *
     *  - `_thumbnail_id` — an attachment, from the "copy into the media library" mode;
     *  - `_product_image_gallery` — a comma list of attachment ids;
     *  - `fifu_image_url` — an external URL, which is what the DEFAULT image mode
     *    writes. Leave it out and every product imported with "keep the original
     *    links" reads as having no image, and this feature becomes a way to delete a
     *    whole catalogue.
     *
     * A VARIATION's image counts as the parent having one. A variable product whose
     * variations carry pictures shows pictures in the shop, whatever the parent row
     * says — and in a delete command the conservative reading is the only defensible
     * one.
     */
    private function hasImageSql(string $alias): string
    {
        $postmeta = $this->db->table('postmeta');
        $posts = $this->db->table('posts');

        return "(
            EXISTS (
                SELECT 1 FROM $postmeta pmi
                WHERE pmi.post_id = $alias.ID
                  AND (
                        (pmi.meta_key = '_thumbnail_id' AND pmi.meta_value NOT IN ('', '0'))
                     OR (pmi.meta_key = '_product_image_gallery' AND pmi.meta_value <> '')
                     OR (pmi.meta_key = 'fifu_image_url' AND pmi.meta_value <> '')
                  )
            )
            OR EXISTS (
                SELECT 1 FROM $posts vp
                JOIN $postmeta vpm ON vpm.post_id = vp.ID
                WHERE vp.post_parent = $alias.ID
                  AND vp.post_type = 'product_variation'
                  AND (
                        (vpm.meta_key = '_thumbnail_id' AND vpm.meta_value NOT IN ('', '0'))
                     OR (vpm.meta_key = 'fifu_image_url' AND vpm.meta_value <> '')
                  )
            )
        )";
    }

    /**
     * Which of these products have an image. Keyed by id, one query.
     *
     * @param array<int,int> $ids
     * @return array<int,bool>
     */
    private function imageFlags(array $ids): array
    {
        if ($ids === []) {
            return [];
        }

        $posts = $this->db->table('posts');
        $placeholders = $this->placeholders(count($ids));

        $rows = $this->db->rows(
            "SELECT p.ID, {$this->hasImageSql('p')} AS has_image
             FROM $posts p
             WHERE p.ID IN ($placeholders)",
            $ids
        );

        $flags = [];
        foreach ($rows as $row) {
            $flags[(int) $row['ID']] = (int) $row['has_image'] === 1;
        }

        return $flags;
    }

    /**
     * The complete WHERE clause: a selection, optionally narrowed.
     *
     * @param array<string,mixed> $filter
     * @return array{0:string, 1:array<int,mixed>}
     */
    private function buildFilter(array $filter): array
    {
        [$where, $params] = $this->buildSelection($filter);

        /*
         * NARROWING, applied on top of the selection — never instead of it.
         *
         * `name` and `status` are additional AND clauses, and one of the four
         * selections is still required. That keeps the guarantee this method has
         * always made: an empty filter never quietly means everything. A caller
         * searching a catalogue by name passes `all: true` as well, saying out loud
         * that the search runs over the whole catalogue.
         *
         * Only the lookup reaches this. The delete command accepts ids and no filter
         * at all, so nothing here can widen what a delete covers.
         */
        $name = isset($filter['name']) ? trim((string) $filter['name']) : '';

        if ($name !== '') {
            // LIKE with both wildcards, the same as wp-admin's own product search.
            // `%` and `_` in the search text are escaped so a SKU containing one does
            // not silently become a wildcard.
            $escaped = str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $name);
            $where .= " AND p.post_title LIKE ?";
            $params[] = '%' . $escaped . '%';
        }

        $status = isset($filter['status']) ? trim((string) $filter['status']) : '';

        if ($status !== '') {
            if (!in_array($status, ['publish', 'draft', 'pending', 'private', 'future'], true)) {
                throw new ValidationException(
                    'invalid_status',
                    '`status` must be publish, draft, pending, private or future.'
                );
            }
            $where .= " AND p.post_status = ?";
            $params[] = $status;
        }

        /*
         * Products with NO image.
         *
         * A narrowing like the two above, so it still cannot mean "everything" on its
         * own — one of the four selections is required alongside it. That matters more
         * here than for `name`: this one exists to feed a DELETE, and a filter that
         * quietly widened to the whole catalogue is the failure this method's shape has
         * always been built to prevent.
         *
         * Only `without_images: true` does anything. `false` is not "products WITH an
         * image" — asking for that has no use here and answering it would double the
         * surface for no caller.
         */
        if (!empty($filter['without_images'])) {
            $where .= ' AND NOT ' . $this->hasImageSql('p');
        }

        return [$where, $params];
    }

    /**
     * The four selections: by id, by SKU, by category, or everything.
     *
     * @param array<string,mixed> $filter
     * @return array{0:string, 1:array<int,mixed>}
     */
    private function buildSelection(array $filter): array
    {
        $posts = $this->db->table('posts');
        $postmeta = $this->db->table('postmeta');
        $relationships = $this->db->table('term_relationships');

        $base = "p.post_type = 'product'";

        if (!empty($filter['product_ids'])) {
            $ids = $this->intList($filter['product_ids'], 'product_ids');
            $placeholders = $this->placeholders(count($ids));

            return ["$base AND p.ID IN ($placeholders)", $ids];
        }

        if (!empty($filter['skus'])) {
            $skus = $this->stringList($filter['skus'], 'skus');
            $placeholders = $this->placeholders(count($skus));

            return [
                "$base AND EXISTS (
                    SELECT 1 FROM $postmeta pm
                    WHERE pm.post_id = p.ID AND pm.meta_key = '_sku' AND pm.meta_value IN ($placeholders)
                )",
                $skus,
            ];
        }

        if (isset($filter['category']) && trim((string) $filter['category']) !== '') {
            // Sub-categories count too. Choosing "Clothing" and deleting only the
            // products attached directly to it, skipping "Clothing > T-shirts", is
            // the worst kind of technically-right-and-wrong in a delete command.
            $taxonomyIds = $this->categoryTaxonomyIds((string) $filter['category']);

            if ($taxonomyIds === []) {
                // No category matched, so NO product matches. Return a clause that
                // is always false, rather than dropping the filter and matching
                // everything.
                return ['1 = 0', []];
            }

            $placeholders = $this->placeholders(count($taxonomyIds));

            return [
                "$base AND EXISTS (
                    SELECT 1 FROM $relationships tr
                    WHERE tr.object_id = p.ID AND tr.term_taxonomy_id IN ($placeholders)
                )",
                $taxonomyIds,
            ];
        }

        if (!empty($filter['all'])) {
            return [$base, []];
        }

        throw new ValidationException(
            'empty_filter',
            'One of these is required: product_ids, skus, category, or all=true.'
        );
    }

    /**
     * A category by NAME or SLUG, plus its entire subtree.
     *
     * A hierarchical path such as "Clothing > T-shirts" is accepted too — the last
     * segment is used, because that is the category actually attached to products.
     *
     * @return array<int,int> term_taxonomy_id
     */
    private function categoryTaxonomyIds(string $category): array
    {
        $segments = array_filter(array_map('trim', explode('>', $category)));
        $name = $segments === [] ? trim($category) : (string) end($segments);

        $terms = $this->db->table('terms');
        $taxonomies = $this->db->table('term_taxonomy');

        $roots = $this->db->rows(
            "SELECT tt.term_taxonomy_id, tt.term_id
             FROM $terms t
             INNER JOIN $taxonomies tt ON tt.term_id = t.term_id
             WHERE tt.taxonomy = 'product_cat' AND (t.name = ? OR t.slug = ?)",
            [$name, $name]
        );

        if ($roots === []) {
            return [];
        }

        $taxonomyIds = [];
        $frontier = [];

        foreach ($roots as $row) {
            $taxonomyIds[] = (int) $row['term_taxonomy_id'];
            $frontier[] = (int) $row['term_id'];
        }

        for ($depth = 0; $depth < self::MAX_CATEGORY_DEPTH && $frontier !== []; $depth++) {
            $placeholders = $this->placeholders(count($frontier));

            $children = $this->db->rows(
                "SELECT term_taxonomy_id, term_id FROM $taxonomies
                 WHERE taxonomy = 'product_cat' AND parent IN ($placeholders)",
                $frontier
            );

            $frontier = [];
            foreach ($children as $row) {
                $taxonomyId = (int) $row['term_taxonomy_id'];
                if (in_array($taxonomyId, $taxonomyIds, true)) {
                    continue;
                }
                $taxonomyIds[] = $taxonomyId;
                $frontier[] = (int) $row['term_id'];
            }
        }

        return $taxonomyIds;
    }

    /**
     * SKU, the three prices and the stock, for a page of products.
     *
     * The regular price, the sale price and the stock were added for the product
     * management screen, and they are not decoration there: a screen that offers to
     * change a price has to show which price it is about to change, and a bulk
     * percentage has to be computed from the REGULAR price rather than from the
     * displayed one — applying a discount to an already-discounted number compounds
     * it, quietly, on every run.
     *
     * Still one statement. Three more `meta_key` values in the same `IN (…)` is the
     * same index scan, which is why the summary ceiling of 500 does not move.
     *
     * @param array<int,int> $ids
     * @return array<int,array{sku:string, price:string, regular_price:string, sale_price:string, stock:string, manage_stock:string}>
     */
    private function skuAndPrice(array $ids): array
    {
        if ($ids === []) {
            return [];
        }

        $postmeta = $this->db->table('postmeta');
        $placeholders = $this->placeholders(count($ids));

        $keys = ['_sku', '_price', '_regular_price', '_sale_price', '_stock', '_manage_stock'];
        $keyPlaceholders = $this->placeholders(count($keys));

        $rows = $this->db->rows(
            "SELECT post_id, meta_key, meta_value FROM $postmeta
             WHERE post_id IN ($placeholders) AND meta_key IN ($keyPlaceholders)",
            [...$ids, ...$keys]
        );

        $fields = [
            '_sku'           => 'sku',
            '_price'         => 'price',
            '_regular_price' => 'regular_price',
            '_sale_price'    => 'sale_price',
            '_stock'         => 'stock',
            '_manage_stock'  => 'manage_stock',
        ];

        $empty = [
            'sku'           => '',
            'price'         => '',
            'regular_price' => '',
            'sale_price'    => '',
            'stock'         => '',
            'manage_stock'  => 'no',
        ];

        $out = [];
        foreach ($rows as $row) {
            $id = (int) $row['post_id'];
            $out[$id] ??= $empty;

            $field = $fields[(string) $row['meta_key']] ?? null;
            if ($field !== null) {
                $out[$id][$field] = (string) $row['meta_value'];
            }
        }

        return $out;
    }

    /**
     * Count variations and images in ONE statement, not one per product.
     *
     * @param array<int,int> $ids
     * @return array<int,array{variations:int, attachments:int}>
     */
    private function childCounts(array $ids): array
    {
        if ($ids === []) {
            return [];
        }

        $posts = $this->db->table('posts');
        $placeholders = $this->placeholders(count($ids));

        $rows = $this->db->rows(
            "SELECT post_parent, post_type, COUNT(*) AS total FROM $posts
             WHERE post_parent IN ($placeholders)
               AND post_type IN ('product_variation', 'attachment')
             GROUP BY post_parent, post_type",
            $ids
        );

        $out = [];
        foreach ($rows as $row) {
            $id = (int) $row['post_parent'];
            $out[$id] ??= ['variations' => 0, 'attachments' => 0];

            if ($row['post_type'] === 'product_variation') {
                $out[$id]['variations'] = (int) $row['total'];
            } else {
                $out[$id]['attachments'] = (int) $row['total'];
            }
        }

        return $out;
    }

    /**
     * @param array<int,int> $ids
     * @return array<int,string>
     */
    private function productTypes(array $ids): array
    {
        return $this->termNamesFor($ids, 'product_type', true);
    }

    /**
     * @param array<int,int> $ids
     * @return array<int,array<int,string>>
     */
    private function categoryNames(array $ids): array
    {
        /** @var array<int,array<int,string>> $names */
        $names = $this->termNamesFor($ids, 'product_cat', false);
        return $names;
    }

    /**
     * @param array<int,int> $ids
     * @return array<int,mixed> a string when $single, otherwise an array of strings
     */
    private function termNamesFor(array $ids, string $taxonomy, bool $single): array
    {
        if ($ids === []) {
            return [];
        }

        $terms = $this->db->table('terms');
        $taxonomies = $this->db->table('term_taxonomy');
        $relationships = $this->db->table('term_relationships');
        $placeholders = $this->placeholders(count($ids));

        $rows = $this->db->rows(
            "SELECT tr.object_id, t.name
             FROM $relationships tr
             INNER JOIN $taxonomies tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
             INNER JOIN $terms t ON t.term_id = tt.term_id
             WHERE tr.object_id IN ($placeholders) AND tt.taxonomy = ?
             ORDER BY t.name",
            [...$ids, $taxonomy]
        );

        $out = [];
        foreach ($rows as $row) {
            $id = (int) $row['object_id'];
            if ($single) {
                $out[$id] ??= (string) $row['name'];
            } else {
                $out[$id][] = (string) $row['name'];
            }
        }

        return $out;
    }

    /* ------------------------------------------------------------- delete */

    /**
     * Delete a batch. Each product succeeds or fails on its own, as in importBatch.
     *
     * @param array<int,int> $productIds
     * @return array<int,array<string,mixed>>
     */
    public function deleteBatch(array $productIds, bool $deleteImages): array
    {
        $results = [];

        foreach ($productIds as $productId) {
            try {
                $results[] = [
                    'product_id' => $productId,
                    'ok'         => true,
                    'removed'    => $this->deleteOne($productId, $deleteImages),
                ];
            } catch (ValidationException $e) {
                $results[] = [
                    'product_id' => $productId,
                    'ok'         => false,
                    'error'      => ['code' => $e->errorCode(), 'message' => $e->getMessage()],
                ];
            } catch (\Throwable $e) {
                $results[] = [
                    'product_id' => $productId,
                    'ok'         => false,
                    'error'      => ['code' => 'delete_failed', 'message' => $e->getMessage()],
                ];
            }
        }

        return $results;
    }

    /**
     * Delete one product and everything hanging off it.
     *
     * ORDER MATTERS: collect the child ids BEFORE deleting the parent rows. Delete
     * from `posts` first and then go looking for the variations' postmeta, and
     * `WHERE post_parent = ?` finds nothing — exactly the trap the inherited stored
     * function fell into.
     *
     * @return array<string,int>
     */
    private function deleteOne(int $productId, bool $deleteImages): array
    {
        if ($productId <= 0) {
            throw new ValidationException('invalid_id', "Invalid product_id: $productId.");
        }

        $posts = $this->db->table('posts');
        $postmeta = $this->db->table('postmeta');
        $comments = $this->db->table('comments');
        $commentmeta = $this->db->table('commentmeta');
        $relationships = $this->db->table('term_relationships');
        $taxonomies = $this->db->table('term_taxonomy');
        $termmeta = $this->db->table('termmeta');
        $lookup = $this->db->table('wc_product_meta_lookup');
        $importLog = $this->db->table('tsd_import_log');

        $type = $this->db->scalar("SELECT post_type FROM $posts WHERE ID = ? LIMIT 1", [$productId]);

        if ($type === null) {
            throw new ValidationException('not_found', "There is no post with id $productId.");
        }

        if ($type !== 'product') {
            throw new ValidationException(
                'not_a_product',
                "id $productId is post_type '$type', not 'product'."
            );
        }

        // --- collect the child ids BEFORE deleting anything ---

        $variationIds = array_map(
            static fn (array $row): int => (int) $row['ID'],
            $this->db->rows(
                "SELECT ID FROM $posts WHERE post_parent = ? AND post_type = 'product_variation'",
                [$productId]
            )
        );

        // Images hang off both the parent product and each variation.
        $imageParents = [$productId, ...$variationIds];
        $attachmentIds = array_map(
            static fn (array $row): int => (int) $row['ID'],
            $this->db->rows(
                "SELECT ID FROM $posts
                 WHERE post_parent IN ({$this->placeholders(count($imageParents))})
                   AND post_type = 'attachment'",
                $imageParents
            )
        );

        $files = $deleteImages ? $this->attachedFiles($attachmentIds) : [];

        $commentIds = array_map(
            static fn (array $row): int => (int) $row['comment_ID'],
            $this->db->rows(
                "SELECT comment_ID FROM $comments WHERE comment_post_ID = ?",
                [$productId]
            )
        );

        // A term's count must drop by exactly the number of relationships removed,
        // so read them first.
        $termRows = $this->db->rows(
            "SELECT tr.term_taxonomy_id, tt.term_id, tt.taxonomy
             FROM $relationships tr
             INNER JOIN $taxonomies tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
             WHERE tr.object_id = ?",
            [$productId]
        );

        $allPostIds = [$productId, ...$variationIds, ...$attachmentIds];

        $removed = [
            'posts'              => 0,
            'postmeta'           => 0,
            'term_relationships' => 0,
            'lookup'             => 0,
            'comments'           => 0,
            'commentmeta'        => 0,
            'attachments'        => 0,
            'files'              => 0,
            'import_log'         => 0,
        ];

        $this->db->begin();

        try {
            if ($commentIds !== []) {
                $removed['commentmeta'] = $this->deleteWhereIn(
                    "DELETE FROM $commentmeta WHERE comment_id IN (%s)",
                    $commentIds
                );
                $removed['comments'] = $this->deleteWhereIn(
                    "DELETE FROM $comments WHERE comment_ID IN (%s)",
                    $commentIds
                );
            }

            $removed['postmeta'] = $this->deleteWhereIn(
                "DELETE FROM $postmeta WHERE post_id IN (%s)",
                $allPostIds
            );

            $removed['term_relationships'] = $this->deleteWhereIn(
                "DELETE FROM $relationships WHERE object_id IN (%s)",
                $allPostIds
            );

            // Give each term its count back, including the separate counter in
            // termmeta that create_product increments itself. GREATEST(...,0)
            // because a site that has been deleted from by hand may already have a
            // skewed count, and a negative number showing in wp-admin is more
            // confusing than one that is slightly high.
            foreach ($termRows as $termRow) {
                $this->db->execute(
                    "UPDATE $taxonomies SET count = GREATEST(CAST(count AS SIGNED) - 1, 0)
                     WHERE term_taxonomy_id = ?",
                    [(int) $termRow['term_taxonomy_id']]
                );

                $counter = $this->counterMetaKey((string) $termRow['taxonomy']);
                if ($counter !== null) {
                    $this->db->execute(
                        "UPDATE $termmeta
                         SET meta_value = GREATEST(CAST(meta_value AS SIGNED) - 1, 0)
                         WHERE term_id = ? AND meta_key = ?",
                        [(int) $termRow['term_id'], $counter]
                    );
                }
            }

            // Both the parent and its variations have rows in the lookup table.
            $removed['lookup'] = $this->deleteWhereIn(
                "DELETE FROM $lookup WHERE product_id IN (%s)",
                [$productId, ...$variationIds]
            );

            if ($attachmentIds !== []) {
                $removed['attachments'] = $this->deleteWhereIn(
                    "DELETE FROM $posts WHERE ID IN (%s)",
                    $attachmentIds
                );
            }

            $removed['posts'] = $this->deleteWhereIn(
                "DELETE FROM $posts WHERE ID IN (%s)",
                [$productId, ...$variationIds]
            );

            // Without removing this row, re-importing the same file would match the
            // idempotency key, return the id of the product just deleted, and report
            // "deduplicated" for something that no longer exists.
            $removed['import_log'] = $this->deleteWhereIn(
                "DELETE FROM $importLog WHERE product_id IN (%s)",
                [$productId, ...$variationIds]
            );

            $this->db->commit();
        } catch (\Throwable $e) {
            $this->db->rollback();
            throw $e;
        }

        // Files are handled OUTSIDE the transaction, after the commit. Deleting
        // files first and then rolling back loses the images while keeping the
        // product — a failure in the direction that cannot be repaired.
        if ($deleteImages) {
            $removed['files'] = $this->deleteFiles($files);
        }

        return $removed;
    }

    private function counterMetaKey(string $taxonomy): ?string
    {
        return match ($taxonomy) {
            'product_cat' => 'product_count_product_cat',
            'product_tag' => 'product_count_product_tag',
            default       => null,
        };
    }

    /**
     * Absolute paths of the local images belonging to these attachments.
     *
     * `_wp_attached_file` holds a relative path for an uploaded image but keeps the
     * URL VERBATIM for an externally linked one — there is no file to delete in
     * that case, and nothing there may be touched.
     *
     * @param array<int,int> $attachmentIds
     * @return array<int,string>
     */
    private function attachedFiles(array $attachmentIds): array
    {
        if ($attachmentIds === []) {
            return [];
        }

        $postmeta = $this->db->table('postmeta');

        $rows = $this->db->rows(
            "SELECT meta_value FROM $postmeta
             WHERE post_id IN ({$this->placeholders(count($attachmentIds))})
               AND meta_key = '_wp_attached_file'",
            $attachmentIds
        );

        $uploads = $this->wordpressRoot . '/wp-content/uploads';
        $realUploads = realpath($uploads);

        if ($realUploads === false) {
            return [];
        }

        $paths = [];

        foreach ($rows as $row) {
            $relative = trim((string) $row['meta_value']);

            if ($relative === '' || str_contains($relative, '://')) {
                continue;
            }

            // This site's own images are stored as "2026/08/name.jpg". Reject any
            // absolute path or `../` before joining.
            if (str_starts_with($relative, '/') || str_contains($relative, '..')) {
                continue;
            }

            $candidate = $realUploads . '/' . $relative;
            $real = realpath($candidate);

            // After resolving symlinks the file must still be INSIDE uploads.
            // Following a symlink out of it would delete a system file.
            if ($real === false || !str_starts_with($real, $realUploads . '/')) {
                continue;
            }

            $paths[] = $real;
        }

        return $paths;
    }

    /** @param array<int,string> $paths */
    private function deleteFiles(array $paths): int
    {
        $deleted = 0;

        foreach ($paths as $path) {
            if (@unlink($path)) {
                $deleted++;
            }
        }

        return $deleted;
    }

    /**
     * DELETE with an IN list, returning the number of rows actually removed.
     *
     * @param string $template SQL with exactly one `%s` for the placeholders
     * @param array<int,int> $ids
     */
    private function deleteWhereIn(string $template, array $ids): int
    {
        $ids = array_values(array_unique(array_map('intval', $ids)));

        if ($ids === []) {
            return 0;
        }

        $sql = sprintf($template, $this->placeholders(count($ids)));
        $this->db->execute($sql, $ids);

        return $this->db->raw()->affected_rows;
    }

    private function placeholders(int $count): string
    {
        return implode(',', array_fill(0, max(1, $count), '?'));
    }

    /**
     * @param mixed $raw
     * @return array<int,int>
     */
    private function intList($raw, string $field): array
    {
        if (!is_array($raw)) {
            throw new ValidationException('invalid_filter', "$field must be an array.");
        }

        $ids = [];
        foreach ($raw as $value) {
            $id = (int) $value;
            if ($id > 0) {
                $ids[] = $id;
            }
        }

        $ids = array_values(array_unique($ids));

        if ($ids === []) {
            throw new ValidationException('invalid_filter', "$field contains no usable value.");
        }

        return $ids;
    }

    /**
     * @param mixed $raw
     * @return array<int,string>
     */
    private function stringList($raw, string $field): array
    {
        if (!is_array($raw)) {
            throw new ValidationException('invalid_filter', "$field must be an array.");
        }

        $values = [];
        foreach ($raw as $value) {
            $trimmed = trim((string) $value);
            if ($trimmed !== '') {
                $values[] = $trimmed;
            }
        }

        $values = array_values(array_unique($values));

        if ($values === []) {
            throw new ValidationException('invalid_filter', "$field contains no usable value.");
        }

        return $values;
    }
}
