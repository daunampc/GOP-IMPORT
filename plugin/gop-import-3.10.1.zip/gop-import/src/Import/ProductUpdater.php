<?php

namespace GopImport\Import;

use GopImport\Db\Connection;
use GopImport\Db\TermRepository;
use GopImport\Support\Slug;

/**
 * Changes products that are ALREADY on the site, without recreating them.
 *
 * Until this existed the plugin could only create. `ProductImporter::importOne()`
 * answers `deduplicated` for a key it has seen before and changes nothing, so the
 * only way to alter a price was delete-then-reimport — which loses the product id,
 * the reviews, the URL and everything pointing at them. For a real shop prices
 * change weekly, so that was the most frequent operation the tool could not do.
 *
 * THE PROPERTY THE WHOLE FEATURE RESTS ON: only fields PRESENT in the request are
 * written. `{sku, price}` changes the price and must not blank the description,
 * the images, the categories or the stock. Anything else turns a price sync into
 * catalogue destruction, so presence — not emptiness — is the discriminant
 * everywhere below, and `array_key_exists()` rather than `isset()` is what makes
 * that readable from JSON.
 *
 * Three states per field, and there is no fourth:
 *
 *   key absent          leave it exactly as it is
 *   "description": ""   clear it, on purpose
 *   "description": null REFUSE the row (`null_field`)
 *
 * `null` is refused rather than guessed at because two client libraries will
 * serialise an empty field two different ways, and guessing wrong here means
 * erasing a product description.
 *
 * Why this is written in PHP rather than calling the inherited `tsd_update_product`
 * stored function — the same reason `ProductDeleter` refuses
 * `delete_product_by_id`. That function writes ONE value into both
 * `_regular_price` and `_price`, so setting a regular price destroys the sale
 * price; it never touches `wc_product_meta_lookup`, so category pages keep showing
 * the old number; it deletes a product's category rows and increments the new
 * terms' counts without ever decrementing the old ones; and it has no variation
 * path at all.
 *
 * Three principles carried over unchanged from `ProductImporter`:
 *
 *  1. Each row sits in ONE transaction. A half-updated product is worse than an
 *     unchanged one, so any failure rolls the whole row back.
 *  2. Prepared statements throughout, including the IN lists.
 *  3. Report what actually happened per row — here, which fields changed and what
 *     they changed FROM — so the caller can say "340 products, 340 prices changed,
 *     0 descriptions touched" instead of a bare success count.
 */
final class ProductUpdater
{
    /**
     * Rows per request. 50, matching MAX_BATCH_SIZE and MAX_DELETE_BATCH, for the
     * same reason they are 50: a hard ceiling on ONE HTTP request, not on what one
     * run covers.
     */
    public const MAX_UPDATE_BATCH = 50;

    /** SKUs one `exists` call will answer for. */
    public const MAX_EXISTS_SKUS = 1000;

    /**
     * What a PRODUCT row may set.
     *
     * The absentees are deliberate and each has its own reason — see
     * `unsupportedFieldMessage()`. A field outside this list is an ERROR for the
     * row rather than something quietly dropped: ignoring it in silence leaves the
     * caller believing the images were replaced.
     */
    private const PRODUCT_FIELDS = [
        'name', 'sku', 'slug', 'description', 'short_description', 'status',
        'price', 'regular_price', 'sale_price', 'stock', 'instock',
        'categories', 'tags', 'shipping_class', 'custom_meta',
    ];

    /**
     * What a VARIATION row may set, matched by the variation's OWN sku.
     *
     * Narrower on purpose. A variation has no categories, no tags and no name of
     * its own — WooCommerce shows it under its parent's title — so accepting those
     * would be accepting fields that cannot be written.
     */
    private const VARIATION_FIELDS = [
        'sku', 'description', 'status',
        'price', 'regular_price', 'sale_price', 'stock', 'instock',
    ];

    /**
     * Fields that are matching keys rather than data.
     *
     * `product_id` is the most precise of the three and the only one that always
     * works: a product with no SKU cannot be addressed by SKU, and two products
     * sharing a SKU cannot be addressed by it at all — `resolveTarget()` refuses
     * both rather than guessing. A screen that has listed products already knows
     * their ids, so it should not have to go back through a name.
     */
    private const MATCH_FIELDS = ['product_id', 'idempotency_key'];

    private const STATUSES = ['publish', 'draft', 'pending', 'private', 'future'];

    private Connection $db;

    private TermRepository $terms;

    private string $fnPrefix;

    public function __construct(Connection $db, TermRepository $terms, string $fnPrefix)
    {
        $this->db = $db;
        $this->terms = $terms;
        $this->fnPrefix = $fnPrefix;
    }

    /* ------------------------------------------------------------- exists */

    /**
     * Which of these SKUs are already on the site.
     *
     * Cheap by design, and its whole purpose is to be asked BEFORE a run: the app
     * had no way to find out whether a file's SKUs already existed, so a file of
     * products that were all already present imported as a second set of products
     * and the operator learned about it afterwards. A number that arrives after the
     * run is not a preview.
     *
     * Answers with enough to make a decision — the current price and status, not
     * merely a yes — because "1,198 rows already on the site, 12 of them draft" is
     * a different decision from "1,198 rows already on the site".
     *
     * @param array<int,string> $skus
     * @return array{found:array<int,array<string,mixed>>, missing:array<int,string>}
     */
    public function exists(array $skus): array
    {
        $wanted = [];
        foreach ($skus as $sku) {
            $trimmed = trim((string) $sku);
            if ($trimmed !== '') {
                $wanted[$trimmed] = true;
            }
        }

        $wanted = array_keys($wanted);

        if ($wanted === []) {
            throw new ValidationException('empty_skus', '`skus` contains no usable value.');
        }

        if (count($wanted) > self::MAX_EXISTS_SKUS) {
            throw new ValidationException(
                'too_many_skus',
                'At most ' . self::MAX_EXISTS_SKUS . ' SKUs per request; received ' . count($wanted) . '.'
            );
        }

        $posts = $this->db->table('posts');
        $postmeta = $this->db->table('postmeta');
        $placeholders = $this->placeholders(count($wanted));

        $rows = $this->db->rows(
            "SELECT p.ID, p.post_title, p.post_status, p.post_type, p.post_parent, pm.meta_value AS sku
             FROM $postmeta pm
             INNER JOIN $posts p ON p.ID = pm.post_id
             WHERE pm.meta_key = '_sku'
               AND pm.meta_value IN ($placeholders)
               AND p.post_type IN ('product', 'product_variation')
             ORDER BY p.ID",
            $wanted
        );

        $ids = array_map(static fn (array $row): int => (int) $row['ID'], $rows);
        $prices = $this->metaFor($ids, ['_price', '_regular_price', '_sale_price']);
        $types = $this->productTypes($ids);

        $found = [];
        $seen = [];

        foreach ($rows as $row) {
            $id = (int) $row['ID'];
            $sku = (string) $row['sku'];
            $isVariation = $row['post_type'] === 'product_variation';

            $seen[$sku] = true;

            $found[] = [
                'sku'            => $sku,
                'product_id'     => $id,
                'name'           => (string) $row['post_title'],
                'status'         => (string) $row['post_status'],
                'type'           => $isVariation ? 'variation' : ($types[$id] ?? 'simple'),
                'is_variation'   => $isVariation,
                'parent_id'      => $isVariation ? (int) $row['post_parent'] : null,
                'price'          => $prices[$id]['_price'] ?? '',
                'regular_price'  => $prices[$id]['_regular_price'] ?? '',
                'sale_price'     => $prices[$id]['_sale_price'] ?? '',
            ];
        }

        $missing = [];
        foreach ($wanted as $sku) {
            if (!isset($seen[$sku])) {
                $missing[] = $sku;
            }
        }

        return ['found' => $found, 'missing' => $missing];
    }

    /* ------------------------------------------------------------- update */

    /**
     * Update a batch. Each row succeeds or fails on its own, exactly as
     * `importBatch` does — one bad row does not take the batch down.
     *
     * @param array<int,array<string,mixed>> $items
     * @return array<int,array<string,mixed>>
     */
    public function updateBatch(array $items): array
    {
        $results = [];

        foreach ($items as $index => $item) {
            try {
                if (!is_array($item)) {
                    throw new ValidationException('invalid_row', "Row $index must be an object.");
                }
                $results[] = ['index' => $index, 'ok' => true] + $this->updateOne($item);
            } catch (ValidationException $e) {
                $results[] = [
                    'index' => $index,
                    'ok'    => false,
                    'error' => ['code' => $e->errorCode(), 'message' => $e->getMessage()],
                ];
            } catch (\Throwable $e) {
                $results[] = [
                    'index' => $index,
                    'ok'    => false,
                    'error' => ['code' => 'update_failed', 'message' => $e->getMessage()],
                ];
            }
        }

        return $results;
    }

    /**
     * @param array<string,mixed> $raw
     * @return array<string,mixed>
     */
    public function updateOne(array $raw): array
    {
        $target = $this->resolveTarget($raw);
        $fields = $this->readFields($raw, $target['is_variation']);

        // Nothing to write is not an error — it is a no-op, and saying so is more
        // useful than inventing a failure. A bulk edit whose filter caught a row
        // already at the right price should report that row as unchanged.
        if ($fields === []) {
            return [
                'product_id'   => $target['product_id'],
                'sku'          => $target['sku'],
                'is_variation' => $target['is_variation'],
                'parent_id'    => $target['parent_id'],
                'changed'      => [],
            ];
        }

        $this->db->begin();

        try {
            $changed = $this->apply($target, $fields);
            $this->db->commit();
        } catch (\Throwable $e) {
            $this->db->rollback();
            throw $e;
        }

        return [
            'product_id'   => $target['product_id'],
            'sku'          => $this->skuOf($target['product_id']),
            'is_variation' => $target['is_variation'],
            'parent_id'    => $target['parent_id'],
            'changed'      => $changed,
        ];
    }

    /* ---------------------------------------------------------- resolving */

    /**
     * Find the ONE product this row means, or fail.
     *
     * Ambiguity is an error, never a guess. Two products sharing a SKU is bad data
     * on the site, and picking one of them is how a price lands on the wrong
     * product with nobody able to tell afterwards.
     *
     * @param array<string,mixed> $raw
     * @return array{product_id:int, sku:string, is_variation:bool, parent_id:?int}
     */
    private function resolveTarget(array $raw): array
    {
        /*
         * MOST SPECIFIC FIRST, and the order is the contract.
         *
         * `product_id` names exactly one row and cannot be ambiguous, so a caller
         * that has one is answered from it and the SKU in the same payload is left
         * as data — which is what makes renaming a SKU expressible at all.
         */
        if (array_key_exists('product_id', $raw)) {
            $productId = (int) $raw['product_id'];

            if ($productId <= 0) {
                throw new ValidationException(
                    'invalid_product_id',
                    '`product_id` must be a positive integer.'
                );
            }

            return $this->describe($productId);
        }

        $key = array_key_exists('idempotency_key', $raw) ? trim((string) $raw['idempotency_key']) : '';

        if ($key !== '') {
            $importLog = $this->db->table('tsd_import_log');

            $rows = $this->db->rows(
                "SELECT product_id FROM $importLog WHERE idempotency_key = ? LIMIT 1",
                [$key]
            );

            if ($rows === []) {
                throw new ValidationException(
                    'not_found',
                    "No product on this site was imported with idempotency_key `$key`."
                );
            }

            return $this->describe((int) $rows[0]['product_id']);
        }

        $sku = array_key_exists('sku', $raw) ? trim((string) $raw['sku']) : '';

        if ($sku === '') {
            throw new ValidationException(
                'missing_match_key',
                'A row must carry `product_id`, `sku` or `idempotency_key` so the product can be found.'
            );
        }

        $posts = $this->db->table('posts');
        $postmeta = $this->db->table('postmeta');

        // Variations carry `_sku` too, and updating a variation by its own SKU has
        // to work — so both post types are searched, and which one was found
        // decides the field set.
        $matches = $this->db->rows(
            "SELECT DISTINCT p.ID
             FROM $postmeta pm
             INNER JOIN $posts p ON p.ID = pm.post_id
             WHERE pm.meta_key = '_sku' AND pm.meta_value = ?
               AND p.post_type IN ('product', 'product_variation')
             ORDER BY p.ID
             LIMIT 11",
            [$sku]
        );

        if ($matches === []) {
            throw new ValidationException('not_found', "No product or variation on this site has SKU `$sku`.");
        }

        if (count($matches) > 1) {
            $ids = implode(', ', array_map(static fn (array $row): string => (string) $row['ID'], $matches));

            throw new ValidationException(
                'ambiguous_sku',
                "SKU `$sku` matches more than one product on this site (ids: $ids). "
                . 'Nothing was changed. Fix the duplicate on the site, or address the product by '
                . '`idempotency_key` instead.'
            );
        }

        return $this->describe((int) $matches[0]['ID']);
    }

    /** @return array{product_id:int, sku:string, is_variation:bool, parent_id:?int} */
    private function describe(int $productId): array
    {
        $posts = $this->db->table('posts');

        $rows = $this->db->rows(
            "SELECT ID, post_type, post_parent FROM $posts WHERE ID = ? LIMIT 1",
            [$productId]
        );

        if ($rows === []) {
            throw new ValidationException('not_found', "There is no post with id $productId.");
        }

        $type = (string) $rows[0]['post_type'];

        if ($type !== 'product' && $type !== 'product_variation') {
            throw new ValidationException(
                'not_a_product',
                "id $productId is post_type '$type', not 'product' or 'product_variation'."
            );
        }

        $isVariation = $type === 'product_variation';

        return [
            'product_id'   => $productId,
            'sku'          => $this->skuOf($productId),
            'is_variation' => $isVariation,
            'parent_id'    => $isVariation ? (int) $rows[0]['post_parent'] : null,
        ];
    }

    /* --------------------------------------------------------- validating */

    /**
     * The fields this row asks to write, validated, with absence preserved.
     *
     * Returns only keys that were PRESENT. Everything downstream tests presence on
     * this array, so "not asked for" and "asked for as empty" stay distinguishable
     * all the way to the SQL.
     *
     * @param array<string,mixed> $raw
     * @return array<string,mixed>
     */
    private function readFields(array $raw, bool $isVariation): array
    {
        $allowed = $isVariation ? self::VARIATION_FIELDS : self::PRODUCT_FIELDS;
        $fields = [];

        foreach ($raw as $name => $value) {
            $name = (string) $name;

            if (in_array($name, self::MATCH_FIELDS, true)) {
                continue;
            }

            if (!in_array($name, $allowed, true)) {
                throw new ValidationException(
                    'unsupported_field',
                    $this->unsupportedFieldMessage($name, $isVariation)
                );
            }

            // Refused, not guessed at. See the class comment.
            if ($value === null) {
                throw new ValidationException(
                    'null_field',
                    "`$name` is null. Send \"\" to clear the field on purpose, or leave the key out "
                    . 'to keep the current value — null is refused rather than guessed at.'
                );
            }

            $fields[$name] = $value;
        }

        // `sku` addressed the row rather than changing it, unless the row was
        // addressed some other way. Changing the thing that was used to find the
        // product, in the same call, has no second identifier to fall back on.
        $addressedOtherwise =
            array_key_exists('product_id', $raw) || array_key_exists('idempotency_key', $raw);

        if (isset($fields['sku']) && !$addressedOtherwise) {
            unset($fields['sku']);
        }

        return $this->normalize($fields);
    }

    private function unsupportedFieldMessage(string $name, bool $isVariation): string
    {
        $reasons = [
            'images' => 'Replacing the gallery means creating and deleting attachments, which changes '
                . 'image ids. It is not part of a partial update.',
            'type' => 'Changing simple to variable rebuilds the whole variation set, which changes '
                . 'variation ids.',
            'attributes' => 'Rewriting attributes rebuilds the variation set, which changes variation ids.',
            'variations' => 'Rebuilding the variation set changes variation ids and breaks anything '
                . 'referencing them. Update a variation by its OWN sku instead.',
            'reviews' => 'Reviews are created with the product and are not updated through this route.',
            'mode_import' => 'There is no full_data mode on an update: an update writes what it was '
                . 'given and nothing else.',
        ];

        if (isset($reasons[$name])) {
            return "`$name` cannot be updated. " . $reasons[$name];
        }

        if ($isVariation && in_array($name, self::PRODUCT_FIELDS, true)) {
            return "`$name` belongs to a product, not to a variation. SKU matched a variation, so only "
                . implode(', ', self::VARIATION_FIELDS) . ' can be written.';
        }

        return "`$name` is not a field this route writes. Allowed: " . implode(', ', $isVariation ? self::VARIATION_FIELDS : self::PRODUCT_FIELDS) . '.';
    }

    /**
     * `$isVariation` is not needed here: `readFields()` has already refused any
     * field that does not belong to the kind of row that matched, so by this point
     * the two sets validate identically.
     *
     * @param array<string,mixed> $fields
     * @return array<string,mixed>
     */
    private function normalize(array $fields): array
    {
        if (array_key_exists('name', $fields)) {
            $name = trim((string) $fields['name']);
            if ($name === '') {
                // Unlike a description, an empty title is not a state a product can
                // legitimately be in — WordPress renders it as a blank row.
                throw new ValidationException('missing_name', '`name` cannot be cleared. A product must have a name.');
            }
            $fields['name'] = $name;
        }

        if (array_key_exists('status', $fields)) {
            $status = trim((string) $fields['status']);
            if (!in_array($status, self::STATUSES, true)) {
                throw new ValidationException(
                    'invalid_status',
                    '`status` must be one of: ' . implode(', ', self::STATUSES)
                );
            }
            $fields['status'] = $status;
        }

        if (array_key_exists('slug', $fields)) {
            $slug = trim((string) $fields['slug']);
            if ($slug === '') {
                throw new ValidationException(
                    'invalid_slug',
                    '`slug` cannot be cleared. An empty post_name makes the product unreachable at its URL.'
                );
            }
            $fields['slug'] = Slug::make($slug);
        }

        if (array_key_exists('sku', $fields)) {
            $fields['sku'] = trim((string) $fields['sku']);
        }

        foreach (['price', 'regular_price', 'sale_price'] as $field) {
            if (!array_key_exists($field, $fields)) {
                continue;
            }
            $fields[$field] = $this->money($fields[$field], $field);
        }

        if (array_key_exists('stock', $fields)) {
            $raw = $fields['stock'];
            if ($raw === '') {
                $fields['stock'] = '';
            } elseif (is_numeric($raw)) {
                $fields['stock'] = (string) (int) $raw;
            } else {
                throw new ValidationException(
                    'invalid_stock',
                    '`stock` must be a whole number, or "" to stop managing stock for this product.'
                );
            }
        }

        if (array_key_exists('instock', $fields)) {
            $fields['instock'] = filter_var($fields['instock'], FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
            if ($fields['instock'] === null) {
                throw new ValidationException('invalid_instock', '`instock` must be true or false.');
            }
        }

        foreach (['categories', 'tags'] as $field) {
            if (!array_key_exists($field, $fields)) {
                continue;
            }
            $fields[$field] = $this->stringList($fields[$field], $field);
        }

        if (array_key_exists('custom_meta', $fields)) {
            $meta = $fields['custom_meta'];
            if (!is_array($meta)) {
                throw new ValidationException('invalid_custom_meta', '`custom_meta` must be an object.');
            }
            $fields['custom_meta'] = $meta;
        }

        if (array_key_exists('description', $fields)) {
            $fields['description'] = (string) $fields['description'];
        }

        if (array_key_exists('short_description', $fields)) {
            $fields['short_description'] = (string) $fields['short_description'];
        }

        if (array_key_exists('shipping_class', $fields)) {
            $fields['shipping_class'] = trim((string) $fields['shipping_class']);
        }

        return $fields;
    }

    /**
     * A price on the way in.
     *
     * `""` is kept as `""` — that is how a sale is ENDED, and it has to survive all
     * the way to the meta row rather than being turned into 0, which would mean
     * "free".
     *
     * @param mixed $value
     */
    private function money($value, string $field): string
    {
        if ($value === '') {
            return '';
        }

        if (!is_numeric($value)) {
            throw new ValidationException(
                'invalid_price',
                "`$field` must be a number, or \"\" to clear it. Received: " . var_export($value, true)
            );
        }

        if ((float) $value < 0) {
            throw new ValidationException('invalid_price', "`$field` cannot be negative.");
        }

        // Kept as a string, exactly as the import path does: WooCommerce stores
        // prices as plain text in postmeta, and a float round trip is how 199000.1
        // becomes 199000.09999999999.
        return (string) $value;
    }

    /**
     * @param mixed $values
     * @return array<int,string>
     */
    private function stringList($values, string $field): array
    {
        if (!is_array($values)) {
            throw new ValidationException("invalid_$field", "`$field` must be an array of strings.");
        }

        $out = [];
        foreach ($values as $value) {
            $trimmed = trim((string) $value);
            if ($trimmed !== '') {
                $out[] = $trimmed;
            }
        }

        return array_values(array_unique($out));
    }

    /* ------------------------------------------------------------ applying */

    /**
     * Write the fields, and report what actually moved.
     *
     * Runs inside the row's transaction. Every branch tests `array_key_exists`
     * against `$fields` — which only holds keys the request carried — so an absent
     * field reaches no SQL at all rather than reaching SQL with an empty value.
     *
     * @param array{product_id:int, sku:string, is_variation:bool, parent_id:?int} $target
     * @param array<string,mixed> $fields
     * @return array<string,array{from:mixed, to:mixed}>
     */
    private function apply(array $target, array $fields): array
    {
        $productId = $target['product_id'];
        $changed = [];

        $this->applyPostColumns($productId, $fields, $changed);
        $this->applySku($productId, $fields, $changed);
        $this->applyPrices($productId, $fields, $changed);
        $this->applyStock($productId, $fields, $changed);
        $this->applyCustomMeta($productId, $fields, $changed);

        if (!$target['is_variation']) {
            $this->applyTerms($productId, $fields, $changed);
        }

        if ($changed === []) {
            return [];
        }

        // WordPress stamps this on every save, and plugins and caches watch it.
        $this->touchModified($productId);

        /*
         * The lookup table and the cache, and this is the half that decides whether
         * anybody SEES the change.
         *
         * Writing postmeta alone leaves `wc_product_meta_lookup` holding the old
         * price, and that table is what WooCommerce reads for category pages, sorting
         * and filtering — so the product page shows the new price while every listing
         * shows the old one. That is the bug that makes people think the tool did
         * nothing.
         */
        $this->refreshLookup($productId);

        if ($target['parent_id'] !== null && $target['parent_id'] > 0) {
            // A variation's price moved, so the parent's displayed RANGE moved.
            // Recomputed by aggregate over every variation rather than by
            // `create_product`'s incremental comparison, which is only correct while
            // variations are being ADDED and is wrong the moment one is lowered.
            $this->refreshPriceRange($target['parent_id']);
            $this->clearTransients($target['parent_id']);
        }

        $this->clearTransients($productId);

        return $changed;
    }

    /**
     * @param array<string,mixed> $fields
     * @param array<string,array{from:mixed, to:mixed}> $changed
     */
    private function applyPostColumns(int $productId, array $fields, array &$changed): void
    {
        $map = [
            'name'              => 'post_title',
            'description'       => 'post_content',
            'short_description' => 'post_excerpt',
            'status'            => 'post_status',
            'slug'              => 'post_name',
        ];

        $present = array_intersect_key($map, $fields);

        if ($present === []) {
            return;
        }

        $posts = $this->db->table('posts');
        $columns = implode(', ', array_values($present));

        $rows = $this->db->rows("SELECT $columns FROM $posts WHERE ID = ? LIMIT 1", [$productId]);

        if ($rows === []) {
            throw new ValidationException('not_found', "There is no post with id $productId.");
        }

        foreach ($present as $field => $column) {
            $from = (string) $rows[0][$column];
            $to = (string) $fields[$field];

            if ($from === $to) {
                continue;
            }

            if ($column === 'post_name') {
                $this->refuseTakenSlug($productId, $to);
            }

            $this->db->execute("UPDATE $posts SET `$column` = ? WHERE ID = ?", [$to, $productId]);

            $changed[$field] = ['from' => $from, 'to' => $to];
        }
    }

    /**
     * A slug already in use is refused, not silently suffixed.
     *
     * The plugin writes straight to the database and so never runs
     * `wp_unique_post_slug()` — two products sharing a slug both exist and one of
     * them is unreachable. Suffixing it quietly would mean the product does not
     * live at the URL the operator asked for, and they would find out from a
     * customer.
     */
    private function refuseTakenSlug(int $productId, string $slug): void
    {
        $posts = $this->db->table('posts');

        $taken = $this->db->rows(
            "SELECT ID FROM $posts
             WHERE post_name = ? AND ID <> ?
               AND post_type IN ('product', 'product_variation')
             LIMIT 1",
            [$slug, $productId]
        );

        if ($taken !== []) {
            throw new ValidationException(
                'slug_taken',
                "The slug `$slug` already belongs to product " . (int) $taken[0]['ID'] . '. Two products '
                . 'sharing a slug both exist and one becomes unreachable, so this row was refused rather '
                . 'than given a different slug from the one asked for.'
            );
        }
    }

    /**
     * @param array<string,mixed> $fields
     * @param array<string,array{from:mixed, to:mixed}> $changed
     */
    private function applySku(int $productId, array $fields, array &$changed): void
    {
        if (!array_key_exists('sku', $fields)) {
            return;
        }

        $to = (string) $fields['sku'];
        $from = $this->skuOf($productId);

        if ($from === $to) {
            return;
        }

        if ($to !== '') {
            $posts = $this->db->table('posts');
            $postmeta = $this->db->table('postmeta');

            // Otherwise this write CREATES the ambiguity that `resolveTarget()`
            // refuses to act on — and the next price sync for that SKU would fail
            // for a reason nobody could trace back to here.
            $clash = $this->db->rows(
                "SELECT p.ID FROM $postmeta pm
                 INNER JOIN $posts p ON p.ID = pm.post_id
                 WHERE pm.meta_key = '_sku' AND pm.meta_value = ? AND p.ID <> ?
                   AND p.post_type IN ('product', 'product_variation')
                 LIMIT 1",
                [$to, $productId]
            );

            if ($clash !== []) {
                throw new ValidationException(
                    'sku_taken',
                    "SKU `$to` already belongs to product " . (int) $clash[0]['ID'] . '. Two products '
                    . 'sharing a SKU cannot be addressed by SKU afterwards, so this row was refused.'
                );
            }
        }

        $this->writeMeta($productId, '_sku', $to);

        $changed['sku'] = ['from' => $from, 'to' => $to];
    }

    /**
     * Prices, and `_price` is DERIVED — never accepted as an independent value.
     *
     * WooCommerce displays `_price`, and `_price` equals `_sale_price` while a sale
     * is on and `_regular_price` otherwise. `Normalizer::prices()` already does that
     * on the import path; the inherited stored function does not, which is why
     * setting a regular price through it destroys the sale price.
     *
     * The recomputation needs the CURRENT value of whichever input the request did
     * not carry, so both are read. That is a requirement rather than an
     * optimisation: `{sku, sale_price: ""}` means "end the sale", and it has to put
     * `_price` back to the regular price that is already on the product.
     *
     * @param array<string,mixed> $fields
     * @param array<string,array{from:mixed, to:mixed}> $changed
     */
    private function applyPrices(int $productId, array $fields, array &$changed): void
    {
        $touchesRegular = array_key_exists('regular_price', $fields) || array_key_exists('price', $fields);
        $touchesSale = array_key_exists('sale_price', $fields);

        if (!$touchesRegular && !$touchesSale) {
            return;
        }

        $current = $this->metaFor([$productId], ['_price', '_regular_price', '_sale_price'])[$productId] ?? [];

        $fromRegular = (string) ($current['_regular_price'] ?? '');
        $fromSale = (string) ($current['_sale_price'] ?? '');
        $fromPrice = (string) ($current['_price'] ?? '');

        // `price` is the alias `regular_price` takes when it is absent — the same
        // relationship the import path has.
        $toRegular = $touchesRegular
            ? (string) ($fields['regular_price'] ?? $fields['price'])
            : $fromRegular;

        $toSale = $touchesSale ? (string) $fields['sale_price'] : $fromSale;

        $toPrice = $toSale !== '' ? $toSale : $toRegular;

        foreach (
            [
                ['regular_price', '_regular_price', $fromRegular, $toRegular],
                ['sale_price', '_sale_price', $fromSale, $toSale],
                ['price', '_price', $fromPrice, $toPrice],
            ] as [$field, $metaKey, $from, $to]
        ) {
            if ($from === $to) {
                continue;
            }
            $this->writeMeta($productId, $metaKey, $to);
            $changed[$field] = ['from' => $from, 'to' => $to];
        }
    }

    /**
     * Stock quantity, and the stock STATUS that follows from it.
     *
     * `_stock_status` is derived when a quantity is written, because nothing else
     * will derive it. WooCommerce recomputes it from the quantity and the backorder
     * setting whenever a product is saved through WooCommerce — and this plugin
     * writes straight to the database, so a product left at `instock` with `_stock`
     * of 0 is buyable right up to the point where the order fails.
     *
     * An explicit `instock` in the request WINS over the derivation: the caller said
     * what they meant. Either way the result appears in `changed`, so a derived
     * value is visible rather than silent.
     *
     * @param array<string,mixed> $fields
     * @param array<string,array{from:mixed, to:mixed}> $changed
     */
    private function applyStock(int $productId, array $fields, array &$changed): void
    {
        $touchesStock = array_key_exists('stock', $fields);
        $touchesInstock = array_key_exists('instock', $fields);

        if (!$touchesStock && !$touchesInstock) {
            return;
        }

        $current = $this->metaFor(
            [$productId],
            ['_stock', '_manage_stock', '_stock_status', '_backorders']
        )[$productId] ?? [];

        $fromStock = (string) ($current['_stock'] ?? '');
        $fromManage = (string) ($current['_manage_stock'] ?? 'no');
        $fromStatus = (string) ($current['_stock_status'] ?? '');
        $backorders = (string) ($current['_backorders'] ?? 'no');

        $toManage = $fromManage;
        $toStock = $fromStock;

        if ($touchesStock) {
            $toStock = (string) $fields['stock'];
            // "" is "stop managing stock for this product", which is a real and
            // reachable state — not the same thing as a quantity of zero.
            $toManage = $toStock === '' ? 'no' : 'yes';
        }

        if ($fromStock !== $toStock) {
            $this->writeMeta($productId, '_stock', $toStock);
            $changed['stock'] = ['from' => $fromStock, 'to' => $toStock];
        }

        if ($fromManage !== $toManage) {
            $this->writeMeta($productId, '_manage_stock', $toManage);
            $changed['manage_stock'] = ['from' => $fromManage, 'to' => $toManage];
        }

        if ($touchesInstock) {
            $toStatus = $fields['instock'] === true ? 'instock' : 'outofstock';
        } elseif ($toManage === 'yes' && $backorders === 'no') {
            $toStatus = ((int) $toStock) > 0 ? 'instock' : 'outofstock';
        } else {
            $toStatus = $fromStatus;
        }

        if ($fromStatus !== $toStatus && $toStatus !== '') {
            $this->writeMeta($productId, '_stock_status', $toStatus);
            $changed['instock'] = ['from' => $fromStatus, 'to' => $toStatus];
        }
    }

    /**
     * @param array<string,mixed> $fields
     * @param array<string,array{from:mixed, to:mixed}> $changed
     */
    private function applyCustomMeta(int $productId, array $fields, array &$changed): void
    {
        if (!array_key_exists('custom_meta', $fields)) {
            return;
        }

        /** @var array<string,mixed> $meta */
        $meta = $fields['custom_meta'];

        // ADDITIVE, and deliberately so: a partial update that replaced the whole
        // meta set would delete every key the request did not mention, which for
        // postmeta means deleting whatever other plugins put there.
        foreach ($meta as $key => $value) {
            $key = (string) $key;

            if ($key === '' || $key === '_sku' || $key === '_price'
                || $key === '_regular_price' || $key === '_sale_price'
                || $key === '_stock' || $key === '_stock_status' || $key === '_manage_stock'
            ) {
                throw new ValidationException(
                    'reserved_meta',
                    "`custom_meta` may not write `$key` — it has a field of its own on this route, and "
                    . 'two ways to set one value is how they end up disagreeing.'
                );
            }

            $to = $value === null ? '' : (string) $value;
            $from = $this->metaValue($productId, $key);

            if ($from === $to) {
                continue;
            }

            $this->writeMeta($productId, $key, $to);
            $changed["custom_meta.$key"] = ['from' => $from, 'to' => $to];
        }
    }

    /**
     * Categories, tags and the shipping class — replacing the SET, with the counts
     * corrected on BOTH sides.
     *
     * The inherited stored function deletes the old relationships and increments the
     * new terms' counts without ever decrementing the old ones, so every category
     * change leaks a count and wp-admin slowly fills with categories claiming
     * products they no longer hold. `ProductDeleter` already decrements both
     * counters on the way out; this is the same arithmetic, applied to a swap.
     *
     * @param array<string,mixed> $fields
     * @param array<string,array{from:mixed, to:mixed}> $changed
     */
    private function applyTerms(int $productId, array $fields, array &$changed): void
    {
        if (array_key_exists('categories', $fields)) {
            /** @var array<int,string> $names */
            $names = $fields['categories'];
            $termIds = [];
            foreach ($names as $name) {
                $termIds[] = $this->terms->category($name, true);
            }
            $this->replaceTerms($productId, 'product_cat', $termIds, 'categories', $changed);
        }

        if (array_key_exists('tags', $fields)) {
            /** @var array<int,string> $names */
            $names = $fields['tags'];
            $termIds = [];
            foreach ($names as $name) {
                $termIds[] = $this->terms->tag($name);
            }
            $this->replaceTerms($productId, 'product_tag', $termIds, 'tags', $changed);
        }

        if (array_key_exists('shipping_class', $fields)) {
            $name = (string) $fields['shipping_class'];
            $termIds = $name === '' ? [] : [$this->terms->shippingClass($name)];
            $this->replaceTerms($productId, 'product_shipping_class', $termIds, 'shipping_class', $changed);
        }
    }

    /**
     * @param array<int,int> $termIds
     * @param array<string,array{from:mixed, to:mixed}> $changed
     */
    private function replaceTerms(
        int $productId,
        string $taxonomy,
        array $termIds,
        string $field,
        array &$changed
    ): void {
        $terms = $this->db->table('terms');
        $taxonomies = $this->db->table('term_taxonomy');
        $relationships = $this->db->table('term_relationships');
        $termmeta = $this->db->table('termmeta');

        $currentRows = $this->db->rows(
            "SELECT tt.term_taxonomy_id, tt.term_id, t.name
             FROM $relationships tr
             INNER JOIN $taxonomies tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
             INNER JOIN $terms t ON t.term_id = tt.term_id
             WHERE tr.object_id = ? AND tt.taxonomy = ?
             ORDER BY t.name",
            [$productId, $taxonomy]
        );

        $current = [];
        $fromNames = [];
        foreach ($currentRows as $row) {
            $current[(int) $row['term_id']] = (int) $row['term_taxonomy_id'];
            $fromNames[] = (string) $row['name'];
        }

        $wanted = [];
        $toNames = [];
        foreach (array_values(array_unique($termIds)) as $termId) {
            $termId = (int) $termId;
            if ($termId <= 0) {
                continue;
            }

            $rows = $this->db->rows(
                "SELECT tt.term_taxonomy_id, t.name
                 FROM $taxonomies tt
                 INNER JOIN $terms t ON t.term_id = tt.term_id
                 WHERE tt.term_id = ? AND tt.taxonomy = ?
                 LIMIT 1",
                [$termId, $taxonomy]
            );

            if ($rows === []) {
                continue;
            }

            $wanted[$termId] = (int) $rows[0]['term_taxonomy_id'];
            $toNames[] = (string) $rows[0]['name'];
        }

        sort($toNames);

        $added = array_diff_key($wanted, $current);
        $removed = array_diff_key($current, $wanted);

        if ($added === [] && $removed === []) {
            return;
        }

        $counter = $this->counterMetaKey($taxonomy);

        foreach ($removed as $termId => $taxonomyId) {
            $this->db->execute(
                "DELETE FROM $relationships WHERE object_id = ? AND term_taxonomy_id = ?",
                [$productId, $taxonomyId]
            );

            // GREATEST(...,0) for the same reason the deleter uses it: a site that
            // has been edited by hand may already have a skewed count, and a
            // negative number in wp-admin is more confusing than one slightly high.
            $this->db->execute(
                "UPDATE $taxonomies SET count = GREATEST(CAST(count AS SIGNED) - 1, 0)
                 WHERE term_taxonomy_id = ?",
                [$taxonomyId]
            );

            if ($counter !== null) {
                $this->db->execute(
                    "UPDATE $termmeta SET meta_value = GREATEST(CAST(meta_value AS SIGNED) - 1, 0)
                     WHERE term_id = ? AND meta_key = ?",
                    [$termId, $counter]
                );
            }
        }

        foreach ($added as $termId => $taxonomyId) {
            $this->db->execute(
                "INSERT IGNORE INTO $relationships (object_id, term_taxonomy_id, term_order)
                 VALUES (?, ?, 0)",
                [$productId, $taxonomyId]
            );

            $this->db->execute(
                "UPDATE $taxonomies SET count = count + 1 WHERE term_taxonomy_id = ?",
                [$taxonomyId]
            );

            if ($counter !== null) {
                $existing = $this->db->rows(
                    "SELECT meta_id FROM $termmeta WHERE term_id = ? AND meta_key = ? LIMIT 1",
                    [$termId, $counter]
                );

                if ($existing === []) {
                    $this->db->execute(
                        "INSERT INTO $termmeta (term_id, meta_key, meta_value) VALUES (?, ?, '1')",
                        [$termId, $counter]
                    );
                } else {
                    $this->db->execute(
                        "UPDATE $termmeta SET meta_value = CAST(meta_value AS SIGNED) + 1
                         WHERE term_id = ? AND meta_key = ?",
                        [$termId, $counter]
                    );
                }
            }
        }

        $changed[$field] = [
            'from' => $field === 'shipping_class' ? ($fromNames[0] ?? '') : $fromNames,
            'to'   => $field === 'shipping_class' ? ($toNames[0] ?? '') : $toNames,
        ];
    }

    private function counterMetaKey(string $taxonomy): ?string
    {
        return match ($taxonomy) {
            'product_cat' => 'product_count_product_cat',
            'product_tag' => 'product_count_product_tag',
            default       => null,
        };
    }

    /* ------------------------------------------------- lookup table + cache */

    /**
     * Rewrite this product's row in `wc_product_meta_lookup` from the truth in
     * postmeta.
     *
     * Not an optimisation. This table is what WooCommerce reads for category pages,
     * price sorting and price filters, so a price change that stops at postmeta is
     * invisible everywhere a shopper actually looks.
     *
     * For a VARIABLE parent the range comes from its variations, which is what
     * `refreshPriceRange()` does; for anything else min and max are both the
     * product's own displayed price.
     */
    public function refreshLookup(int $productId): void
    {
        $posts = $this->db->table('posts');
        $lookup = $this->db->table('wc_product_meta_lookup');

        $rows = $this->db->rows(
            "SELECT post_type, post_parent FROM $posts WHERE ID = ? LIMIT 1",
            [$productId]
        );

        if ($rows === []) {
            return;
        }

        $meta = $this->metaFor(
            [$productId],
            [
                '_sku', '_price', '_regular_price', '_sale_price', '_stock', '_manage_stock',
                '_stock_status', '_virtual', '_downloadable', '_tax_status', '_tax_class',
            ]
        )[$productId] ?? [];

        $price = (string) ($meta['_price'] ?? '');
        $regular = (string) ($meta['_regular_price'] ?? '');
        $sale = (string) ($meta['_sale_price'] ?? '');
        $manageStock = (string) ($meta['_manage_stock'] ?? 'no') === 'yes';

        $onSale = $sale !== '' && $regular !== '' && (float) $sale < (float) $regular ? 1 : 0;

        $values = [
            'sku'            => (string) ($meta['_sku'] ?? ''),
            'virtual'        => (string) ($meta['_virtual'] ?? 'no') === 'yes' ? 1 : 0,
            'downloadable'   => (string) ($meta['_downloadable'] ?? 'no') === 'yes' ? 1 : 0,
            'min_price'      => $price === '' ? null : (float) $price,
            'max_price'      => $price === '' ? null : (float) $price,
            'onsale'         => $onSale,
            'stock_quantity' => $manageStock && ($meta['_stock'] ?? '') !== '' ? (int) $meta['_stock'] : null,
            'stock_status'   => (string) ($meta['_stock_status'] ?? 'instock'),
            'tax_status'     => (string) ($meta['_tax_status'] ?? 'taxable'),
            'tax_class'      => (string) ($meta['_tax_class'] ?? ''),
        ];

        $existing = $this->db->rows(
            "SELECT `product_id` FROM $lookup WHERE `product_id` = ? LIMIT 1",
            [$productId]
        );

        if ($existing === []) {
            $this->db->execute(
                // Every column is backticked: `virtual` is a reserved word in MySQL 8
                // (generated columns), so the bare name is a syntax error.
                "INSERT INTO $lookup
                    (`product_id`, `sku`, `virtual`, `downloadable`, `min_price`, `max_price`,
                     `onsale`, `stock_quantity`, `stock_status`, `rating_count`, `average_rating`,
                     `total_sales`, `tax_status`, `tax_class`)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0.00, 0, ?, ?)",
                [
                    $productId, $values['sku'], $values['virtual'], $values['downloadable'],
                    $values['min_price'], $values['max_price'], $values['onsale'],
                    $values['stock_quantity'], $values['stock_status'],
                    $values['tax_status'], $values['tax_class'],
                ]
            );
        } else {
            $this->db->execute(
                "UPDATE $lookup SET
                    `sku` = ?, `virtual` = ?, `downloadable` = ?, `min_price` = ?, `max_price` = ?,
                    `onsale` = ?, `stock_quantity` = ?, `stock_status` = ?, `tax_status` = ?,
                    `tax_class` = ?
                 WHERE `product_id` = ?",
                [
                    $values['sku'], $values['virtual'], $values['downloadable'],
                    $values['min_price'], $values['max_price'], $values['onsale'],
                    $values['stock_quantity'], $values['stock_status'],
                    $values['tax_status'], $values['tax_class'],
                    $productId,
                ]
            );
        }

        // A parent whose own row was just rewritten as a flat price must have its
        // range put back if it is in fact variable.
        if ((string) $rows[0]['post_type'] === 'product') {
            $this->refreshPriceRange($productId);
        }
    }

    /**
     * A variable product's displayed price range, computed from its variations.
     *
     * By aggregate, NOT by `create_product`'s running comparison. That comparison
     * only widens the range, which is correct while variations are being added and
     * wrong the moment one is lowered — the min stays at the old floor and the
     * category page keeps advertising a price nothing is sold at.
     *
     * A product with no variations is left alone: its own price is already its
     * range, and zeroing it here would wipe the row `refreshLookup()` just wrote.
     */
    public function refreshPriceRange(int $productId): void
    {
        $posts = $this->db->table('posts');
        $postmeta = $this->db->table('postmeta');
        $lookup = $this->db->table('wc_product_meta_lookup');

        $rows = $this->db->rows(
            "SELECT MIN(CAST(pm.meta_value AS DECIMAL(19,4))) AS min_price,
                    MAX(CAST(pm.meta_value AS DECIMAL(19,4))) AS max_price,
                    COUNT(*) AS total
             FROM $posts p
             INNER JOIN $postmeta pm ON pm.post_id = p.ID AND pm.meta_key = '_price'
             WHERE p.post_parent = ? AND p.post_type = 'product_variation'
               AND pm.meta_value <> ''",
            [$productId]
        );

        if ($rows === [] || (int) $rows[0]['total'] === 0) {
            return;
        }

        $onSale = $this->db->scalar(
            "SELECT COUNT(*) FROM $posts p
             INNER JOIN $postmeta reg ON reg.post_id = p.ID AND reg.meta_key = '_regular_price'
             INNER JOIN $postmeta sale ON sale.post_id = p.ID AND sale.meta_key = '_sale_price'
             WHERE p.post_parent = ? AND p.post_type = 'product_variation'
               AND sale.meta_value <> '' AND reg.meta_value <> ''
               AND CAST(sale.meta_value AS DECIMAL(19,4)) < CAST(reg.meta_value AS DECIMAL(19,4))",
            [$productId]
        );

        $this->db->execute(
            "UPDATE $lookup SET `min_price` = ?, `max_price` = ?, `onsale` = ? WHERE `product_id` = ?",
            [(float) $rows[0]['min_price'], (float) $rows[0]['max_price'], ((int) $onSale) > 0 ? 1 : 0, $productId]
        );

        // The parent's own `_price` is what a theme reading postmeta shows, and
        // WooCommerce keeps it at the lowest variation price — the number on the
        // category page.
        $this->writeMeta($productId, '_price', (string) (float) $rows[0]['min_price']);
    }

    /**
     * Recompute the price range of EVERY variable product on the site.
     *
     * The route behind `/maintenance/recalculate-prices`. wp-admin's Maintenance tab
     * has had this button all along and the app could not reach it, so a variable
     * product imported by this tool could show a wrong min/max on category pages —
     * which is the first price a shopper sees.
     *
     * @return array{products:int}
     */
    public function recalculatePrices(): array
    {
        $posts = $this->db->table('posts');

        $rows = $this->db->rows(
            "SELECT DISTINCT p.post_parent AS id
             FROM $posts p
             WHERE p.post_type = 'product_variation' AND p.post_parent > 0"
        );

        $touched = 0;

        foreach ($rows as $row) {
            $this->refreshPriceRange((int) $row['id']);
            $this->clearTransients((int) $row['id']);
            $touched++;
        }

        return ['products' => $touched];
    }

    /**
     * Drop the WooCommerce transients that cache this product's price.
     *
     * Written out by hand rather than calling `tsd_clear_woocommeerce_transients`,
     * and that is not fastidiousness. That procedure branches on
     * `IF(_idParent IS NOT null)`, and its non-null branch is
     * `DELETE FROM wp_options WHERE option_name LIKE CONCAT('%_', _idParent)` — a
     * LIKE that would match any option whose name happens to end in `_8412`,
     * WooCommerce's or not. The names below are exact.
     */
    private function clearTransients(int $productId): void
    {
        $options = $this->db->table('options');

        $names = [
            "_transient_wc_var_prices_$productId",
            "_transient_timeout_wc_var_prices_$productId",
            "_transient_wc_product_children_$productId",
            "_transient_timeout_wc_product_children_$productId",
            "_transient_wc_child_has_weight_$productId",
            "_transient_timeout_wc_child_has_weight_$productId",
            "_transient_wc_child_has_dimensions_$productId",
            "_transient_timeout_wc_child_has_dimensions_$productId",
            "_transient_wc_related_$productId",
            "_transient_timeout_wc_related_$productId",
        ];

        $this->db->execute(
            "DELETE FROM $options WHERE option_name IN ({$this->placeholders(count($names))})",
            $names
        );
    }

    private function touchModified(int $productId): void
    {
        $posts = $this->db->table('posts');

        $this->db->execute(
            "UPDATE $posts SET post_modified = UTC_TIMESTAMP(), post_modified_gmt = UTC_TIMESTAMP()
             WHERE ID = ?",
            [$productId]
        );
    }

    /* ---------------------------------------------------------- meta plumbing */

    /**
     * Write one postmeta value, inserting the row if it is not there.
     *
     * `affected_rows` cannot be used to decide between UPDATE and INSERT: it is 0
     * both when no row matched AND when the value written was identical to the one
     * already stored. So existence is read first.
     *
     * A duplicated meta_key — which messy sites do have — is updated in ALL its
     * rows rather than only the first, because leaving a stale duplicate behind is
     * how WooCommerce reads the old price back later.
     */
    private function writeMeta(int $productId, string $key, string $value): void
    {
        $postmeta = $this->db->table('postmeta');

        $existing = $this->db->rows(
            "SELECT meta_id FROM $postmeta WHERE post_id = ? AND meta_key = ? LIMIT 1",
            [$productId, $key]
        );

        if ($existing === []) {
            $this->db->execute(
                "INSERT INTO $postmeta (post_id, meta_key, meta_value) VALUES (?, ?, ?)",
                [$productId, $key, $value]
            );
            return;
        }

        $this->db->execute(
            "UPDATE $postmeta SET meta_value = ? WHERE post_id = ? AND meta_key = ?",
            [$value, $productId, $key]
        );
    }

    private function metaValue(int $productId, string $key): string
    {
        $postmeta = $this->db->table('postmeta');

        $rows = $this->db->rows(
            "SELECT meta_value FROM $postmeta WHERE post_id = ? AND meta_key = ? LIMIT 1",
            [$productId, $key]
        );

        return $rows === [] ? '' : (string) $rows[0]['meta_value'];
    }

    /**
     * Several meta keys for several products, in one statement.
     *
     * @param array<int,int> $ids
     * @param array<int,string> $keys
     * @return array<int,array<string,string>>
     */
    private function metaFor(array $ids, array $keys): array
    {
        $ids = array_values(array_unique(array_map('intval', $ids)));

        if ($ids === [] || $keys === []) {
            return [];
        }

        $postmeta = $this->db->table('postmeta');

        $rows = $this->db->rows(
            "SELECT post_id, meta_key, meta_value FROM $postmeta
             WHERE post_id IN ({$this->placeholders(count($ids))})
               AND meta_key IN ({$this->placeholders(count($keys))})",
            [...$ids, ...$keys]
        );

        $out = [];
        foreach ($rows as $row) {
            $id = (int) $row['post_id'];
            $key = (string) $row['meta_key'];
            // First wins, so a duplicated key reports the same value the lookup
            // rebuild will read.
            $out[$id][$key] ??= (string) $row['meta_value'];
        }

        return $out;
    }

    private function skuOf(int $productId): string
    {
        return $this->metaValue($productId, '_sku');
    }

    /**
     * @param array<int,int> $ids
     * @return array<int,string>
     */
    private function productTypes(array $ids): array
    {
        $ids = array_values(array_unique(array_map('intval', $ids)));

        if ($ids === []) {
            return [];
        }

        $terms = $this->db->table('terms');
        $taxonomies = $this->db->table('term_taxonomy');
        $relationships = $this->db->table('term_relationships');

        $rows = $this->db->rows(
            "SELECT tr.object_id, t.name
             FROM $relationships tr
             INNER JOIN $taxonomies tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
             INNER JOIN $terms t ON t.term_id = tt.term_id
             WHERE tr.object_id IN ({$this->placeholders(count($ids))}) AND tt.taxonomy = 'product_type'",
            $ids
        );

        $out = [];
        foreach ($rows as $row) {
            $out[(int) $row['object_id']] ??= (string) $row['name'];
        }

        return $out;
    }

    private function placeholders(int $count): string
    {
        return implode(',', array_fill(0, max(1, $count), '?'));
    }
}
