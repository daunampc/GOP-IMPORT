<?php

namespace GopImport\Import;

use GopImport\Db\Connection;
use GopImport\Db\TermRepository;
use GopImport\Media\AttachmentMeta;
use GopImport\Support\Slug;

/**
 * Creates products by calling stored functions — one call for the parent, one
 * per variation.
 *
 * Three differences from v2:
 *
 *  1. Each product sits in its own transaction. A failure on the 12th variation
 *     rolls back cleanly instead of leaving an orphaned parent behind, as v2 did.
 *  2. Idempotency keys: sending the same key again returns the existing id rather
 *     than creating a duplicate.
 *  3. Prepared statements are reused across the batch, and term ids are cached.
 */
final class ProductImporter
{
    private Connection $db;

    private TermRepository $terms;

    private MetaBuilder $meta;

    private AttachmentMeta $attachmentMeta;

    private Normalizer $normalizer;

    private string $fnPrefix;

    public function __construct(
        Connection $db,
        TermRepository $terms,
        MetaBuilder $meta,
        AttachmentMeta $attachmentMeta,
        Normalizer $normalizer,
        string $fnPrefix
    ) {
        $this->db = $db;
        $this->terms = $terms;
        $this->meta = $meta;
        $this->attachmentMeta = $attachmentMeta;
        $this->normalizer = $normalizer;
        $this->fnPrefix = $fnPrefix;
    }

    /**
     * Import a batch. Each item succeeds or fails on its own — one bad row does
     * not take the batch down with it.
     *
     * @param array<int,array<string,mixed>> $items
     * @return array<int,array<string,mixed>>
     */
    public function importBatch(array $items): array
    {
        $results = [];

        foreach ($items as $index => $item) {
            try {
                $results[] = ['index' => $index, 'ok' => true] + $this->importOne($item);
            } catch (ValidationException $e) {
                $results[] = [
                    'index' => $index,
                    'ok'    => false,
                    'error' => ['code' => $e->errorCode(), 'message' => $e->getMessage()],
                ];
            } catch (\Throwable $e) {
                $results[] = [
                    'index' => $index,
                    'ok'    => false,
                    'error' => ['code' => 'import_failed', 'message' => $e->getMessage()],
                ];
            }
        }

        return $results;
    }

    /**
     * @param array<string,mixed> $raw
     * @return array<string,mixed>
     */
    public function importOne(array $raw): array
    {
        $idempotencyKey = isset($raw['idempotency_key']) ? (string) $raw['idempotency_key'] : '';

        if ($idempotencyKey !== '') {
            $existing = $this->findByIdempotencyKey($idempotencyKey);
            if ($existing !== null) {
                return $existing + ['deduplicated' => true];
            }
        }

        $item = $this->normalizer->product($raw);

        $this->db->begin();
        try {
            $productId = $this->createParent($item);
            $variationIds = $this->createVariations($productId, $item);
            $reviewIds = $this->createReviews($productId, $item);

            if ($idempotencyKey !== '') {
                $this->rememberIdempotencyKey($idempotencyKey, $productId, $variationIds);
            }

            $this->db->commit();
        } catch (\mysqli_sql_exception $e) {
            $this->db->rollback();

            // 1062 = UNIQUE violation. Two requests carrying the same idempotency
            // key raced; one won. The loser reads the winner's result rather than
            // reporting an error — which is what idempotent actually means.
            if ($e->getCode() === 1062 && $idempotencyKey !== '') {
                $existing = $this->findByIdempotencyKey($idempotencyKey);
                if ($existing !== null) {
                    return $existing + ['deduplicated' => true];
                }
            }

            throw $e;
        } catch (\Throwable $e) {
            $this->db->rollback();
            throw $e;
        }

        return [
            'product_id'    => $productId,
            'sku'           => (string) ($item['sku'] ?? ''),
            'variation_ids' => $variationIds,
            'review_ids'    => $reviewIds,
        ];
    }

    /** @param array<string,mixed> $item */
    private function createParent(array $item): int
    {
        $categoryIds = [];
        $mergeSubCategory = $item['merge_name_sub_category'] ?? true;
        foreach ($item['categories'] as $category) {
            $categoryIds[] = $this->terms->category($category, (bool) $mergeSubCategory);
        }

        $tagIds = [];
        foreach ($item['tags'] as $tag) {
            $tagIds[] = $this->terms->tag($tag);
        }

        $shippingClassId = '';
        if (!empty($item['shipping_class'])) {
            $shippingClassId = (string) $this->terms->shippingClass((string) $item['shipping_class']);
        }

        $meta = $this->meta->build($item, false);

        $productId = (int) $this->db->callFunction($this->fnPrefix . 'create_product', [
            $item['name'],
            $item['slug'],
            $item['description'],
            $item['short_description'],
            implode(';', array_unique($categoryIds)),
            $item['type'],
            implode(';', $item['images']),
            $this->attachmentMeta->forList($item['images']),
            implode(';', array_unique($tagIds)),
            0,
            $meta['meta_key'],
            $meta['meta_value'],
            $item['reviews_allowed'] ? 'open' : 'closed',
            $item['status'],
            $shippingClassId,
        ]);

        if ($productId <= 0) {
            throw new \RuntimeException('The create_product stored function did not return a valid id.');
        }

        foreach ($item['attributes'] ?? [] as $attribute) {
            $name = (string) ($attribute['name'] ?? '');
            if ($name === '') {
                continue;
            }
            $values = array_map('strval', $attribute['values'] ?? []);
            $this->terms->attributeForProduct($productId, $name, $values);
        }

        return $productId;
    }

    /**
     * @param array<string,mixed> $item
     * @return array<int,int>
     */
    private function createVariations(int $productId, array $item): array
    {
        $ids = [];

        foreach ($item['variations'] as $variation) {
            $ids[] = $this->createVariation($productId, $item, $variation);
        }

        return $ids;
    }

    /**
     * @param array<string,mixed> $parent
     * @param array<string,mixed> $variation
     */
    private function createVariation(int $productId, array $parent, array $variation): int
    {
        // A variation takes its parent's title — that is how WooCommerce shows it.
        $title = (string) $parent['name'];

        $excerptParts = [];
        $slug = (string) $variation['slug'];
        $rebuildSlug = $slug === '';
        if ($rebuildSlug) {
            $slug = (string) $parent['slug'];
        }

        foreach ($variation['attributes'] as $attribute) {
            $name = (string) ($attribute['name'] ?? '');
            $value = (string) ($attribute['value'] ?? '');
            if ($name === '') {
                continue;
            }

            $attributeSlug = str_replace('--', '-', Slug::make($name));
            $variation['custom_meta']['attribute_pa_' . $attributeSlug] = Slug::make($value, true);

            $excerptParts[] = "$name: $value";

            if ($rebuildSlug) {
                $slug .= '-' . Slug::make($value);
            }
        }

        // WordPress limits post_name to 200 characters.
        if (strlen($slug) > 200) {
            $slug = substr($slug, 0, 191) . '-' . substr(md5($slug), 0, 8);
        }

        while (str_contains($slug, '--')) {
            $slug = str_replace('--', '-', $slug);
        }

        $images = [];
        if (!empty($variation['images']) && is_array($variation['images'])) {
            $images = array_values(array_filter(array_map('strval', $variation['images'])));
        } elseif (!empty($variation['image'])) {
            $images = [(string) $variation['image']];
        }

        $shippingClassId = '';
        if (!empty($variation['shipping_class'])) {
            $shippingClassId = (string) $this->terms->shippingClass((string) $variation['shipping_class']);
        }

        $meta = $this->meta->build($variation, true);

        // create_variant takes prices as DOUBLE; v2's 'null' maps to 0.
        $price = $variation['price'] === 'null' ? 0.0 : (float) $variation['price'];

        $id = (int) $this->db->callFunction($this->fnPrefix . 'create_variant', [
            $title,
            $slug,
            $variation['description'],
            implode(', ', $excerptParts),
            $price,
            (string) ($variation['virtual'] ?? 'no'),
            (string) ($variation['downloadable'] ?? 'no'),
            $variation['instock'] ? 'instock' : 'outofstock',
            implode(';', $images),
            $this->attachmentMeta->forList($images),
            $productId,
            $meta['meta_key'],
            $meta['meta_value'],
            $variation['reviews_allowed'] ? 'open' : 'closed',
            $variation['status'],
            $shippingClassId,
        ]);

        if ($id <= 0) {
            throw new \RuntimeException("Creating a variation failed for product $productId.");
        }

        return $id;
    }

    /**
     * @param array<string,mixed> $item
     * @return array<int,int>
     */
    private function createReviews(int $productId, array $item): array
    {
        $ids = [];

        foreach ($item['reviews'] ?? [] as $review) {
            // An empty string has to become NULL: the stored function's parameter
            // is DATETIME, and MySQL 8 rejects '' at the point of binding.
            $createdAt = trim((string) ($review['time_create'] ?? $review['date'] ?? ''));

            // The stored function's parameter order: (..., _time_reate, _rating)
            $ids[] = (int) $this->db->callFunction($this->fnPrefix . 'create_review', [
                $productId,
                (string) ($review['review_author'] ?? ''),
                (string) ($review['review_author_email'] ?? ''),
                (string) ($review['review_content'] ?? ''),
                $createdAt === '' ? null : $createdAt,
                (float) ($review['rating'] ?? 5),
            ]);
        }

        return $ids;
    }

    /** @return array<string,mixed>|null */
    private function findByIdempotencyKey(string $key): ?array
    {
        $table = $this->db->table('tsd_import_log');

        $rows = $this->db->rows(
            "SELECT product_id, variation_ids FROM $table WHERE idempotency_key = ? LIMIT 1",
            [$key]
        );

        if ($rows === []) {
            return null;
        }

        return [
            'product_id'    => (int) $rows[0]['product_id'],
            'variation_ids' => array_map('intval', array_filter(explode(',', (string) $rows[0]['variation_ids']))),
            'review_ids'    => [],
            'sku'           => '',
        ];
    }

    /** @param array<int,int> $variationIds */
    private function rememberIdempotencyKey(string $key, int $productId, array $variationIds): void
    {
        $table = $this->db->table('tsd_import_log');

        $this->db->execute(
            "INSERT INTO $table (idempotency_key, product_id, variation_ids, created_at)
             VALUES (?, ?, ?, NOW())",
            [$key, $productId, implode(',', $variationIds)]
        );
    }
}
