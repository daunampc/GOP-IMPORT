<?php

namespace GopImport\Import;

/** A bad payload — the client's fault, so 400 rather than 500. */
final class ValidationException extends \RuntimeException
{
    // NOT named `$code`: Exception already declares that property as
    // protected, and redeclaring it as private is a fatal error.
    private string $errorCode;

    public function __construct(string $errorCode, string $message)
    {
        parent::__construct($message);
        $this->errorCode = $errorCode;
    }

    public function errorCode(): string
    {
        return $this->errorCode;
    }
}
