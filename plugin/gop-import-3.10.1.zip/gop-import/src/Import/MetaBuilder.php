<?php

namespace GopImport\Import;

use GopImport\Support\Slug;

/**
 * Packs postmeta into a pair of strings (keys, values) separated by `<->`.
 *
 * This is the core speed trick inherited from v2: by folding an array into a
 * string, a stored function with a fixed parameter list can still accept any
 * number of meta rows, and every postmeta INSERT happens inside MySQL instead of
 * one round trip each.
 */
final class MetaBuilder
{
    public const SEPARATOR = '<->';

    /** Maps a JSON field to WooCommerce's meta_key. */
    private const FIELD_TO_META = [
        'sku'               => '_sku',
        'total_sales'       => 'total_sales',
        'tax_status'        => '_tax_status',
        'tax_class'         => '_tax_class',
        'manage_stock'      => '_manage_stock',
        'backorders'        => '_backorders',
        'sold_individually' => '_sold_individually',
        'virtual'           => '_virtual',
        'downloadable'      => '_downloadable',
        'download_limit'    => '_download_limit',
        'download_expiry'   => '_download_expiry',
        'stock'             => '_stock',
        'regular_price'     => '_regular_price',
        'price'             => '_price',
        'low_stock_amount'  => '_low_stock_amount',
        'weight'            => '_weight',
        'length'            => '_length',
        'width'             => '_width',
        'height'            => '_height',
        'purchase_note'     => '_purchase_note',
        'sale_price'        => '_sale_price',
        'date_sale_start'   => '_sale_price_dates_from',
        'date_sale_end'     => '_sale_price_dates_to',
    ];

    /**
     * @param array<string,mixed> $item
     * @return array{meta_key:string, meta_value:string}
     */
    public function build(array $item, bool $isVariation = false): array
    {
        $keys = [];
        $values = [];

        foreach (self::FIELD_TO_META as $field => $metaKey) {
            if (!isset($item[$field])) {
                continue;
            }
            $value = $item[$field];
            if ($value === null || $value === 'null') {
                continue;
            }
            $keys[] = $this->sanitize($metaKey);
            $values[] = $this->sanitize((string) $value);
        }

        $keys[] = '_stock_status';
        $values[] = !empty($item['instock']) ? 'instock' : 'outofstock';

        if (!$isVariation && isset($item['attributes'])) {
            $keys[] = '_product_attributes';
            $values[] = $this->serializeAttributes($item['attributes']);
        }

        if (!$isVariation && isset($item['default_attributes'])) {
            $keys[] = '_default_attributes';
            $values[] = $this->serializeDefaultAttributes($item['default_attributes']);
        }

        foreach ($this->customMeta($item) as $key => $value) {
            $keys[] = $this->sanitize($key);
            $values[] = $this->sanitize($value);
        }

        return [
            'meta_key'   => implode(self::SEPARATOR, $keys),
            'meta_value' => implode(self::SEPARATOR, $values),
        ];
    }

    /**
     * `<->` is the internal separator; if it appears in the data itself the meta
     * would be split in the wrong place. v2 replaced it with a space, and that
     * behaviour is kept.
     */
    private function sanitize(string $value): string
    {
        return str_replace(self::SEPARATOR, ' ', $value);
    }

    /**
     * @param array<string,mixed> $item
     * @return array<string,string>
     */
    private function customMeta(array $item): array
    {
        $out = [];

        foreach ($item['custom_meta'] ?? [] as $key => $value) {
            // v2 skipped an empty attribute_pa_*, because WooCommerce reads
            // "nothing chosen" differently from "chose an empty value".
            if ($value === null && str_contains((string) $key, '_pa_')) {
                continue;
            }
            $out[(string) $key] = (string) ($value ?? '');
        }

        if (isset($item['cloud_info'])) {
            $out['cloud_info'] = json_encode($item['cloud_info'], JSON_UNESCAPED_UNICODE);
        }

        return $out;
    }

    /**
     * WooCommerce stores `_product_attributes` as a PHP-serialised array.
     *
     * Uses the real serialize() rather than assembling the string by hand as v2
     * did — v2 counted lengths with strlen and concatenated, and one byte out
     * corrupted the whole meta silently.
     *
     * The flag values are kept as STRINGS ('0'/'1') rather than ints, to stay
     * byte-compatible with what v2 wrote. WooCommerce reads both, but a theme or
     * plugin reading the meta directly sees exactly what it saw before.
     *
     * @param array<int,array<string,mixed>> $attributes
     */
    private function serializeAttributes(array $attributes): string
    {
        $out = [];
        $position = 0;

        foreach ($attributes as $attribute) {
            $name = (string) ($attribute['name'] ?? '');
            if ($name === '') {
                continue;
            }

            // v2 used the key `used_for_variation`; `variation` is accepted too,
            // for brevity.
            $usedForVariation = $attribute['used_for_variation'] ?? $attribute['variation'] ?? true;

            $taxonomy = 'pa_' . Slug::make($name);
            $out[$taxonomy] = [
                'name'         => $taxonomy,
                'value'        => '',
                'position'     => (string) $position++,
                'is_visible'   => ($attribute['visible'] ?? true) ? '1' : '0',
                'is_variation' => $usedForVariation ? '1' : '0',
                'is_taxonomy'  => '1',
            ];
        }

        return serialize($out);
    }

    /**
     * WooCommerce keys `_default_attributes` by taxonomy name (`pa_color`),
     * with no `attribute_` prefix.
     *
     * @param array<int,array<string,mixed>> $defaults
     */
    private function serializeDefaultAttributes(array $defaults): string
    {
        $out = [];
        foreach ($defaults as $default) {
            $name = (string) ($default['name'] ?? '');
            if ($name === '') {
                continue;
            }
            $out['pa_' . Slug::make($name)] = Slug::make((string) ($default['value'] ?? ''), true);
        }

        return serialize($out);
    }
}
