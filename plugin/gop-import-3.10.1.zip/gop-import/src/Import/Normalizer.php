<?php

namespace GopImport\Import;

use GopImport\Support\Slug;

/**
 * Fills in defaults and validates a payload before anything touches the
 * database.
 *
 * One important difference from v2: anything wrong throws a ValidationException
 * right here, rather than drifting down into SQL and failing halfway.
 */
final class Normalizer
{
    private const TYPES = ['simple', 'variable', 'external'];

    private const STATUSES = ['publish', 'draft', 'pending', 'private', 'future'];

    /**
     * @param array<string,mixed> $item
     * @return array<string,mixed>
     * @throws ValidationException
     */
    public function product(array $item): array
    {
        if (!isset($item['name']) || trim((string) $item['name']) === '') {
            throw new ValidationException('missing_name', 'A product must have a `name`.');
        }

        $item['name'] = (string) $item['name'];
        $item['type'] = $this->type($item);
        $item['status'] = $this->status($item['status'] ?? 'publish');
        $item['slug'] = $this->slug($item['slug'] ?? '', $item['name']);
        $item['description'] = (string) ($item['description'] ?? '');
        $item['short_description'] = (string) ($item['short_description'] ?? '');
        $item['categories'] = $this->stringList($item['categories'] ?? [], 'categories');
        $item['tags'] = $this->stringList($item['tags'] ?? [], 'tags');
        $item['images'] = $this->images($item['images'] ?? []);
        $item['custom_meta'] = $this->customMeta($item['custom_meta'] ?? []);
        $item['reviews_allowed'] = $item['reviews_allowed'] ?? true;
        $item['instock'] = $this->bool($item['instock'] ?? false);

        $item = $this->prices($item);

        if (($item['mode_import'] ?? '') === 'full_data') {
            $item = $this->fullDataDefaults($item, false);
        }

        $item['variations'] = $this->variations($item);

        // Variations present means the product is variable, whatever `type` the
        // client sent.
        if ($item['variations'] !== []) {
            $item['type'] = 'variable';
        }

        return $item;
    }

    /**
     * @param array<string,mixed> $item
     * @return array<string,mixed>
     */
    public function variation(array $item, bool $fullData): array
    {
        $item['slug'] = $this->slug($item['slug'] ?? '');
        $item['description'] = (string) ($item['description'] ?? '');
        $item['status'] = $this->status($item['status'] ?? 'publish');
        $item['custom_meta'] = $this->customMeta($item['custom_meta'] ?? []);
        $item['reviews_allowed'] = $item['reviews_allowed'] ?? true;
        $item['instock'] = $this->bool($item['instock'] ?? false);
        $item['attributes'] = $item['attributes'] ?? [];

        $item = $this->prices($item);

        if ($fullData) {
            $item = $this->fullDataDefaults($item, true);
        }

        return $item;
    }

    /**
     * @param array<string,mixed> $item
     * @return array<string,mixed>
     */
    private function prices(array $item): array
    {
        // The string 'null' is v2's convention for "no price".
        if (!isset($item['price']) || $item['price'] === '') {
            $item['price'] = 'null';
        }

        if (!isset($item['regular_price']) || $item['regular_price'] === '') {
            $item['regular_price'] = $item['price'];
        }

        // With a sale price set, the displayed `_price` must be the sale price.
        if (isset($item['sale_price']) && $item['sale_price'] !== '' && $item['price'] !== $item['sale_price']) {
            $item['price'] = $item['sale_price'];
        }

        return $item;
    }

    /**
     * @param array<string,mixed> $item
     * @return array<string,mixed>
     */
    private function fullDataDefaults(array $item, bool $isVariation): array
    {
        $defaults = [
            'tax_status'        => 'taxable',
            'tax_class'         => $isVariation ? 'parent' : '',
            'backorders'        => 'no',
            'sold_individually' => 'no',
            'virtual'           => 'no',
            'downloadable'      => 'no',
            'download_limit'    => '-1',
            'download_expiry'   => -1,
            'average_rating'    => 0,
            'review_count'      => 0,
            'total_sales'       => 0,
        ];

        foreach ($defaults as $key => $value) {
            if (!isset($item[$key]) || $item[$key] === '') {
                $item[$key] = $value;
            }
        }

        if (!isset($item['stock']) || $item['stock'] === '') {
            $item['stock'] = null;
            $item['manage_stock'] = 'no';
        } else {
            $item['manage_stock'] = 'yes';
        }

        return $item;
    }

    /**
     * @param array<string,mixed> $item
     * @return array<int,array<string,mixed>>
     */
    private function variations(array $item): array
    {
        $variations = $item['variations'] ?? [];
        if (!is_array($variations)) {
            throw new ValidationException('invalid_variations', '`variations` must be an array.');
        }

        $fullData = ($item['mode_import'] ?? '') === 'full_data';
        $out = [];

        foreach ($variations as $index => $variation) {
            if (!is_array($variation)) {
                throw new ValidationException('invalid_variation', "variations[$index] must be an object.");
            }
            $out[] = $this->variation($variation, $fullData);
        }

        return $out;
    }

    /** @param array<string,mixed> $item */
    private function type(array $item): string
    {
        $type = (string) ($item['type'] ?? 'simple');
        if ($type === '') {
            $type = 'simple';
        }
        if (!in_array($type, self::TYPES, true)) {
            throw new ValidationException(
                'invalid_type',
                '`type` must be one of: ' . implode(', ', self::TYPES) . " (received: $type)"
            );
        }
        return $type;
    }

    private function status(string $status): string
    {
        if ($status === '') {
            return 'publish';
        }
        if (!in_array($status, self::STATUSES, true)) {
            throw new ValidationException(
                'invalid_status',
                '`status` must be one of: ' . implode(', ', self::STATUSES)
            );
        }
        return $status;
    }

    /**
     * A product's slug. NEVER returns an empty string.
     *
     * `$fallback` (the product name) is the last safety net. A client sending an
     * empty slug used to produce an empty `post_name`, and WordPress then served
     * the product at `domain.com/product//` — present in the database and
     * impossible to open. This is a public API with several callers, so it takes
     * care of this itself rather than trusting the client to have done so.
     */
    private function slug(string $slug, string $fallback = ''): string
    {
        $slug = trim($slug);

        if ($slug === '' && $fallback !== '') {
            $slug = Slug::make($fallback);
        }

        // A name in a non-Latin script slugs to nothing; hash it so there is a
        // stable path rather than no path at all.
        if ($slug === '' && $fallback !== '') {
            $slug = 'product-' . substr(md5($fallback), 0, 10);
        }

        // Collapse repeated dashes — WordPress never produces `a--b`.
        while (str_contains($slug, '--')) {
            $slug = str_replace('--', '-', $slug);
        }

        return trim($slug, '-');
    }

    /**
     * @param mixed $values
     * @return array<int,string>
     */
    private function stringList($values, string $field): array
    {
        if (!is_array($values)) {
            throw new ValidationException('invalid_' . $field, "`$field` must be an array of strings.");
        }

        $out = [];
        foreach ($values as $value) {
            $value = trim((string) $value);
            if ($value !== '') {
                $out[] = $value;
            }
        }

        return array_values(array_unique($out));
    }

    /**
     * @param mixed $images
     * @return array<int,string>
     */
    private function images($images): array
    {
        if (!is_array($images)) {
            throw new ValidationException('invalid_images', '`images` must be an array of URLs.');
        }

        $out = [];
        foreach ($images as $url) {
            $url = trim((string) $url);
            if ($url === '') {
                continue;
            }
            if (!preg_match('~^https?://~i', $url)) {
                throw new ValidationException('invalid_image_url', "Invalid image URL: $url");
            }
            // `;` is the separator for the image list on the way into SQL.
            if (str_contains($url, ';')) {
                throw new ValidationException('invalid_image_url', "An image URL may not contain `;`: $url");
            }
            $out[] = $url;
        }

        return $out;
    }

    /**
     * @param mixed $meta
     * @return array<string,mixed>
     */
    private function customMeta($meta): array
    {
        if ($meta === '' || $meta === null) {
            return [];
        }
        if (!is_array($meta)) {
            throw new ValidationException('invalid_custom_meta', '`custom_meta` must be an object.');
        }
        return $meta;
    }

    /** @param mixed $value */
    private function bool($value): bool
    {
        return filter_var($value, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE) ?? (bool) $value;
    }
}
