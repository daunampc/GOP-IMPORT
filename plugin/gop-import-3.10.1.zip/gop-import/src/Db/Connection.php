<?php

namespace GopImport\Db;

use GopImport\Support\Config;

/**
 * A mysqli wrapper with two things v2 did not have:
 *
 *  - A persistent connection (the `p:` prefix), which drops the TCP handshake
 *    and authentication from every request.
 *  - A prepared-statement cache: each SQL string is prepared ONCE for the whole
 *    batch and then executed repeatedly. This is where the time goes when
 *    importing 50 products at once.
 */
final class Connection
{
    private \mysqli $db;

    /** @var array<string,\mysqli_stmt> */
    private array $statements = [];

    private string $prefix;

    public function __construct(Config $config)
    {
        // Make mysqli throw rather than return false — fail early instead of
        // swallowing the error.
        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

        $host = (string) $config->require('db_host');
        $port = null;
        if (str_contains($host, ':')) {
            [$host, $portPart] = explode(':', $host, 2);
            $port = is_numeric($portPart) ? (int) $portPart : null;
        }

        $persistent = (string) $config->get('persistent_connection', '1') === '1';

        $this->db = new \mysqli(
            ($persistent ? 'p:' : '') . $host,
            (string) $config->require('db_user'),
            (string) $config->get('db_password', ''),
            (string) $config->require('db_name'),
            $port
        );

        $charset = (string) $config->get('charset', 'utf8mb4');
        if ($charset !== '') {
            @$this->db->set_charset($charset);
        }

        // Pin the session collation to the REAL collation of wp_posts, which
        // setup.php detects and writes into the config.
        //
        // Without this, MySQL 8 compares variables inside a stored function
        // using the server default (utf8mb4_0900_ai_ci) while the columns use
        // utf8mb4_unicode_ci, and every `=` between the two blows up with
        // "Illegal mix of collations". That is exactly why v2 needed an entire
        // convert_charset_database function to paper over it.
        $collate = (string) $config->get('collate', '');
        if ($charset !== '' && $collate !== ''
            && preg_match('/^[a-z0-9_]+$/i', $charset)
            && preg_match('/^[a-z0-9_]+$/i', $collate)
        ) {
            @$this->db->query("SET NAMES '$charset' COLLATE '$collate'");
        }

        // The same sql_mode as v2: the inherited stored functions were written
        // assuming it — 0000-00-00 dates allowed, not strict.
        @$this->db->query("SET SESSION sql_mode='NO_ZERO_IN_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION'");

        $this->prefix = $config->tablePrefix();
    }

    public function raw(): \mysqli
    {
        return $this->db;
    }

    public function prefix(): string
    {
        return $this->prefix;
    }

    /** A WordPress table name with the prefix applied. */
    public function table(string $name): string
    {
        return '`' . $this->prefix . $name . '`';
    }

    /**
     * Prepare, with a cache. Calling this again with the same $sql inside one
     * request returns the existing statement instead of another prepare round
     * trip.
     */
    public function prepare(string $sql): \mysqli_stmt
    {
        if (!isset($this->statements[$sql])) {
            $this->statements[$sql] = $this->db->prepare($sql);
        }
        return $this->statements[$sql];
    }

    /**
     * Call a stored function and return its scalar result.
     *
     * @param array<int,mixed> $params
     */
    public function callFunction(string $function, array $params)
    {
        $placeholders = implode(',', array_fill(0, count($params), '?'));
        $stmt = $this->prepare("SELECT `$function`($placeholders) AS result");

        if ($params !== []) {
            $stmt->bind_param($this->typeString($params), ...$params);
        }
        $stmt->execute();

        $result = $stmt->get_result();
        $row = $result->fetch_row();
        $result->free();

        return $row[0] ?? null;
    }

    /** @param array<int,mixed> $params */
    public function scalar(string $sql, array $params = [])
    {
        $stmt = $this->prepare($sql);
        if ($params !== []) {
            $stmt->bind_param($this->typeString($params), ...$params);
        }
        $stmt->execute();

        $result = $stmt->get_result();
        $row = $result->fetch_row();
        $result->free();

        return $row[0] ?? null;
    }

    /**
     * @param array<int,mixed> $params
     * @return array<int,array<string,mixed>>
     */
    public function rows(string $sql, array $params = []): array
    {
        $stmt = $this->prepare($sql);
        if ($params !== []) {
            $stmt->bind_param($this->typeString($params), ...$params);
        }
        $stmt->execute();

        $result = $stmt->get_result();
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        $result->free();

        return $rows;
    }

    /** @param array<int,mixed> $params */
    public function execute(string $sql, array $params = []): void
    {
        $stmt = $this->prepare($sql);
        if ($params !== []) {
            $stmt->bind_param($this->typeString($params), ...$params);
        }
        $stmt->execute();
    }

    public function begin(): void
    {
        $this->db->begin_transaction();
    }

    public function commit(): void
    {
        $this->db->commit();
    }

    public function rollback(): void
    {
        $this->db->rollback();
    }

    /**
     * mysqli needs a type string for bind_param. Anything that is not an int or
     * a float is sent as a string — the stored function casts it itself, and
     * that avoids large numbers being rounded on the way in.
     *
     * @param array<int,mixed> $params
     */
    private function typeString(array $params): string
    {
        $types = '';
        foreach ($params as $param) {
            if (is_int($param)) {
                $types .= 'i';
            } elseif (is_float($param)) {
                $types .= 'd';
            } else {
                $types .= 's';
            }
        }
        return $types;
    }
}
