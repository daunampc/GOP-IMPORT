<?php

namespace GopImport\Db;

use GopImport\Support\Slug;

/**
 * Resolves category / tag / shipping-class NAMES to term ids, memoised for the
 * life of one request.
 *
 * One of the clearest speed-ups over v2. v2 called `create_category()` for every
 * category of every product, so importing 50 products sharing 3 categories cost
 * 150 round trips. Here it costs 3, and everything after that comes from the
 * cache.
 */
final class TermRepository
{
    private Connection $db;

    private string $fnPrefix;

    /** @var array<string,int> keyed by "taxonomy|parent|slug" */
    private array $cache = [];

    public function __construct(Connection $db, string $fnPrefix)
    {
        $this->db = $db;
        $this->fnPrefix = $fnPrefix;
    }

    /**
     * Categories support a hierarchy written with `>`:
     * "Clothing > T-shirts > Men" creates three nested levels and returns the id
     * of the deepest one.
     *
     * @param bool $mergeNameSubCategory when true a child's slug folds in the
     *   parent's name ("clothing-t-shirts"); when false it uses its own name
     *   only ("t-shirts"). Defaults to true, to match data already imported by
     *   v2.
     */
    public function category(string $breadcrumb, bool $mergeNameSubCategory = true): int
    {
        $parentId = 0;
        $accumulated = '';

        foreach (explode('>', $breadcrumb) as $name) {
            $name = trim($name);
            if ($name === '') {
                continue;
            }

            $accumulated = $accumulated === '' ? $name : $accumulated . ' ' . $name;
            $slugSource = $mergeNameSubCategory ? $accumulated : $name;

            $parentId = $this->resolve($name, Slug::make($slugSource), 'product_cat', $parentId);
        }

        return $parentId;
    }

    public function tag(string $name): int
    {
        return $this->resolve($name, Slug::make($name), 'product_tag', 0);
    }

    public function shippingClass(string $name): int
    {
        return $this->resolve($name, Slug::make($name), 'product_shipping_class', 0);
    }

    /**
     * Create a global attribute (pa_*) together with its list of values, and
     * return the attribute's id.
     *
     * @param array<int,string> $values
     */
    public function attribute(string $label, array $values): int
    {
        $slug = Slug::make($label);
        $key = "attribute|0|$slug";
        if (isset($this->cache[$key])) {
            return $this->cache[$key];
        }

        $id = (int) $this->db->callFunction(
            $this->fnPrefix . 'create_attribute',
            [$label, $slug, implode(';', $values)]
        );

        return $this->cache[$key] = $id;
    }

    /**
     * Attach an attribute to one specific product (the term_relationships
     * table). Not cacheable, because it depends on the product id.
     *
     * @param array<int,string> $values
     */
    public function attributeForProduct(int $productId, string $label, array $values): void
    {
        $slugs = array_map(static fn ($value) => Slug::make((string) $value), $values);

        $this->db->callFunction($this->fnPrefix . 'create_attribute_for_product', [
            $productId,
            $label,
            Slug::make($label),
            implode(';', $values),
            implode(';', $slugs),
        ]);
    }

    private function resolve(string $name, string $slug, string $taxonomy, int $parentId): int
    {
        $key = "$taxonomy|$parentId|$slug";
        if (isset($this->cache[$key])) {
            return $this->cache[$key];
        }

        $id = (int) $this->db->callFunction(
            $this->fnPrefix . 'create_term',
            [$name, $slug, $taxonomy, $parentId]
        );

        return $this->cache[$key] = $id;
    }
}
