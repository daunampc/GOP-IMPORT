<?php

namespace GopImport\Setup;

/** An installation failure, with a message complete enough to act on. */
final class InstallerException extends \RuntimeException
{
}
