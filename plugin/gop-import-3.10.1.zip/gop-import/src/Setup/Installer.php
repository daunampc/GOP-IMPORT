<?php

namespace GopImport\Setup;

use GopImport\Support\Config;
use GopImport\Support\SqlRewriter;

/**
 * The installation logic, shared by BOTH ways in: `setup.php` from the command
 * line, and the wp-admin screen.
 *
 * Kept in one place deliberately. It used to live entirely inside setup.php;
 * copying it to add the admin screen would have let the two drift apart, and a
 * bug fixed on one side would have stayed on the other.
 */
final class Installer
{
    /** @var array<int,string> */
    private array $log = [];

    private string $functionPrefix;

    public function __construct(string $functionPrefix)
    {
        $this->functionPrefix = $functionPrefix;
    }

    /** @return array<int,string> */
    public function log(): array
    {
        return $this->log;
    }

    private function say(string $message): void
    {
        $this->log[] = $message;
    }

    /**
     * Read the database credentials out of wp-config.php by PARSING the text.
     *
     * For the CLI path only. Inside wp-admin, WordPress has already defined the
     * `DB_*` constants, so `fromWordPress()` is strictly more accurate — no
     * guessing where the file is, no worrying about an unusual wp-config.
     *
     * @return array<string,string>
     */
    public static function parseWpConfig(string $path): array
    {
        $source = (string) file_get_contents($path);
        $out = [];

        foreach (['DB_NAME', 'DB_USER', 'DB_PASSWORD', 'DB_HOST', 'DB_CHARSET', 'DB_COLLATE'] as $constant) {
            if (preg_match(
                '/define\s*\(\s*[\'"]' . $constant . '[\'"]\s*,\s*(["\'])(.*?)\1\s*\)/s',
                $source,
                $matches
            )) {
                $out[$constant] = $matches[2];
            }
        }

        if (preg_match('/\$table_prefix\s*=\s*([\'"])(.*?)\1/', $source, $matches)) {
            $out['table_prefix'] = $matches[2];
        }

        return $out;
    }

    /** Look for wp-config.php in the usual places. CLI path only. */
    public static function findWpConfig(string $pluginDir): ?string
    {
        $candidates = [
            dirname($pluginDir, 2) . '/wp-config.php',   // wp-content/plugins/<plugin>/ → WP root
            dirname($pluginDir, 3) . '/wp-config.php',
            dirname($pluginDir, 1) . '/wp-config.php',
            $pluginDir . '/wp-config.php',
        ];

        foreach ($candidates as $candidate) {
            if (is_file($candidate)) {
                return $candidate;
            }
        }

        return null;
    }

    /**
     * Database credentials taken straight from WordPress's own constants.
     * Only callable from inside WordPress.
     *
     * @return array<string,string>
     */
    public static function fromWordPress(): array
    {
        global $table_prefix;

        return [
            'DB_NAME'      => DB_NAME,
            'DB_USER'      => DB_USER,
            'DB_PASSWORD'  => DB_PASSWORD,
            'DB_HOST'      => DB_HOST,
            'table_prefix' => $table_prefix,
        ];
    }

    public function connect(array $credentials): \mysqli
    {
        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

        $connection = new \mysqli(
            $credentials['DB_HOST'],
            $credentials['DB_USER'],
            $credentials['DB_PASSWORD'] ?? '',
            $credentials['DB_NAME']
        );

        @$connection->query(
            "SET SESSION sql_mode='NO_ZERO_IN_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION'"
        );

        return $connection;
    }

    /**
     * Detect the REAL charset and collation of the posts table.
     *
     * This has to be right: MySQL 8 defaults to `utf8mb4_0900_ai_ci` while a
     * WordPress table is usually `utf8mb4_unicode_ci`, and any mismatch makes
     * every comparison inside a stored function fail with "Illegal mix of
     * collations".
     *
     * @return array{0:string,1:string}
     */
    public function detectCharsetCollate(\mysqli $connection, string $dbName, string $tablePrefix): array
    {
        $statement = $connection->prepare(
            'SELECT CCSA.character_set_name AS cs, CCSA.collation_name AS co
             FROM information_schema.TABLES T
             INNER JOIN information_schema.COLLATION_CHARACTER_SET_APPLICABILITY CCSA
                 ON CCSA.collation_name = T.table_collation
             WHERE T.table_schema = ? AND T.table_name = ?
             LIMIT 1'
        );

        $table = $tablePrefix . 'posts';
        $statement->bind_param('ss', $dbName, $table);
        $statement->execute();

        $row = $statement->get_result()->fetch_assoc();

        // The returned column name's case varies between MySQL versions.
        $charset = $row['cs'] ?? $row['CS'] ?? 'utf8mb4';
        $collate = $row['co'] ?? $row['CO'] ?? 'utf8mb4_unicode_ci';

        $this->say("Charset: $charset / $collate");

        return [(string) $charset, (string) $collate];
    }

    /** The tables the stored functions touch — the only ones whose collation matters. */
    private const TOUCHED_TABLES = [
        'posts', 'postmeta', 'terms', 'term_taxonomy', 'term_relationships', 'termmeta',
        'options', 'comments', 'commentmeta',
        'wc_product_meta_lookup', 'woocommerce_attribute_taxonomies',
    ];

    /**
     * Bring the database and every relevant table to ONE collation.
     *
     * Required, not optional. MySQL gives a stored function's parameters the
     * DATABASE's default collation at the moment the function is created — not
     * the session's. If the database defaults to `utf8mb4_unicode_ci` while
     * `wp_posts` is `utf8mb4_unicode_520_ci` (WordPress prefers 520 where it is
     * available), every comparison between a parameter and a column fails with
     * "Illegal mix of collations".
     *
     * In practice it is worse than that: WordPress creates its core tables with
     * one collation while WooCommerce creates its own with the server default —
     * two tables in one database, disagreeing.
     *
     * ALTER DATABASE only changes the default for objects created afterwards; it
     * rewrites no data. ALTER TABLE does rewrite, so only tables that actually
     * DIFFER are touched, and each one is named in the log.
     *
     * @throws InstallerException
     */
    public function normalizeCollation(
        \mysqli $connection,
        string $dbName,
        string $tablePrefix,
        string $charset,
        string $collate
    ): void {
        try {
            $connection->query("ALTER DATABASE `$dbName` DEFAULT CHARACTER SET = $charset DEFAULT COLLATE = $collate");
            $this->say("Set the database default collation: $collate");
        } catch (\mysqli_sql_exception $exception) {
            throw new InstallerException(
                'Could not change the database default collation (' . $exception->getMessage() . '). '
                . 'The MySQL account needs ALTER on the database. Without this step the stored functions '
                . 'will report "Illegal mix of collations" during an import.'
            );
        }

        $names = array_map(
            static fn (string $table): string => $tablePrefix . $table,
            self::TOUCHED_TABLES
        );

        $placeholders = implode(',', array_fill(0, count($names), '?'));

        $statement = $connection->prepare(
            "SELECT TABLE_NAME, TABLE_COLLATION FROM information_schema.TABLES
             WHERE TABLE_SCHEMA = ? AND TABLE_NAME IN ($placeholders)"
        );

        $statement->bind_param(str_repeat('s', count($names) + 1), $dbName, ...$names);
        $statement->execute();

        $mismatched = [];
        $result = $statement->get_result();
        while ($row = $result->fetch_assoc()) {
            if ((string) $row['TABLE_COLLATION'] !== $collate) {
                $mismatched[] = (string) $row['TABLE_NAME'];
            }
        }
        $result->free();

        if ($mismatched === []) {
            $this->say('Every relevant table already shares one collation');
            return;
        }

        foreach ($mismatched as $table) {
            try {
                $connection->query("ALTER TABLE `$table` CONVERT TO CHARACTER SET $charset COLLATE $collate");
                $this->say("Aligning the collation of $table");
            } catch (\mysqli_sql_exception $exception) {
                throw new InstallerException(
                    "Could not align the collation of $table: " . $exception->getMessage()
                );
            }
        }
    }

    /**
     * Install every stored function and procedure.
     *
     * Must run AFTER normalizeCollation(): a function's parameters take the
     * database's default collation at the exact moment it is created.
     *
     * @throws InstallerException
     */
    public function installRoutines(\mysqli $connection, string $tablePrefix, string $sqlDir): void
    {
        $rewriter = new SqlRewriter($this->functionPrefix, $tablePrefix);

        $files = glob($sqlDir . '/*.sql');
        if ($files === false || $files === []) {
            throw new InstallerException("No SQL files were found in $sqlDir");
        }

        // File order is install order: 01_slugify first, because
        // create_attribute calls it.
        sort($files);

        foreach ($rewriter->prefixedRoutines() as $name) {
            @$connection->query("DROP FUNCTION IF EXISTS `$name`");
            @$connection->query("DROP PROCEDURE IF EXISTS `$name`");
        }

        foreach ($files as $file) {
            $name = basename($file);

            try {
                $connection->query($rewriter->rewrite((string) file_get_contents($file)));
                $this->say("Installing $name");
            } catch (\mysqli_sql_exception $exception) {
                // 1419: binary logging is on and MySQL demands SUPER to create
                // a function.
                if ($exception->getCode() === 1419) {
                    throw new InstallerException(
                        "Could not create the stored function ($name): binary logging is on and MySQL "
                        . "requires SUPER. Ask the host to run: SET GLOBAL log_bin_trust_function_creators = 1;"
                    );
                }

                throw new InstallerException(
                    "Failed installing $name: (" . $exception->getCode() . ') ' . $exception->getMessage()
                );
            }
        }
    }

    public function installTables(
        \mysqli $connection,
        string $tablePrefix,
        string $charset,
        string $collate
    ): void {
        $table = $tablePrefix . 'tsd_import_log';

        $connection->query(
            "CREATE TABLE IF NOT EXISTS `$table` (
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `idempotency_key` VARCHAR(191) NOT NULL,
                `product_id` BIGINT UNSIGNED NOT NULL,
                `variation_ids` TEXT NULL,
                `created_at` DATETIME NOT NULL,
                PRIMARY KEY (`id`),
                UNIQUE KEY `uniq_idempotency_key` (`idempotency_key`),
                KEY `idx_product_id` (`product_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=$charset COLLATE=$collate"
        );

        $this->say("Creating table $table");
    }

    /**
     * @return array{api_key:string, api_secret:string}
     */
    public static function generateKeys(): array
    {
        return [
            'api_key' => bin2hex(random_bytes(8)),
            'api_secret' => bin2hex(random_bytes(32)),
        ];
    }

    /**
     * Ghi config.ini.
     *
     * @param array<string,string> $extra keys to add or override
     * @throws InstallerException
     */
    public function writeConfig(array $credentials, string $charset, string $collate, string $siteUrl, array $extra = []): void
    {
        $values = array_merge([
            'db_host'                   => $credentials['DB_HOST'],
            'db_user'                   => $credentials['DB_USER'],
            'db_password'               => $credentials['DB_PASSWORD'] ?? '',
            'db_name'                   => $credentials['DB_NAME'],
            'table_prefix'              => $credentials['table_prefix'] ?? 'wp_',
            'charset'                   => $charset,
            'collate'                   => $collate,
            'site_url'                  => $siteUrl,
            'persistent_connection'     => '1',
        ], $extra);

        if (!Config::write(Config::path(), $values)) {
            throw new InstallerException(
                'Could not write config/config.ini. Make the config/ directory writable.'
            );
        }

        $this->say('Ghi config/config.ini');
    }

    /**
     * The routines still missing from the database.
     *
     * @return array<int,string>
     */
    public function missingRoutines(\mysqli $connection): array
    {
        $installed = [];

        $result = $connection->query(
            'SELECT ROUTINE_NAME AS name FROM information_schema.ROUTINES WHERE ROUTINE_SCHEMA = DATABASE()'
        );

        if ($result !== false) {
            while ($row = $result->fetch_assoc()) {
                $installed[strtolower((string) $row['name'])] = true;
            }
            $result->free();
        }

        $missing = [];
        foreach (SqlRewriter::ROUTINES as $routine) {
            $name = $this->functionPrefix . $routine;
            if (!isset($installed[strtolower($name)])) {
                $missing[] = $name;
            }
        }

        return $missing;
    }
}
