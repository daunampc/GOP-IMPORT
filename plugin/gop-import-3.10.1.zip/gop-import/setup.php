<?php

/**
 * The installer, from the command line or a browser.
 *
 * Since 3.0 the wp-admin dashboard (GOP_IMPORT → Status) does the same job with a
 * interface, and does it more accurately — it reads the database credentials
 * straight from WordPress's own constants instead of guessing where
 * wp-config.php is.
 *
 * This file is kept for two cases: installing across many sites from a script,
 * and rescue when wp-admin cannot be reached.
 *
 * All of the logic lives in src/Setup/Installer.php, shared with the admin
 * screen, so a fix in one place is a fix on both paths.
 */

declare(strict_types=1);

require_once __DIR__ . '/src/Bootstrap.php';

use GopImport\Bootstrap;
use GopImport\Setup\Installer;
use GopImport\Setup\InstallerException;
use GopImport\Support\Config;

Bootstrap::registerAutoloader();

$isCli = PHP_SAPI === 'cli';

function fail(string $message, array $log = []): never
{
    global $isCli;

    if ($isCli) {
        fwrite(STDERR, "ERROR: $message" . PHP_EOL);
        exit(1);
    }

    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(
        ['ok' => false, 'error' => $message, 'log' => $log],
        JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
    );
    exit;
}

function say(string $message): void
{
    global $isCli;

    if ($isCli) {
        echo $message . PHP_EOL;
    }
}

/**
 * The site URL prefers the request's real host: cloned sites often forget to update
 * `siteurl` trong database.
 */
function detect_site_url(\mysqli $connection, string $tablePrefix): string
{
    if (!empty($_SERVER['HTTP_HOST'])) {
        $scheme = $_SERVER['REQUEST_SCHEME'] ?? 'http';

        if (
            ($_SERVER['HTTPS'] ?? '') === 'on'
            || ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https'
            || str_contains((string) ($_SERVER['HTTP_CF_VISITOR'] ?? ''), 'https')
        ) {
            $scheme = 'https';
        }

        return $scheme . '://' . $_SERVER['HTTP_HOST'];
    }

    $statement = $connection->prepare(
        "SELECT option_value FROM `{$tablePrefix}options` WHERE option_name = 'siteurl' LIMIT 1"
    );
    $statement->execute();
    $row = $statement->get_result()->fetch_row();

    return (string) ($row[0] ?? '');
}

// ------------------------------------------------------------------- installing

// Checked BEFORE any mysqli_* call. Without stopping here, a missing extension
// produces only "Call to undefined function mysqli_report()", which says nothing
// about how to fix it.
if (!extension_loaded('mysqli')) {
    fail(
        "This server has not enabled the `mysqli` extension, and the plugin requires it.\n"
        . 'Enable `mysqli` under PHP Extensions in your hosting panel, or install the package, e.g. '
        . 'apt install php' . PHP_MAJOR_VERSION . '.' . PHP_MINOR_VERSION . '-mysql'
    );
}

if (version_compare(PHP_VERSION, '8.1', '<')) {
    fail('The plugin requires PHP 8.1 or newer; this server runs PHP ' . PHP_VERSION . '.');
}

// Over HTTP this only runs while NOT yet installed. Reinstalling goes through
// wp-admin, or by deleting config/config.ini over FTP/SSH. That way nobody
// outside can force a new key pair to be generated.
if (!$isCli && Config::exists()) {
    http_response_code(409);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'ok' => false,
        'error' => 'Already installed. Use the dashboard (GOP_IMPORT → Status) to reinstall, '
            . 'or delete config/config.ini and try again.',
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

$installer = new Installer(Bootstrap::FN_PREFIX);

say('GOP_IMPORT — starting installation');

$wpConfigPath = Installer::findWpConfig(__DIR__);
if ($wpConfigPath === null) {
    fail('wp-config.php was not found. The plugin must live in wp-content/plugins/.');
}
say("- Found wp-config.php: $wpConfigPath");

$credentials = Installer::parseWpConfig($wpConfigPath);
foreach (['DB_NAME', 'DB_USER', 'DB_HOST'] as $required) {
    if (!isset($credentials[$required])) {
        fail("Could not read the $required constant from wp-config.php.");
    }
}

$credentials['table_prefix'] ??= 'wp_';
say('- Table prefix: ' . $credentials['table_prefix']);

try {
    $connection = $installer->connect($credentials);
} catch (\mysqli_sql_exception $exception) {
    fail('Could not connect to the database: ' . $exception->getMessage());
}

[$charset, $collate] = $installer->detectCharsetCollate(
    $connection,
    $credentials['DB_NAME'],
    $credentials['table_prefix']
);
say("- Charset: $charset / $collate");

@$connection->set_charset($charset);

$siteUrl = detect_site_url($connection, $credentials['table_prefix']);
say("- Site URL: $siteUrl");

try {
    say('- Aligning the collation of the database and its relevant tables...');
    $installer->normalizeCollation(
        $connection,
        $credentials['DB_NAME'],
        $credentials['table_prefix'],
        $charset,
        $collate
    );

    say('- Installing the stored functions and procedures...');
    $installer->installRoutines($connection, $credentials['table_prefix'], __DIR__ . '/sql');

    say('- Creating the supporting tables...');
    $installer->installTables($connection, $credentials['table_prefix'], $charset, $collate);

    $keys = Installer::generateKeys();

    $installer->writeConfig($credentials, $charset, $collate, $siteUrl, $keys);
} catch (InstallerException $exception) {
    fail($exception->getMessage(), $installer->log());
}

say('- Wrote config/config.ini');
say('');
say('INSTALLATION COMPLETE. Save the two values below — the secret is shown ONCE:');
say('  api_key    = ' . $keys['api_key']);
say('  api_secret = ' . $keys['api_secret']);
say('');
say('Then delete setup.php, or press "Delete setup.php" in wp-admin.');

if (!$isCli) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'ok'         => true,
        'api_key'    => $keys['api_key'],
        'api_secret' => $keys['api_secret'],
        'site_url'   => $siteUrl,
        'note'       => 'Save api_secret now; it is shown once. Then delete setup.php from the server.',
        'log'        => $installer->log(),
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
