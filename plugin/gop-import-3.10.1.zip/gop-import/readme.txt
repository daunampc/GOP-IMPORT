=== GOP_IMPORT ===
Contributors: gopimport
Tags: woocommerce, import, products, bulk, api
Requires at least: 5.0
Tested up to: 7.0
Requires PHP: 8.1
Stable tag: 3.10.1
License: Proprietary
Text Domain: gop-import

High-speed WooCommerce product import over an authenticated API, writing straight
to MySQL, driven from the GOP_IMPORT web application.

== Description ==

This plugin is the site-side half of GOP_IMPORT. It exposes one authenticated API
endpoint and an admin dashboard; the catalogue itself is prepared, previewed and
sent by the web application.

Everything goes through **one** entry point, `index.php`, which authenticates
first and then routes against an allowlist. That file deliberately does NOT load
WordPress — it is why an import of 14,000 products is measured in minutes rather
than hours — so nothing in it can rely on WordPress functions, hooks or options.

What it does on the site:

* creates and updates products, variations, attributes, categories, tags and
  reviews, writing to `postmeta`, `wc_product_meta_lookup` and the term tables so
  category pages, price sorting and price filters agree with the product page;
* deletes products completely, including their variations, image attachments,
  meta, term links with the counts corrected, reviews and — if asked — the image
  files in uploads;
* fetches images into the site's own media library;
* clears WooCommerce's transients, because writing straight to the database means
  WooCommerce is never told to.

Every request is signed with HMAC-SHA256 over method, route, timestamp and body.
An unsigned or stale request is refused before anything is read.

== Installation ==

1. In wp-admin, go to **Plugins → Add New → Upload Plugin** and choose
   `gop-import-<version>.zip`.
2. Activate it. The directory must be named `gop-import` — every API URL is built
   from that name. Uploading the zip gets this right; copying files by hand may not.
3. Open **GOP_IMPORT** in the admin menu and run the installer. It writes
   `config/config.ini` with this site's database credentials and a freshly
   generated API key and secret.
4. Paste the API key and secret into the web application when connecting the site.
5. Enter your licence key when the plugin asks for it, and press Activate.

`config/config.ini` is never shipped and never overwritten by an upgrade: it holds
this site's own credentials.

== Frequently Asked Questions ==

= Does it need WooCommerce? =

Yes. It writes WooCommerce's own tables and meta; without WooCommerce active the
data would exist and nothing would render it.

= Why does the plugin directory name matter? =

The API URL is `<site>/wp-content/plugins/gop-import/index.php`. A directory with
another name answers 404 to every call. The web application has a "Plugin base URL
override" for a site that cannot be renamed.

= Where are the logs? =

`logs/php-error.log` inside the plugin directory, and the admin dashboard shows
the import log. Neither is web-readable: both directories carry an `.htaccess`
deny rule.

== Changelog ==

= 3.10.1 =
* **A site whose clock differs from the managing app's no longer refuses everything.**
  Two servers never agree on the time, and a difference of more than five minutes made
  every request fail with "Authentication failed." — the same words as a wrong secret,
  so nothing on either side said which it was. A request whose signature is correct but
  whose timestamp is outside the five-minute window now answers `stale_request` with
  `server_time`, and the app corrects its own timestamp and retries once. The replay
  window stays five minutes: it is not widened to cover the skew.
* The signature is now checked BEFORE the timestamp, so `server_time` is only ever told
  to a caller that holds the secret. Anyone else still gets the same vague refusal as
  before.
* The skew is written to `logs/php-error.log`, so an operator can read how far apart
  the two clocks are.

= 3.10.0 =
* **Images travel as raw bytes, not base64.** The upload body is a JSON manifest, a
  newline, then the images end to end. Base64 cost a third of the wire on every
  image-heavy request — 2.00 MB of JPEG became 2.67 MB — plus an encode on one side and
  a decode on the other. A request now carries half again as much image for the same
  body size, so a catalogue needs a third fewer round trips, and the per-image limit
  rises from 22 MB to 31 MB.
* **New `POST /images/present`.** Answers which images this site already holds. The
  managing app asks before it fetches anything, and every "yes" is an image it neither
  downloads from the source nor sends here. On a catalogue being re-synced that is most
  of the traffic of a run.
* **Images are stored at a content-addressed path**, `gop-import/<2 hex>/`, instead of
  `YYYY/MM/`. That is what makes the question above answerable: a dated path put the
  same image somewhere else next month, so nothing could be looked up. Files are spread
  over 256 directories, so a catalogue of 100,000 images is not one unlistable folder.
* The `file_name` field is gone from the upload. A client-supplied name would make the
  path a function of the request, and the lookup above would always miss.
* **Required** by the managing app for the "copy into the site's media library" image
  mode. The format is not negotiated, so a 3.9.0 site is refused rather than fed a body
  it would read as base64 and reject entry by entry.

= 3.9.0 =
* **The plugin no longer downloads images.** `POST /images/fetch` is gone, and with it
  every outbound network call this plugin used to make. The web application downloads
  each image and sends the bytes to the new `POST /images/upload`, which only decodes
  and writes the file. A request now costs a disk write instead of holding a PHP
  process for as long as the slowest image host took — which is what exhausted PHP-FPM
  pools and returned 502 to real shoppers during an import.
* Writing an image is **idempotent**. The filename is derived from the source URL, so
  a retried batch overwrites nothing and leaves no `-1`, `-2` duplicates in uploads.
  One image used by many products is stored once.
* The bytes are checked against a magic-byte table, so a host that answers 200 with an
  HTML error page can no longer land in the media library as a `.jpg`. The previous
  build trusted the `Content-Type` the remote server declared.
* `GET /health` reports `max_image_upload_bytes` and `php_memory_limit`.
* Images larger than **22 MB** are refused (the previous limit was 32 MB). Base64 in a
  32 MB body cannot carry more, and this build says so with `upload_too_large` instead
  of failing obscurely.
* **This build is required** by the web application for the "copy into the site's media
  library" image mode; the application refuses that mode against older builds.
* `allow_private_image_hosts` is removed from the configuration. It guarded outbound
  fetches, and there are none left.

= 3.8.0 =
* A build with no activation server address (`GOP_IMPORT_APP_URL` empty) now accepts a
  licence key on the site itself instead of refusing it, so the plugin can be tested
  without one. Every screen shows "not verified" in that state and `GET /health`
  reports `verified: false`. Putting an address back into that one constant restores
  real checking with no other change. A build in this state accepts any key, so it is
  not one to distribute.

= 3.7.0 =
* `POST /products/lookup` gained `without_images`: find the products that have no
  picture at all, so they can be reviewed and removed from the web application.
  An external image URL counts as an image — that is what the default import mode
  writes — and so does an image on a variation, because a variable product whose
  variants have pictures shows pictures. Every row the lookup returns now carries
  `has_image`, from the same definition the filter used, so the list an operator reads
  agrees with why it matched.

= 3.6.0 =
* Customers enter their licence key and nothing else. The activation server's address
  is part of the build (`GOP_IMPORT_APP_URL` in gop-import.php), so it is set once for
  every installation and can be overridden for a single site from wp-config.php.

= 3.5.1 =
* Rewrote every message the plugin shows. They were paragraphs explaining how
  licensing works; they are now one line each. Two of them were also out of date and
  said reading still worked without a key, which stopped being true in 3.5.0.
* Dates are shown as dates rather than as ISO timestamps.
* Tidier activation dialog and licence panel.

= 3.5.0 =
* An unactivated installation now refuses EVERY route, not only the ones that write.
  Each refusal is a 403 carrying a `license_*` code, so the web application still
  tells "this site is not activated" apart from "this site is unreachable" — and says
  which.
* wp-admin shows an activation dialog until a key is entered, and offers nothing else:
  every other screen would be a button that leads nowhere while the API refuses
  everything.
* The web application refuses to publish to a site activated with a DIFFERENT key
  from the account's own, and says so in those words.

= 3.4.0 =
* Activation key. The plugin confirms the key with the web application; `GET /health`
  reports a SHA-256 fingerprint of the key, never the key, so the web application can
  confirm a site is running its own account's key. The key is re-confirmed daily; a
  check that cannot reach the server changes nothing, and the last successful answer
  keeps working for 14 days.

= 3.3.1 =
* Declares compatibility with WooCommerce's High-Performance Order Storage (HPOS),
  the cart and checkout blocks, and the product block editor — which removes the
  "some of your active plugins are incompatible with currently enabled WooCommerce
  features" notice. Nothing was broken: the plugin never touches orders, cart or
  checkout, and it had simply never said so.

= 3.3.0 =
* Packaged to WordPress conventions: readme.txt, uninstall cleanup, an activation
  check that refuses to activate on an unsupported PHP or without mysqli rather
  than white-screening wp-admin, translation loading, and directory index guards.
* No change to the API, the database writes or the admin screens.

= 3.2.0 =
* `POST /products/update` — change products that already exist, writing only the
  fields a request actually carries.
* `POST /products/exists` — ask which SKUs the site already has, before a run.
* `POST /maintenance/recalculate-prices`.
* Product lookup gained `name` and `status` filters and returns prices and stock.
* Fixed `clear_woocommeerce_transients(0)` deleting every option whose name ended
  in `_0`.

= 3.1.0 =
* Deep product deletion, taxonomy reading, transient clearing, admin dashboard.

== Upgrade Notice ==

= 3.10.1 =
Fixes "Authentication failed." on every request when this site's clock and the managing
app's differ by more than five minutes. Update this plugin, then the managing app.

= 3.10.0 =
Required for the "copy into the site's media library" image mode, and worth having for
speed: images now travel as raw bytes rather than base64, and the app asks which ones
this site already holds before sending anything. Update the plugin BEFORE that mode is
used again — the app blocks such a run against an older build rather than failing image
by image. Images already copied by 3.8.0 or earlier are not found by the new lookup, so
the first run after upgrading re-sends them once.

= 3.9.0 =
Required for the "copy into the site's media library" image mode. This build removes
`POST /images/fetch`, so update the plugin BEFORE that mode is used again — the web
application blocks such a run against an older build rather than failing image by
image. Imports stop loading your site's PHP to fetch images.

= 3.8.0 =
For testing: a key is accepted without being checked while this build carries no
activation server address.

= 3.7.0 =
Needed for "products with no image" in the web application. Older builds ignore the
new filter rather than refusing it, so the web application refuses to use it against
a site below 3.7.0 instead of quietly matching everything.

= 3.6.0 =
The activation screen no longer asks for a server address; it is built in. Nothing to
do on a site that is already activated.

= 3.5.1 =
Wording and layout only.

= 3.5.0 =
An unactivated site now refuses every API call, not only the ones that write, and
wp-admin asks for the key in a dialog. Enter the key before upgrading a site that is
in use, or its next import is refused.

= 3.4.0 =
Needs an activation key on the plugin's Licence tab — the same key the web
application uses. Until it is entered, imports are refused and the site stays
readable.

= 3.3.1 =
Clears WooCommerce's plugin-incompatibility notice by declaring what this plugin
does and does not touch. No behaviour change.

= 3.3.0 =
Packaging only. Nothing about the API, the writes or the screens changed, so a site
on 3.2.0 keeps working exactly as it did.
